package com.novax;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.ArrayList;
import java.util.Locale;

@CapacitorPlugin(name = "NovaVoice")
public class NovaVoicePlugin extends Plugin {
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean wakeMode = false;
    private boolean commandMode = false;
    private static final int MIC_REQUEST = 4101;

    @Override public void load() {
        tts = new TextToSpeech(getContext(), status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault()); });
    }

    private boolean micReady() {
        if (getContext().checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) return true;
        getActivity().requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
        return false;
    }

    private void emit(String event, String text) {
        JSObject o = new JSObject();
        if (text != null) o.put("text", text);
        notifyListeners(event, o);
    }

    private void emitState(String state) {
        JSObject o = new JSObject(); o.put("state", state); notifyListeners("state", o);
    }

    private void stopRecognizer() {
        if (recognizer != null) { try { recognizer.stopListening(); } catch (Exception ignored) {} try { recognizer.cancel(); } catch (Exception ignored) {} recognizer.destroy(); recognizer = null; }
    }

    private void listen(final boolean wake) {
        stopRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(getContext())) { emit("error", "Speech recognition is not available on this device."); return; }
        wakeMode = wake; commandMode = !wake;
        emitState(wake ? "wake" : "command");
        recognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onPartialResults(Bundle b) {
                if (!wakeMode) return;
                ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(a!=null && !a.isEmpty()) checkWake(a.get(0));
            }
            public void onEvent(int t, Bundle p) {}
            public void onError(int e) { if (wakeMode && wakeActive()) { new android.os.Handler().postDelayed(() -> listen(true), 350); } else { emitState("idle"); } }
            public void onResults(Bundle b) {
                ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text=(a!=null&&!a.isEmpty())?a.get(0).trim():"";
                if(wakeMode) checkWake(text); else if(!text.isEmpty()) { emit("command", text); emitState("idle"); }
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, wake);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        recognizer.startListening(i);
    }

    private boolean wakeActive() { return wakeMode && !commandMode; }

    private void checkWake(String text) {
        if (text == null) return;
        String n=text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
        int p=n.indexOf("hey nova");
        if(p>=0) {
            String after=n.substring(p+8).trim();
            emit("wakeWord", "hey nova");
            if(!after.isEmpty()) { stopRecognizer(); commandMode=true; wakeMode=false; emitState("command"); emit("command", after); }
            else { listen(false); }
        }
    }

    @PluginMethod public void startWakeWord(PluginCall call) {
        if (!micReady()) { call.resolve(); return; }
        listen(true); call.resolve();
    }

    @PluginMethod public void stopWakeWord(PluginCall call) {
        wakeMode=false; commandMode=false; stopRecognizer(); emitState("idle"); call.resolve();
    }

    @PluginMethod public void startCommand(PluginCall call) {
        if (!micReady()) { call.resolve(); return; }
        listen(false); call.resolve();
    }

    @PluginMethod public void speak(PluginCall call) {
        String text=call.getString("text", "");
        if(tts!=null && !text.isEmpty()) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova");
        call.resolve();
    }

    @Override protected void handleOnDestroy() { stopRecognizer(); if(tts!=null) tts.shutdown(); super.handleOnDestroy(); }
}

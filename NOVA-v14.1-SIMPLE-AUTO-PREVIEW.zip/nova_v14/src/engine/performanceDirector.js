export const QUALITY_ORDER = ['invisible','farGeometry','farTextures','shadowDistance','crowdDensity','secondaryEffects','dynamicResolution'];
export function recommendAdjustments(metrics) {
  if ((metrics.memoryMB ?? 0) > (metrics.memoryBudgetMB ?? 0) * 0.9) return ['evictUnused','reduceTextureMips','reduceFarGeometry'];
  if ((metrics.frameMs ?? 0) > (1000 / (metrics.targetFps || 30))) return ['reduceInvisibleWork','reduceFarGeometry','reduceShadows','reduceCrowds','reduceSecondaryEffects','enableDynamicResolution'];
  return ['holdQuality'];
}

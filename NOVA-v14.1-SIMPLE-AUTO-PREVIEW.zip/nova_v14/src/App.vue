<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { DEFAULT_GAME_PROMPT } from './prompts/gamePrompt';
import { DEFAULT_VIDEO_PROMPT } from './prompts/videoPrompt';
import { chooseBestAssets, buildAcquisitionPlan, cleanupPlan } from './services/assetResolver';
import { DEVICE_PROFILES, buildQualityPlan, chooseMobileVariant } from './services/mobileQuality';
import { buildVideoRenderPlan } from './services/videoRenderer';

const panel = ref(null);
const menu = ref(false);
const device = ref(localStorage.getItem('nova.device') || 'low');
const gamePrompt = ref(localStorage.getItem('nova.gamePrompt') || DEFAULT_GAME_PROMPT);
const videoPrompt = ref(localStorage.getItem('nova.videoPrompt') || DEFAULT_VIDEO_PROMPT);
const notice = ref('NOVA READY');
const selectedAssets = ref([]);
const acquisition = ref([]);
const cleanup = ref([]);
const qualityPlan = ref(buildQualityPlan(DEVICE_PROFILES.low));
const videoPlan = ref(buildVideoRenderPlan());
const showAdvanced = ref(false);
const rendererPlacement = ref(localStorage.getItem('nova.rendererPlacement') || 'end');
const gamePreviewOn = ref(false);
const videoPreviewOn = ref(false);
const gamePreviewRef = ref(null);
const videoPreviewRef = ref(null);
let observer;

const currentProfile = computed(() => DEVICE_PROFILES[device.value]);
const rendererLabel = computed(() => rendererPlacement.value === 'end' ? 'At the end' : rendererPlacement.value === 'middle' ? 'After setup' : 'Near the top');

function open(p) {
  panel.value = p;
  menu.value = false;
  showAdvanced.value = false;
  notice.value = p === 'game' ? 'GAME READY' : p === 'video' ? 'VIDEO READY' : 'IMAGE READY';
  nextTick(setupPreviewObserver);
}
function closePanel() { panel.value = null; stopPreviewObserver(); }
function savePrompt(kind) {
  localStorage.setItem(kind === 'game' ? 'nova.gamePrompt' : 'nova.videoPrompt', kind === 'game' ? gamePrompt.value : videoPrompt.value);
  notice.value = 'Saved';
}
function resetPrompt(kind) {
  if (kind === 'game') gamePrompt.value = DEFAULT_GAME_PROMPT;
  else videoPrompt.value = DEFAULT_VIDEO_PROMPT;
  notice.value = 'Restored';
}
function resolveAssets() {
  const candidates = [
    { id:'unity-hero-high', name:'High-detail hero character', source:'Authorized Unity-compatible connector', sourceType:'unity-package', license:'commercial-license', modificationAllowed:true, redistributionAllowed:false, quality:98, mobileCost:48, category:'character', tags:['hero','realistic','rigged','high-detail'], cached:true, variants:[{id:'mobile',mobile:true},{id:'balanced',mobile:true},{id:'high'}] },
    { id:'unity-creature-cute', name:'Cute creature companion', source:'Authorized Unity-compatible connector', sourceType:'unity-package', license:'commercial-license', modificationAllowed:true, redistributionAllowed:false, quality:94, mobileCost:34, category:'creature', tags:['cute','creature','rigged','animated'], cached:true, variants:[{id:'mobile',mobile:true},{id:'balanced',mobile:true},{id:'high'}] },
    { id:'unity-city', name:'Detailed modular world', source:'Authorized Unity-compatible connector', sourceType:'unity-package', license:'commercial-license', modificationAllowed:true, redistributionAllowed:false, quality:96, mobileCost:58, category:'environment', tags:['city','modular','realistic','detailed'], cached:true, variants:[{id:'mobile',mobile:true},{id:'balanced',mobile:true},{id:'high'}] },
    { id:'unity-vehicle', name:'Mobile-optimized vehicle', source:'Authorized Unity-compatible connector', sourceType:'unity-package', license:'commercial-license', modificationAllowed:true, redistributionAllowed:false, quality:91, mobileCost:27, category:'vehicle', tags:['vehicle','mobile','optimized'], cached:false, variants:[{id:'mobile',mobile:true},{id:'balanced',mobile:true}] },
    { id:'unknown', name:'Unverified download', source:'Unknown website', license:'unknown', modificationAllowed:false, quality:100, mobileCost:20, category:'environment', tags:['detailed'] }
  ];
  const requirements = {
    character:{slot:'hero',category:'character',hero:true,tags:['hero','realistic','rigged','high-detail'],mobileCostBudget:52},
    creature:{slot:'creature',category:'creature',hero:true,tags:['cute','creature','rigged','animated'],mobileCostBudget:40},
    environment:{slot:'near-world',category:'environment',nearCamera:true,tags:['city','modular','realistic','detailed'],mobileCostBudget:62},
    vehicle:{slot:'vehicle',category:'vehicle',tags:['vehicle','mobile','optimized'],mobileCostBudget:32}
  };
  selectedAssets.value = chooseBestAssets(candidates, requirements).map(a => ({...a, variant: chooseMobileVariant(a, currentProfile.value)?.id || 'source'}));
  acquisition.value = buildAcquisitionPlan(candidates, requirements);
  notice.value = `${selectedAssets.value.length} assets ready`;
}
function optimizeScene() {
  qualityPlan.value = buildQualityPlan(currentProfile.value);
  notice.value = `${currentProfile.value.label} mode`;
}
function runCleanup() {
  const source = selectedAssets.value.map((a, i) => ({...a, active:i < 2, visible:true, distance:i * 30, cached:true}));
  source.push({id:'unused-temp',name:'Unused conversion temp',visible:false,cached:true,license:'user-owned',modificationAllowed:true});
  source.push({id:'blocked-download',name:'Blocked unverified asset',visible:false,cached:false,license:'unknown'});
  cleanup.value = cleanupPlan(source,{nearDistance:60,prefetchDistance:220});
}
function refreshVideoPlan() {
  videoPlan.value = buildVideoRenderPlan({durationMinutes:10,shotSeconds:6});
  notice.value = `${videoPlan.value.estimatedShots} shots planned`;
}
function generate(kind) {
  savePrompt(kind);
  if (kind === 'game') { resolveAssets(); optimizeScene(); runCleanup(); notice.value = 'Build ready to preview'; }
  else { refreshVideoPlan(); notice.value = 'Video ready to preview'; }
  nextTick(setupPreviewObserver);
}
function setPlacement(value) {
  rendererPlacement.value = value;
  localStorage.setItem('nova.rendererPlacement', value);
  notice.value = `Preview ${rendererLabel.value.toLowerCase()}`;
}
function togglePreview(kind, force) {
  const target = kind === 'game' ? gamePreviewOn : videoPreviewOn;
  target.value = typeof force === 'boolean' ? force : !target.value;
}
function setupPreviewObserver() {
  stopPreviewObserver();
  const targets = [];
  if (panel.value === 'game' && gamePreviewRef.value) targets.push(['game', gamePreviewRef.value]);
  if (panel.value === 'video' && videoPreviewRef.value) targets.push(['video', videoPreviewRef.value]);
  if (!targets.length || !('IntersectionObserver' in window)) return;
  observer = new IntersectionObserver(entries => {
    entries.forEach(entry => togglePreview(entry.target.dataset.renderer, entry.isIntersecting));
  }, { threshold: 0.18, rootMargin: '0px 0px -8% 0px' });
  targets.forEach(([kind, el]) => { el.dataset.renderer = kind; observer.observe(el); });
}
function stopPreviewObserver() {
  if (observer) { observer.disconnect(); observer = null; }
  gamePreviewOn.value = false;
  videoPreviewOn.value = false;
}

onMounted(() => { resolveAssets(); optimizeScene(); runCleanup(); refreshVideoPlan(); });
watch(device, () => { localStorage.setItem('nova.device', device.value); optimizeScene(); resolveAssets(); runCleanup(); });
onBeforeUnmount(stopPreviewObserver);
</script>

<template>
  <main class="app-shell">
    <header class="topbar">
      <div class="brand-wrap"><div class="nova-mark">N</div><div class="brand">NOVA</div></div>
      <div class="top-actions"><div class="status">{{ notice }}</div><button class="dots" @click="menu=!menu" aria-label="Open menu">•••</button></div>
    </header>

    <div v-if="menu" class="menu">
      <button @click="open('image')"><span>IMAGE</span><small>Make a still image</small></button>
      <button @click="open('video')"><span>VIDEO / ANIME</span><small>Make a cinematic video</small></button>
      <button @click="open('game')"><span>GAME</span><small>Build and preview a 3D game</small></button>
    </div>

    <section v-if="!panel" class="home">
      <div class="orbital"><div class="orbital-ring ring-a"></div><div class="orbital-ring ring-b"></div><div class="orbital-line"></div><button class="core" @click="open('game')"><span>N</span><small>NOVA</small></button></div>
      <div class="home-caption">CREATE • PREVIEW • USE</div>
      <div class="showcase-row">
        <button class="showcase-card active" @click="open('game')"><div class="scene-thumb city-thumb"><span>3D GAME</span></div><strong>GAME</strong><small>Build it, then see it on your phone</small></button>
        <button class="showcase-card" @click="open('video')"><div class="scene-thumb anime-thumb"><span>VIDEO</span></div><strong>VIDEO / ANIME</strong><small>Make it shot by shot</small></button>
        <button class="showcase-card" @click="open('image')"><div class="scene-thumb image-thumb"><span>IMAGE</span></div><strong>IMAGE</strong><small>Create a still image</small></button>
      </div>
    </section>

    <section v-else class="workspace">
      <div class="workspace-head"><button class="back" @click="closePanel">←</button><div><div class="eyebrow">NOVA / {{ panel.toUpperCase() }}</div><h1>{{ panel==='game'?'Game':panel==='video'?'Video / Anime':'Image Studio' }}</h1><p v-if="panel==='game'">Simple build controls. The preview wakes up by itself when you reach it.</p><p v-else-if="panel==='video'">Simple video controls. The preview wakes up when it enters the screen.</p><p v-else>Simple still-image workspace.</p></div></div>

      <div v-if="panel==='game'" class="simple-layout" :class="`placement-${rendererPlacement}`">
        <article class="card build-card">
          <div class="pill">3D GAME</div><h2>Build your game</h2><p>Tell NOVA what you want. NOVA chooses permitted high-quality assets and the smallest mobile-friendly versions that keep the important details.</p>
          <textarea v-model="gamePrompt" aria-label="Game prompt"></textarea>
          <div class="simple-actions"><button @click="resetPrompt('game')">Use example</button><button class="primary" @click="generate('game')">Build</button></div>
        </article>
        <article class="card phone-card">
          <div class="phone-title"><span>PHONE MODE</span><b>{{ currentProfile.label }}</b></div>
          <select v-model="device" aria-label="Phone quality"><option value="low">Low-end Android</option><option value="balanced">Balanced Android</option><option value="high">High Android</option></select>
          <div class="easy-stats"><span><b>{{currentProfile.targetFps}}</b> FPS</span><span><b>{{currentProfile.textureBudgetMB}}</b> MB</span><span><b>{{currentProfile.maxActiveLights}}</b> lights</span></div>
          <p>High detail stays closest to the camera. Far and unused detail is reduced first.</p>
        </article>

        <article ref="gamePreviewRef" class="card auto-renderer" :class="{ 'renderer-on': gamePreviewOn }">
          <div class="renderer-head"><div><span class="pill">AUTO PREVIEW</span><h2>See the downloaded game</h2><p>This is the small-screen preview of the assembled 3D build. It automatically starts when this card reaches your screen.</p></div><span class="auto-state">{{gamePreviewOn?'ON':'SLEEPING'}}</span></div>
          <div class="mini-runtime" :class="{'active':gamePreviewOn}"><div class="mini-sky"></div><div class="mini-ground"></div><div class="mini-hero"></div><div class="mini-creature"></div><div class="mini-world"></div><div v-if="!gamePreviewOn" class="mini-sleep">Scroll here to start preview</div><div v-else class="mini-live">LIVE • SAME MOBILE PROFILE</div></div>
          <div class="renderer-note"><span>3D runtime preview</span><span>{{currentProfile.targetFps}} FPS target</span><span>{{rendererLabel}}</span></div>
        </article>

        <article class="card easy-more"><button @click="showAdvanced=!showAdvanced">{{showAdvanced?'Hide':'More'}} settings</button><div v-if="showAdvanced" class="advanced-content"><p>Selected assets: {{selectedAssets.length}} • Quality plan: {{qualityPlan.textureBudgetMB}} MB textures.</p><ul><li v-for="a in selectedAssets" :key="a.id">{{a.name}} — {{a.variant}}</li></ul><button @click="runCleanup">Clear unused build content</button></div></article>
      </div>

      <div v-if="panel==='video'" class="simple-layout" :class="`placement-${rendererPlacement}`">
        <article class="card build-card">
          <div class="pill">VIDEO / ANIME</div><h2>Make your video</h2><p>NOVA breaks a long episode into small shots, keeps characters consistent, and joins the finished shots at the end.</p>
          <textarea v-model="videoPrompt" aria-label="Video prompt"></textarea>
          <div class="simple-actions"><button @click="resetPrompt('video')">Use example</button><button class="primary" @click="generate('video')">Prepare video</button></div>
        </article>
        <article class="card phone-card"><div class="phone-title"><span>10-MINUTE EPISODE</span><b>{{videoPlan.estimatedShots}} shots</b></div><div class="easy-stats"><span><b>{{videoPlan.shotSeconds}}s</b> each</span><span><b>10m</b> total</span><span><b>1</b> final video</span></div><p>Only the shot on screen needs to be active in the preview, helping a low-end phone stay responsive.</p></article>

        <article ref="videoPreviewRef" class="card auto-renderer" :class="{ 'renderer-on': videoPreviewOn }">
          <div class="renderer-head"><div><span class="pill">AUTO PREVIEW</span><h2>See the finished video</h2><p>This preview automatically turns on when it reaches the screen. It uses a lightweight preview instead of rendering the whole episode on the phone.</p></div><span class="auto-state">{{videoPreviewOn?'ON':'SLEEPING'}}</span></div>
          <div class="mini-video" :class="{'active':videoPreviewOn}"><div class="video-light"></div><div class="video-character"></div><div class="video-title-card">{{videoPreviewOn?'SHOT PREVIEW':'Scroll here to start preview'}}</div><div class="video-filmstrip"><i v-for="n in 8" :key="n" :class="{on:videoPreviewOn && n<5}"></i></div></div>
          <div class="renderer-note"><span>Video / anime preview</span><span>{{videoPlan.estimatedShots}} shots ready</span><span>{{rendererLabel}}</span></div>
        </article>

        <article class="card easy-more"><button @click="showAdvanced=!showAdvanced">{{showAdvanced?'Hide':'More'}} settings</button><div v-if="showAdvanced" class="advanced-content"><p>The full renderer remains separate from the game runtime.</p><button @click="savePrompt('video')">Save prompt</button></div></article>
      </div>

      <div v-if="panel==='image'" class="studio-grid"><article class="card wide"><div class="pill">IMAGE</div><h2>Image Studio</h2><div class="image-stage"><div class="image-stage-orb">N</div><div><strong>Describe what you want.</strong><p>The image pipeline stays separate from game and video rendering.</p></div></div></article></div>

      <div v-if="panel!=='image'" class="preview-placement card"><span>Preview position</span><select :value="rendererPlacement" @change="setPlacement($event.target.value)"><option value="end">At the end</option><option value="middle">After setup</option><option value="top">Near the top</option></select><small>Automatic by default. The preview wakes only when it is visible to save phone power.</small></div>
    </section>
  </main>
</template>

import { buildConversionPlan, normalizeAsset, isReusePermitted } from './assetResolver';

const FORMAT_MAP = {
  unitypackage: 'UNITY_PACKAGE',
  glb: 'GLB',
  gltf: 'GLTF',
  fbx: 'FBX',
  obj: 'OBJ',
  prefab: 'UNITY_PREFAB'
};

export function inspectImport(fileName, metadata = {}) {
  const ext = String(fileName || '').split('.').pop().toLowerCase();
  return {
    fileName,
    format: FORMAT_MAP[ext] || 'UNKNOWN',
    license: metadata.license || 'unknown',
    authorized: metadata.authorized === true
  };
}

export function planAuthorizedConversion(fileName, metadata = {}) {
  const inspected = inspectImport(fileName, metadata);
  const asset = normalizeAsset({
    name: fileName,
    source: metadata.source || 'User import',
    sourceType: inspected.format,
    license: inspected.license,
    modificationAllowed: metadata.modificationAllowed === true
  });

  if (!inspected.authorized || !isReusePermitted(asset)) {
    return { allowed: false, inspected, reason: 'The import needs verified rights and permission to modify/convert.' };
  }
  return { allowed: true, inspected, plan: buildConversionPlan(asset) };
}

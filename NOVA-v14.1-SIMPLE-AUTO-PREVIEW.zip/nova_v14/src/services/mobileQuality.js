export const DEVICE_PROFILES = {
  low: {
    id: 'low', label: 'Low-end Android', ramMB: 1024, targetFps: 30,
    textureBudgetMB: 220, sceneMemoryMB: 650, maxVisibleHighDetail: 18,
    maxActiveLights: 2, shadowDistance: 28, resolutionScale: 0.75,
    textureMaxSize: 1024, preferVariants: ['mobile','lite'],
  },
  balanced: {
    id: 'balanced', label: 'Balanced Android', ramMB: 2048, targetFps: 45,
    textureBudgetMB: 420, sceneMemoryMB: 1200, maxVisibleHighDetail: 32,
    maxActiveLights: 4, shadowDistance: 55, resolutionScale: 0.9,
    textureMaxSize: 1536, preferVariants: ['mobile','balanced'],
  },
  high: {
    id: 'high', label: 'High Android', ramMB: 4096, targetFps: 60,
    textureBudgetMB: 800, sceneMemoryMB: 2400, maxVisibleHighDetail: 60,
    maxActiveLights: 8, shadowDistance: 90, resolutionScale: 1,
    textureMaxSize: 2048, preferVariants: ['high','balanced'],
  }
};

export function chooseMobileVariant(asset, profile) {
  const variants = Array.isArray(asset?.variants) ? asset.variants : [];
  const wanted = profile?.preferVariants || ['mobile','lite'];
  return variants.find(v => wanted.includes(v.id)) || variants.find(v => v.mobile === true) || null;
}

export function buildQualityPlan(profile, { hero = true } = {}) {
  return {
    profile: profile.id,
    keepHeroHighestDetail: hero,
    heroPriority: ['geometry','materials','animation','texture-detail'],
    reduceInOrder: ['invisible-work','far-geometry','far-textures','shadow-distance','crowds','secondary-effects','resolution-scale'],
    textureMaxSize: profile.textureMaxSize,
    textureBudgetMB: profile.textureBudgetMB,
    sceneMemoryMB: profile.sceneMemoryMB,
    maxActiveLights: profile.maxActiveLights,
    shadowDistance: profile.shadowDistance,
    resolutionScale: profile.resolutionScale,
    streaming: 'camera-predicted-zones',
    eviction: 'unused-and-out-of-range-after-grace-period'
  };
}

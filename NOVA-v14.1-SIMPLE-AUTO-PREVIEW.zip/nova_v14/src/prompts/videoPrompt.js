export const DEFAULT_VIDEO_PROMPT = `NOVA ANIME STUDIO — 10-MINUTE CINEMATIC SHOWCASE

Create an ORIGINAL 10-minute anime episode designed as a sequence of short production-ready shots. Use the quality categories of polished studio anime—strong composition, expressive acting, detailed backgrounds, dynamic timing, controlled effects and continuity—without copying any existing series, characters, scenes, dialogue, music or footage.

STORY: An original fantasy-adventure about a young courier who discovers a hidden sky-city and must protect a mysterious living map before sunset.

CHARACTER BIBLE
Create original characters with locked identity records: face proportions, eyes, hair, costume, body proportions, palette, personality, voice, animation style and state. Reuse the same references/keyframes across every shot. Reject shots that drift from the identity record.

WORLD BIBLE
Create original locations with consistent architecture, geography, props, lighting rules, weather and time of day. Reuse environment references across shots.

PRODUCTION PIPELINE
script -> episode outline -> character bible -> world bible -> storyboard -> shot list -> keyframe art -> animation -> temporal consistency -> camera/compositing -> lighting/effects -> voice -> dialogue/lip sync -> music/ambience -> continuity QC -> repair -> edit.

SHOT-FIRST RULE
Do not attempt to generate one ten-minute clip in a single pass. Break the episode into manageable shots and assemble them into one final timeline. Preserve character, costume, location and camera continuity between shots.

ANIME MOTION LANGUAGE
Use expressive poses, held frames where appropriate, stylized timing, anticipation, impact timing, controlled smear-like motion only when supported, dramatic camera moves, readable silhouettes, layered effects and intentional cuts. Do not simply apply an anime filter to generic footage.

VOICE
Use multiple original voice profiles suitable for the characters. Keep voices consistent across the episode. Generate dialogue from the original script and synchronize speech timing to the shot.

MEDIA RIGHTS
Only use user-owned, public-domain or explicitly reuse-permitted reference/background media. Track provenance and license metadata. Do not scrape or reuse copyrighted media merely because it is downloadable.

QUALITY CONTROL
Check face identity, costume, proportions, background continuity, lighting direction, motion consistency, dialogue sync, audio levels and shot transitions. Regenerate only the failed shot or frame range instead of redoing the entire episode.

FINAL OUTPUT
Assemble the completed shots into a coherent 10-minute episode with opening, rising action, climax and resolution. Produce a shot manifest, continuity report and final timeline manifest.`;

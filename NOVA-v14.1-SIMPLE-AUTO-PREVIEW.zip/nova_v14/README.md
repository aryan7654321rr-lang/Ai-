# NOVA v14.1 — Simple Auto Preview

NOVA is designed around a low-end Android first workflow.

## What changed

- Simplified Game and Video screens: build first, preview second.
- The renderer means **Build Preview**: a small on-phone view of how the assembled build is intended to look when used/downloaded.
- Game Preview and Video Preview are completely separate.
- The preview is placed automatically. Default: **At the end** of the section.
- The user can choose **At the end / After setup / Near the top**. The choice is saved.
- An `IntersectionObserver` automatically wakes the preview when it enters the screen and puts it to sleep when it leaves. This is specifically to reduce GPU, CPU, memory and battery use on low-end phones.
- Low-end Android remains the default profile.
- Game quality stays focused on hero character, nearby characters/creatures and near-camera world detail; distant/invisible work is reduced first.
- The Game screen remains a 3D runtime host architecture; the preview does not fall back to a 2D game.
- The Video screen remains a separate shot-based cinematic/anime pipeline.
- Advanced controls are hidden under **More settings** instead of filling the main screen.

## Important runtime note

The preview host is deliberately lightweight. A production native 3D runtime/authorized asset connector still needs to supply the actual selected Unity-compatible assets and assembled runtime. This UI does not pretend that a CSS mockup is the finished 3D game.

## Build

```bash
npm install
npm run build
```

No third-party game/video assets are bundled by this project.

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref } from 'vue'

const prompt = ref('Create an original cinematic anime fantasy city with a detailed hero, giant floating ruins, forests, weather, NPCs and a dramatic story.')
const status = ref('Ready')
const mode = ref('studio')
const quality = ref('auto')
const settingsOpen = ref(false)
const micState = ref('Not requested')
const notifications = ref(true)
const videoUrl = ref('')
const videoMime = ref('')
const videoBlob = ref(null)
const isGenerating = ref(false)
const isPlaying = ref(false)
const fps = ref(0)
const rendererLabel = ref('Detecting GPU…')
const worldSeed = ref(Math.floor(Math.random()*1e9))
const canvas = ref(null)
const videoPreview = ref(null)
let ctx, raf, lastFrame=performance.now(), frames=0, fpsTime=performance.now(), recorder, chunks=[]
let audioCtx

const world = ref({
  title:'NOVA World', style:'cinematic anime fantasy', time:0.35, weather:0.2,
  hero:{x:0,y:0,z:0,phase:0}, camera:{x:0,y:2.8,z:8,lookX:0,lookY:1.2,lookZ:0},
  city:[], trees:[], ruins:[], npcs:[], creatures:[], particles:[], scene:'opening'
})

const qualityLabel = computed(()=>({auto:'Adaptive',low:'Low',medium:'Balanced',high:'High',max:'Maximum'}[quality.value]))
const videoReady = computed(()=>!!videoUrl.value)

function seedWorld(text){
  let s=0; for(const c of text) s=(s*31+c.charCodeAt(0))>>>0
  worldSeed.value=s||12345
  const rnd=()=>{ s=(1664525*s+1013904223)>>>0; return s/4294967296 }
  const w={...world.value, city:[],trees:[],ruins:[],npcs:[],creatures:[],particles:[],scene:'opening'}
  for(let i=0;i<28;i++) w.city.push({x:(rnd()-.5)*26,z:(rnd()-.5)*24,h:1+rnd()*5,w:1.5+rnd()*2.8,d:1.5+rnd()*2.8,roof:rnd()})
  for(let i=0;i<42;i++) w.trees.push({x:(rnd()-.5)*34,z:(rnd()-.5)*30,s:.5+rnd()*1.3})
  for(let i=0;i<7;i++) w.ruins.push({x:(rnd()-.5)*30,z:(rnd()-.5)*28,s:1+rnd()*2.5})
  for(let i=0;i<8;i++) w.npcs.push({x:(rnd()-.5)*18,z:(rnd()-.5)*18,phase:rnd()*6.28})
  for(let i=0;i<4;i++) w.creatures.push({x:(rnd()-.5)*20,z:(rnd()-.5)*20,phase:rnd()*6.28,s:.8+rnd()*.7})
  world.value=w
}

function project(x,y,z){
  const cam=world.value.camera, dx=x-cam.x, dz=z-cam.z, dy=y-cam.y
  const yaw=Math.atan2(cam.lookX-cam.x,cam.lookZ-cam.z)
  const cx=Math.cos(yaw), sx=Math.sin(yaw), vz=dx*sx+dz*cx, vx=dx*cx-dz*sx
  const depth=Math.max(.35,vz), f=Math.min(canvas.value.width,canvas.value.height)*.72/depth
  return {x:canvas.value.width/2+vx*f,y:canvas.value.height/2-dy*f,scale:f,depth}
}
function poly(points,fill,stroke){ctx.beginPath(); points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.stroke()}}
function cube(o,base){
  const p=project(o.x,o.y,o.z), p2=project(o.x,o.y+o.h,o.z), w=o.w*p.scale, d=o.d*p.scale*.42
  const top={x:p.x,y:p2.y}, left={x:p.x-w/2,y:p.y}, right={x:p.x+w/2,y:p.y}
  poly([p2, {x:top.x+w/2,y:top.y+d*.15},{x:top.x,y:top.y+d},{x:top.x-w/2,y:top.y+d}],base)
  poly([{x:p.x-w/2,y:p.y},{x:p.x,y:p.y+d*.5},{x:p.x,y:p2.y+d},{x:p.x-w/2,y:p2.y}], 'rgba(20,28,45,.95)')
  poly([{x:p.x,y:p.y+d*.5},{x:p.x+w/2,y:p.y},{x:p.x+w/2,y:p2.y},{x:p.x,y:p2.y+d}], 'rgba(55,70,100,.95)')
  poly([p2,{x:p.x+w/2,y:p2.y},{x:p.x+w/2,y:p2.y+d*.15},{x:p.x,y:p2.y+d},{x:p.x-w/2,y:p2.y}],base)
}
function humanoid(x,z,scale,phase,color){
  const bob=Math.sin(world.value.time*7+phase)*.05, p=project(x,1.25+bob,z), s=p.scale*scale*.38
  ctx.save(); ctx.translate(p.x,p.y); ctx.globalAlpha=Math.max(.35,Math.min(1,1/p.depth*18));
  ctx.fillStyle='rgba(0,0,0,.25)';ctx.beginPath();ctx.ellipse(0,0,s*1.2,s*.25,0,0,Math.PI*2);ctx.fill()
  ctx.fillStyle=color;ctx.beginPath();ctx.ellipse(0,-s*1.55,s*.55,s*.7,0,0,Math.PI*2);ctx.fill()
  ctx.fillStyle='rgba(235,220,210,.98)';ctx.beginPath();ctx.arc(0,-s*2.15,s*.43,0,Math.PI*2);ctx.fill()
  ctx.fillStyle='rgba(25,18,35,.95)';ctx.beginPath();ctx.arc(-s*.08,-s*2.38,s*.5,Math.PI,Math.PI*2);ctx.fill()
  ctx.strokeStyle=color;ctx.lineWidth=Math.max(2,s*.18);ctx.lineCap='round'
  const swing=Math.sin(world.value.time*8+phase)*s*.35
  ctx.beginPath();ctx.moveTo(-s*.38,-s*1.5);ctx.lineTo(-s*.65+swing,-s*.75);ctx.moveTo(s*.38,-s*1.5);ctx.lineTo(s*.65-swing,-s*.75);ctx.stroke()
  ctx.beginPath();ctx.moveTo(-s*.2,-s*.7);ctx.lineTo(-s*.28+swing*.35,0);ctx.moveTo(s*.2,-s*.7);ctx.lineTo(s*.28-swing*.35,0);ctx.stroke();ctx.restore()
}
function creature(c){
  const p=project(c.x,1.8+Math.sin(world.value.time*3+c.phase)*.25,c.z),s=p.scale*c.s*.5
  ctx.save();ctx.translate(p.x,p.y);ctx.fillStyle='rgba(0,0,0,.22)';ctx.beginPath();ctx.ellipse(0,s*.65,s*1.2,s*.25,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='rgba(132,91,205,.9)';ctx.beginPath();ctx.ellipse(0,0,s*1.05,s*.65,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='rgba(230,215,255,.95)';ctx.beginPath();ctx.arc(s*.7,-s*.2,s*.3,0,Math.PI*2);ctx.fill();ctx.strokeStyle='rgba(210,170,255,.65)';ctx.lineWidth=s*.12;ctx.beginPath();ctx.moveTo(-s*.5,-s*.2);ctx.lineTo(-s*1.35,-s*.8);ctx.moveTo(-s*.25,-s*.25);ctx.lineTo(-s*1.1,s*.2);ctx.stroke();ctx.restore()
}
function render(){
  if(!canvas.value) return
  const dpr=Math.min(devicePixelRatio||1, quality.value==='low'?1:quality.value==='max'?2:1.5)
  const rect=canvas.value.getBoundingClientRect(); if(canvas.value.width!==Math.floor(rect.width*dpr)){canvas.value.width=Math.floor(rect.width*dpr);canvas.value.height=Math.floor(rect.height*dpr)}
  ctx=canvas.value.getContext('2d'); const W=canvas.value.width,H=canvas.value.height
  const t=world.value.time, horizon=H*.45
  const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#071329');sky.addColorStop(.48,'#314e86');sky.addColorStop(1,'#10182c');ctx.fillStyle=sky;ctx.fillRect(0,0,W,H)
  ctx.fillStyle='rgba(255,220,160,.85)';ctx.beginPath();ctx.arc(W*.78,H*.19,Math.min(W,H)*.055,0,Math.PI*2);ctx.fill()
  ctx.fillStyle='rgba(80,100,135,.35)';for(let i=0;i<9;i++){ctx.beginPath();ctx.ellipse(W*(.05+i*.12),horizon-25-(i%3)*12,80+(i%4)*30,20,0,0,Math.PI*2);ctx.fill()}
  ctx.fillStyle='#162338';ctx.fillRect(0,horizon,W,H-horizon)
  const grid=quality.value==='low'?14:quality.value==='medium'?20:30
  ctx.strokeStyle='rgba(100,145,190,.12)';for(let i=-grid;i<=grid;i++){const a=project(i,0,-grid),b=project(i,0,grid);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}
  const objects=[]
  for(const b of world.value.city) objects.push({d:project(b.x,0,b.z).depth,fn:()=>cube({...b,y:0},b.roof>.7?'#76548f':b.roof>.35?'#4e668e':'#456b78')})
  for(const r of world.value.ruins) objects.push({d:project(r.x,0,r.z).depth,fn:()=>cube({x:r.x,z:r.z,y:0,h:r.s*2,w:r.s*.7,d:r.s*.7},'#536b72')})
  objects.sort((a,b)=>b.d-a.d);for(const o of objects)o.fn()
  for(const tr of world.value.trees){const p=project(tr.x,1.1*tr.s,tr.z),s=p.scale*.45*tr.s;ctx.fillStyle='#4d3a32';ctx.fillRect(p.x-s*.12,p.y,s*.24,s*1.1);ctx.fillStyle='#315f55';ctx.beginPath();ctx.arc(p.x,p.y,s*.7,0,Math.PI*2);ctx.fill()}
  for(const n of world.value.npcs) humanoid(n.x,n.z,.75,n.phase,'#6e8ee8')
  for(const c of world.value.creatures) creature(c)
  humanoid(world.value.hero.x,world.value.hero.z,1.25,world.value.hero.phase,'#d18a58')
  if(world.value.weather>.5){ctx.fillStyle='rgba(170,205,255,.35)';for(let i=0;i<70;i++){const x=(i*83+world.value.time*180)%W,y=(i*47+world.value.time*420)%H;ctx.fillRect(x,y,1,10)}}
  ctx.fillStyle='rgba(255,255,255,.9)';ctx.font=`${Math.max(12,W/80)}px system-ui`;ctx.fillText(world.value.title,24,34)
  ctx.fillStyle='rgba(180,210,255,.7)';ctx.fillText(`${qualityLabel.value} • ${rendererLabel.value}`,24,58)
  frames++;const now=performance.now();if(now-fpsTime>800){fps.value=Math.round(frames*1000/(now-fpsTime));frames=0;fpsTime=now}
}
function loop(now){const dt=Math.min(.05,(now-lastFrame)/1000);lastFrame=now;if(isPlaying.value){world.value.time=(world.value.time+dt*.06)%1;world.value.hero.phase+=dt*5;world.value.hero.x=Math.sin(world.value.time*6)*2;world.value.hero.z=Math.cos(world.value.time*4)*2}render();raf=requestAnimationFrame(loop)}

async function detectGpu(){
  if(navigator.gpu){try{const a=await navigator.gpu.requestAdapter();rendererLabel.value=a?'WebGPU available':'WebGL fallback';return}catch{}}
  rendererLabel.value='WebGL/Canvas fallback'
}
function generateGame(){isGenerating.value=true;status.value='Generating shared 3D world…';videoUrl.value='';seedWorld(prompt.value);setTimeout(()=>{isGenerating.value=false;mode.value='game';isPlaying.value=true;status.value='Game ready — same world can now drive the cinematic renderer';},700)}
function generateCinematic(){isGenerating.value=true;status.value='Directing cinematic from the shared world…';mode.value='cinematic';isPlaying.value=true;seedWorld(prompt.value);setTimeout(async()=>{await renderVideo();isGenerating.value=false;status.value=videoReady.value?'Cinematic rendered':'Video recording unavailable in this WebView';},400)}
function startInteractive(){seedWorld(prompt.value);mode.value='interactive';isPlaying.value=true;status.value='Interactive cinematic mode — your input changes the shared scene'}
function chooseQuality(q){quality.value=q;localStorage.setItem('nova-quality',q)}
async function renderVideo(){
  if(!canvas.value?.captureStream || !window.MediaRecorder){status.value='This WebView does not expose MediaRecorder';return}
  const stream=canvas.value.captureStream(30); chunks=[]
  const mimeTypes=['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'].filter(MediaRecorder.isTypeSupported)
  if(!mimeTypes.length){status.value='No supported video encoder found';return}
  videoMime.value=mimeTypes[0]; recorder=new MediaRecorder(stream,{mimeType:mimeTypes[0],videoBitsPerSecond:5_000_000});
  recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)}
  recorder.onstop=()=>{videoBlob.value=new Blob(chunks,{type:videoMime.value});if(videoUrl.value)URL.revokeObjectURL(videoUrl.value);videoUrl.value=URL.createObjectURL(videoBlob.value);nextTick(()=>videoPreview.value?.play().catch(()=>{}))}
  recorder.start(); const start=performance.now();
  const duration=7000;
  const oldPlaying=isPlaying.value;isPlaying.value=true
  await new Promise(resolve=>{const step=()=>{const p=Math.min(1,(performance.now()-start)/duration);world.value.hero.x=Math.sin(p*Math.PI*4)*3;world.value.hero.z=Math.cos(p*Math.PI*3)*3;world.value.time=p;world.value.camera.x=Math.sin(p*Math.PI*2)*3;world.value.camera.z=8+Math.cos(p*Math.PI*2)*2;render();if(p<1)requestAnimationFrame(step);else resolve()};step()})
  recorder.stop();await new Promise(r=>recorder.addEventListener('stop',r,{once:true}));isPlaying.value=oldPlaying
}
function downloadVideo(){if(!videoUrl.value)return;const a=document.createElement('a');a.href=videoUrl.value;a.download='nova-cinematic.webm';a.click()}
function askMic(){
  const bridge=window.NovaVoice
  if(bridge?.requestMicrophone){bridge.requestMicrophone();micState.value='System permission requested';return}
  navigator.mediaDevices?.getUserMedia?.({audio:true}).then(s=>{s.getTracks().forEach(t=>t.stop());micState.value='Granted'}).catch(()=>{micState.value='Denied / unavailable'})
}
function openAndroidSettings(){if(window.NovaVoice?.openAppSettings)window.NovaVoice.openAppSettings();else window.open('app-settings:','_self')}
function onKey(e){if(mode.value==='game'||mode.value==='interactive'){if(e.key==='ArrowLeft'||e.key==='a')world.value.hero.x-=.4;if(e.key==='ArrowRight'||e.key==='d')world.value.hero.x+=.4;if(e.key==='ArrowUp'||e.key==='w')world.value.hero.z-=.4;if(e.key==='ArrowDown'||e.key==='s')world.value.hero.z+=.4}}
onMounted(()=>{quality.value=localStorage.getItem('nova-quality')||'auto';detectGpu();nextTick(()=>{raf=requestAnimationFrame(loop)});window.addEventListener('keydown',onKey)})
onBeforeUnmount(()=>{cancelAnimationFrame(raf);window.removeEventListener('keydown',onKey);if(videoUrl.value)URL.revokeObjectURL(videoUrl.value)})
</script>

<template>
  <main class="app">
    <header><div><span class="orb"></span><strong>NOVA</strong><small> SHARED WORLD STUDIO</small></div><button class="dots" @click="settingsOpen=!settingsOpen" aria-label="Settings">⋮</button></header>
    <section class="hero"><div class="badge">TEXT / VOICE → GAME + CINEMATIC</div><h1>Build the world once.<br><span>Play it. Film it.</span></h1><p>NOVA turns your idea into one shared 3D world that can drive gameplay, interactive scenes and recorded anime-style cinematics.</p></section>
    <section class="panel prompt"><textarea v-model="prompt" aria-label="Game idea"></textarea><div class="row"><button class="primary" :disabled="isGenerating" @click="generateGame">🎮 Generate Game</button><button @click="generateCinematic">🎬 Generate Video</button><button @click="startInteractive">◉ Interactive Video</button></div></section>
    <section class="stage"><canvas ref="canvas"></canvas><div class="stagebar"><span>{{status}}</span><span>{{fps}} FPS</span></div><div v-if="mode!=='studio'" class="controls"><button @click="world.hero.z-=.5">▲</button><div><button @click="world.hero.x-=.5">◀</button><button @click="world.hero.z+=.5">▼</button><button @click="world.hero.x+=.5">▶</button></div></div></section>
    <section class="cards"><button :class="{active:mode==='game'}" @click="generateGame"><b>PLAY GAME</b><span>Shared generated world</span></button><button :class="{active:mode==='cinematic'}" @click="generateCinematic"><b>GENERATE VIDEO</b><span>Record a directed cinematic</span></button><button :class="{active:mode==='interactive'}" @click="startInteractive"><b>INTERACTIVE VIDEO</b><span>Play inside the cinematic</span></button></section>
    <section v-if="videoReady" class="videoPanel"><h2>Rendered cinematic</h2><video ref="videoPreview" :src="videoUrl" controls playsinline></video><button class="primary" @click="downloadVideo">Save WebM</button></section>
    <aside v-if="settingsOpen" class="settings"><div class="settingsHead"><h2>Settings & Permissions</h2><button @click="settingsOpen=false">×</button></div><div class="setting"><span>Microphone</span><b>{{micState}}</b><button @click="askMic">Allow / Test</button></div><div class="setting"><span>Android app settings</span><button @click="openAndroidSettings">Open</button></div><div class="setting"><span>Graphics</span><div class="quality"><button v-for="q in ['auto','low','medium','high','max']" :key="q" :class="{sel:quality===q}" @click="chooseQuality(q)">{{q}}</button></div></div><div class="setting"><span>Notifications</span><button @click="notifications=!notifications">{{notifications?'On':'Off'}}</button></div><p class="note">Microphone access is requested only when you use voice. Android controls the final permission state.</p></aside>
  </main>
</template>

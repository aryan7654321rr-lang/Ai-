import fs from 'node:fs';
for (const f of ['index.html','src/App.vue','src/style.css','src/main.js','package.json']) if(!fs.existsSync(f)) throw new Error('Missing '+f)
const app=fs.readFileSync('src/App.vue','utf8');
if(!app.includes('MediaRecorder') || !app.includes('captureStream')) throw new Error('Video renderer missing');
if(!app.includes('Generate Video') || !app.includes('Shared generated world')) throw new Error('Shared world UI missing');
console.log('NOVA smoke test passed')

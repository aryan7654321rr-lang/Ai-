# NOVA-X — Local-First AI Assistant Prototype

NOVA-X is a voice-first, local-first assistant prototype designed around the requirements developed for this project: natural language input, persistent local memory, tolerant text understanding, local tools, game/anime planning, device-aware optimization, and a single simple home screen.

## What is actually working in this repository

- Vue 3 single-screen application structure
- Voice input through Web Speech API when the WebView/browser provides it
- Offline/online status detection
- Local persistent memory using `localStorage`
- Basic language/script detection (Hindi, Chinese, Japanese, Korean, Latin)
- Basic typo/abbreviation normalization
- Local deterministic conversation/intent routing
- Game planning with scenes, systems and device-aware rendering profile
- Chunked anime/video storyboard planning
- Local canvas animation preview
- Device capability collection available to browser/WebView APIs
- Local project JSON export
- Responsive mobile UI
- No paid API key required by the included code
- No cloud GPU required by the included code

## What is intentionally not claimed as finished

The repository does **not** pretend that a tiny web app can provide a frontier LLM, studio-quality text-to-video diffusion, or AAA real-time 3D generation on every low-end phone. Those require additional local model runtimes/native renderers and real-device testing.

The architecture is deliberately designed so those components can be added without replacing the UI or core product flow.

## Run

```bash
npm install
npm run test
npm run dev
```

If your Vue-to-APK repository consumes `App.vue`, `src/main.js`, and `src/style.css`, these files are the primary application payload.

## Test

`npm run test` performs static integration checks on the delivered web application. `python3 -m unittest discover -s tests -v` also runs the original deterministic-core tests.

## Android/device testing

See `docs/DEVICE_TEST.md`. Hardware-dependent items are intentionally left unchecked until tested on a real device.

## Design principle

AI should handle understanding, planning and creative decisions. Deterministic software should handle rendering, animation, storage, encoding and optimization whenever possible. This keeps NOVA local-first and avoids making paid cloud inference a requirement.

<template>
  <div class="app-shell">
    <header class="topbar">
      <div class="brand"><span class="orb"></span><div><b>NOVA-X</b><small>LOCAL-FIRST ASSISTANT</small></div></div>
      <div class="status"><span :class="['dot', online ? 'ok' : 'warn']"></span>{{ online ? 'Internet available' : 'Offline' }}</div>
    </header>

    <main class="main">
      <section v-if="view==='home'" class="home">
        <div class="hero">
          <p class="eyebrow">VOICE • MEMORY • CREATION</p>
          <h1>What should we<br><span>create today?</span></h1>
          <p class="muted">Speak naturally. NOVA tolerates typos, mixed languages and imperfect speech, then routes the task to local tools.</p>
          <div class="command-row">
            <input v-model="prompt" @keyup.enter="runPrompt" placeholder="Try: make a fantasy game with a spirit wolf…" aria-label="NOVA command">
            <button class="mic" @click="toggleMic" :aria-label="listening ? 'Stop listening' : 'Start voice input'">{{ listening ? '■' : '🎙' }}</button>
            <button class="primary" @click="runPrompt">Run</button>
          </div>
          <div v-if="heard" class="heard">Heard: “{{ heard }}”</div>
        </div>
        <div class="quick-grid">
          <button v-for="q in quick" :key="q.label" class="card" @click="useQuick(q.prompt)"><span>{{ q.icon }}</span><b>{{ q.label }}</b><small>{{ q.desc }}</small></button>
        </div>
        <div class="panel summary"><div class="panel-title">NOVA can work locally</div><div class="chips"><span>Chat</span><span>Memory</span><span>Game planning</span><span>Anime/video planning</span><span>PDF</span><span>Device optimization</span><span>Internet research</span></div></div>
      </section>

      <section v-else class="workspace">
        <button class="back" @click="view='home'">← Home</button>
        <div class="workspace-head"><div><p class="eyebrow">{{ titles[view].eyebrow }}</p><h2>{{ titles[view].title }}</h2><p class="muted">{{ titles[view].desc }}</p></div></div>

        <section v-if="view==='chat'" class="chat-panel panel">
          <div class="messages"><div v-for="m in messages" :key="m.id" :class="['msg',m.role]">{{ m.text }}<small v-if="m.source">{{ m.source }}</small></div></div>
          <div class="command-row"><input v-model="chatInput" @keyup.enter="sendChat" placeholder="Ask NOVA anything locally…"><button class="primary" @click="sendChat">Send</button></div>
        </section>

        <section v-if="view==='game'" class="game-work">
          <div class="panel"><label>Game idea</label><textarea v-model="gamePrompt" rows="4"></textarea><div class="row"><select v-model="quality"><option>Recommended</option><option>Balanced</option><option>High</option><option>Maximum</option></select><button class="primary" @click="generateGame">Build plan</button></div></div>
          <div v-if="game" class="panel result"><h3>{{ game.title }}</h3><p>{{ game.summary }}</p><div class="scene-grid"><div v-for="s in game.scenes" :key="s.name" class="scene"><b>{{ s.name }}</b><small>{{ s.visual }} · {{ s.gameplay }}</small></div></div><pre>{{ JSON.stringify(game.deviceProfile,null,2) }}</pre></div>
        </section>

        <section v-if="view==='anime'" class="game-work">
          <div class="panel"><label>Anime/video idea</label><textarea v-model="animePrompt" rows="4"></textarea><div class="row"><input v-model.number="minutes" type="number" min="1" max="30"><button class="primary" @click="generateAnime">Create storyboard</button></div></div>
          <div v-if="anime" class="panel result"><h3>{{ anime.title }}</h3><p>{{ anime.summary }}</p><div class="timeline"><div v-for="c in anime.clips" :key="c.id"><b>Clip {{ c.id }}</b><span>{{ c.duration }}s — {{ c.scene }}</span></div></div><button class="secondary" @click="renderPreview">Render local canvas preview</button><canvas ref="preview" width="720" height="405"></canvas></div>
        </section>

        <section v-if="view==='memory'" class="panel memory"><div class="row"><input v-model="memoryKey" placeholder="Memory name"><input v-model="memoryValue" placeholder="Value"><button class="primary" @click="saveMemory">Save</button></div><div v-for="(v,k) in memories" :key="k" class="memory-row"><b>{{k}}</b><span>{{v}}</span><button @click="removeMemory(k)">×</button></div></section>

        <section v-if="view==='tools'" class="tools-grid">
          <div class="panel"><h3>Text normalizer</h3><textarea v-model="toolText" rows="5" placeholder="Type with mistakes, mixed languages, or missing punctuation"></textarea><button class="primary" @click="normalize">Normalize</button><pre v-if="normalized">{{ normalized }}</pre></div>
          <div class="panel"><h3>Device profile</h3><p>Browser/device information is collected locally.</p><button class="primary" @click="profileDevice">Analyze device</button><pre v-if="device">{{ JSON.stringify(device,null,2) }}</pre></div>
          <div class="panel"><h3>Local export</h3><p>Export your current NOVA project data as JSON.</p><button class="primary" @click="exportProject">Export project</button></div>
        </section>
      </section>
    </main>

    <nav class="nav"><button :class="{active:view==='home'}" @click="view='home'">⌂<small>Home</small></button><button :class="{active:view==='chat'}" @click="view='chat'">◉<small>Chat</small></button><button :class="{active:view==='game'}" @click="view='game'">◇<small>Game</small></button><button :class="{active:view==='anime'}" @click="view='anime'">✦<small>Anime</small></button><button :class="{active:view==='tools'}" @click="view='tools'">⚙<small>Tools</small></button></nav>
  </div>
</template>

<script setup>
import { computed, nextTick, ref } from 'vue'

const view=ref('home'), prompt=ref(''), heard=ref(''), listening=ref(false), online=ref(navigator.onLine)
const chatInput=ref(''), gamePrompt=ref('Create an anime fantasy adventure with a magical forest and an original spirit wolf.'), animePrompt=ref('A cinematic fantasy journey through an enchanted forest with an original spirit wolf.'), minutes=ref(10), quality=ref('Recommended')
const memoryKey=ref(''), memoryValue=ref(''), toolText=ref(''), normalized=ref(''), device=ref(null), game=ref(null), anime=ref(null), preview=ref(null)
const quick=[{icon:'💬',label:'Chat',desc:'Local conversation',prompt:'Hello NOVA, what can you do?'},{icon:'🎮',label:'Create game',desc:'Plan an optimized game',prompt:'Create an anime fantasy game with a magical forest and creatures.'},{icon:'🎬',label:'Make anime',desc:'Build a video storyboard',prompt:'Create a 10 minute cinematic anime fantasy story.'},{icon:'🧠',label:'Remember',desc:'Save a preference',prompt:'remember that my favorite genre is fantasy'}]
const titles={chat:{eyebrow:'LOCAL AI',title:'Talk to NOVA',desc:'A deterministic local assistant layer with persistent memory and error-tolerant intent routing.'},game:{eyebrow:'GAME STUDIO',title:'Build a game',desc:'Create a structured game plan with device-aware rendering settings.'},anime:{eyebrow:'ANIME STUDIO',title:'Create animation',desc:'Generate a chunked storyboard designed for local rendering and assembly.'},memory:{eyebrow:'MEMORY',title:'Your memory',desc:'Stored locally in this browser/app. Nothing is uploaded by this interface.'},tools:{eyebrow:'LOCAL TOOLS',title:'Tools & diagnostics',desc:'Normalization, device profiling and project export.'}}
const messages=ref([{id:1,role:'nova',text:'Hi. I’m NOVA-X. Try a voice command or ask me to create something.',source:'Local'}])
const memories=ref(JSON.parse(localStorage.getItem('nova_memory')||'{}'))
function persist(){localStorage.setItem('nova_memory',JSON.stringify(memories.value))}
function saveMemory(){if(memoryKey.value.trim()&&memoryValue.value.trim()){memories.value[memoryKey.value.trim()]=memoryValue.value.trim();persist();memoryKey.value='';memoryValue.value=''}}
function removeMemory(k){delete memories.value[k];persist()}
function detectLanguage(t){if(/[\u0900-\u097F]/.test(t))return 'Hindi'; if(/[\u4E00-\u9FFF]/.test(t))return 'Chinese'; if(/[\u3040-\u30FF]/.test(t))return 'Japanese'; if(/[\uAC00-\uD7AF]/.test(t))return 'Korean'; return 'English/Latin'}
function normalizeText(t){let x=t.trim().replace(/\s+/g,' ').replace(/\bplz\b/gi,'please').replace(/\bu\b/gi,'you').replace(/\bur\b/gi,'your');return {text:x,language:detectLanguage(x),confidence:x.length?0.9:0}}
function respond(t){const n=normalizeText(t), low=n.text.toLowerCase(); if(/remember|याद/.test(low)){const m=n.text.match(/remember(?: that)?\s+(.+)/i); if(m){memories.value.last_request=m[1];persist();return `I saved that locally: ${m[1]}.`}} if(/game|खेल/.test(low))return 'I can turn this into a game plan. Open Game Studio to generate scenes, systems and device optimization.'; if(/anime|video|movie/.test(low))return 'I can create a chunked animation storyboard. Open Anime Studio to generate clips and render a local preview.'; if(/what can|help/.test(low))return 'I can chat, remember approved information, normalize imperfect text, plan games and anime, inspect device capability, and export local project data.'; return `I understood this as ${JSON.stringify(n.text)} (${n.language}). I can answer simple local requests without an API; advanced knowledge can be connected to a local model later.`}
function sendChat(){if(!chatInput.value.trim())return;const t=chatInput.value;messages.value.push({id:Date.now(),role:'user',text:t});messages.value.push({id:Date.now()+1,role:'nova',text:respond(t),source:'Local'});chatInput.value=''}
function useQuick(q){prompt.value=q;runPrompt()}
function runPrompt(){const t=prompt.value.trim();if(!t)return;if(/game|खेल/i.test(t)){gamePrompt.value=t;view.value='game';generateGame()}else if(/anime|video|movie/i.test(t)){animePrompt.value=t;view.value='anime';generateAnime()}else if(/remember|याद/i.test(t)){respond(t);view.value='memory'}else{chatInput.value=t;view.value='chat';sendChat()}prompt.value=''}
function generateGame(){const low=quality.value==='Recommended';game.value={title:'NOVA Generated Fantasy Adventure',summary:`A structured plan derived from: ${gamePrompt.value}`,deviceProfile:{quality:quality.value,rendering:low?'optimized 3D + 2.5D':'3D profile',streaming:true,lod:true,bakedLighting:true,target:'device-dependent'},scenes:[{name:'Enchanted Forest',visual:'layered terrain, trees, fog',gameplay:'exploration + NPCs'},{name:'Spirit Village',visual:'stylized buildings, particles',gameplay:'quests + dialogue'},{name:'Moonlit Arena',visual:'baked lights, VFX',gameplay:'combat + boss'}]}}
function generateAnime(){const count=Math.max(1,Math.ceil(minutes.value*60/15));const scenes=['Forest arrival','Spirit village','Ancient ruins','Creature encounter','Climactic battle','Quiet ending'];anime.value={title:'NOVA Local Animation Plan',summary:`${minutes.value}-minute project split into ${count} short renderable clips.`,clips:Array.from({length:Math.min(count,40)},(_,i)=>({id:i+1,duration:15,scene:scenes[i%scenes.length]}))}}
async function renderPreview(){await nextTick();const c=preview.value;if(!c)return;const x=c.getContext('2d');let f=0;const draw=()=>{x.clearRect(0,0,c.width,c.height);x.fillStyle='#10192b';x.fillRect(0,0,c.width,c.height);x.fillStyle='#1e6b4d';x.beginPath();x.moveTo(0,330);x.quadraticCurveTo(220,220,420,330);x.quadraticCurveTo(580,230,720,320);x.fill();x.fillStyle='#f3d36a';x.beginPath();x.arc(580,90,45,0,Math.PI*2);x.fill();x.fillStyle='#fff';x.font='28px sans-serif';x.fillText('NOVA local animation preview',30,45);x.fillText('clip '+(Math.floor(f/20)%Math.max(1,anime.value?.clips.length||1)+1),30,385);f++;if(f<120)requestAnimationFrame(draw)};draw()}
function normalize(){normalized.value=JSON.stringify(normalizeText(toolText.value),null,2)}
function profileDevice(){device.value={userAgent:navigator.userAgent,language:navigator.language,cores:navigator.hardwareConcurrency||'unknown',memoryGB:navigator.deviceMemory||'unknown',screen:`${screen.width}x${screen.height}`,online:navigator.onLine,notes:'Browser APIs are estimates; real GPU/RAM/thermal tests require Android hardware.'}}
function exportProject(){const data={version:'0.2.0',memories:memories.value,game:game.value,anime:anime.value,generatedAt:new Date().toISOString()};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='nova-project.json';a.click();URL.revokeObjectURL(a.href)}
function toggleMic(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){heard.value='SpeechRecognition is not available in this WebView. Use typed input or a WebView/native speech bridge.';return}if(listening.value)return;const r=new SR();r.lang=navigator.language||'en-US';r.interimResults=false;r.maxAlternatives=3;listening.value=true;r.onresult=e=>{heard.value=e.results[0][0].transcript;prompt.value=heard.value;listening.value=false};r.onerror=e=>{heard.value=`Voice input error: ${e.error}`;listening.value=false};r.onend=()=>listening.value=false;r.start()}
window.addEventListener('online',()=>online.value=true);window.addEventListener('offline',()=>online.value=false)
</script>

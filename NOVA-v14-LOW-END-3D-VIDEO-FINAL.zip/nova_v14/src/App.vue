<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { DEFAULT_GAME_PROMPT } from './prompts/gamePrompt';
import { DEFAULT_VIDEO_PROMPT } from './prompts/videoPrompt';
import { chooseBestAssets, buildAcquisitionPlan, cleanupPlan } from './services/assetResolver';
import { DEVICE_PROFILES, buildQualityPlan, chooseMobileVariant } from './services/mobileQuality';
import { buildVideoRenderPlan, VIDEO_RENDERER } from './services/videoRenderer';

const panel = ref(null);
const menu = ref(false);
const device = ref(localStorage.getItem('nova.device') || 'low');
const gamePrompt = ref(localStorage.getItem('nova.gamePrompt') || DEFAULT_GAME_PROMPT);
const videoPrompt = ref(localStorage.getItem('nova.videoPrompt') || DEFAULT_VIDEO_PROMPT);
const notice = ref('NOVA READY');
const selectedAssets = ref([]);
const acquisition = ref([]);
const cleanup = ref([]);
const qualityPlan = ref(buildQualityPlan(DEVICE_PROFILES.low));
const videoPlan = ref(buildVideoRenderPlan());
const showDetails = ref(false);
const runtimeStatus = ref('3D RUNTIME HOST READY');
const assetSourceStatus = ref('AUTHORIZED ASSET SOURCES ONLY');
const selectedSource = ref('Unity-compatible / authorized connector');

const currentProfile = computed(() => DEVICE_PROFILES[device.value]);
const runtimeBadges = computed(() => [
  `${currentProfile.value.targetFps} FPS TARGET`,
  `${currentProfile.value.textureBudgetMB} MB TEXTURE`,
  `${currentProfile.value.textureMaxSize}px MAX TEX`,
  `${Math.round(currentProfile.value.resolutionScale * 100)}% BASE RES`
]);

function open(p) {
  panel.value = p;
  menu.value = false;
  showDetails.value = false;
  notice.value = p === 'game' ? '3D GAME RUNTIME READY' : p === 'video' ? 'VIDEO RENDERER READY' : 'IMAGE STUDIO READY';
}
function closePanel() { panel.value = null; }
function savePrompt(kind) {
  localStorage.setItem(kind === 'game' ? 'nova.gamePrompt' : 'nova.videoPrompt', kind === 'game' ? gamePrompt.value : videoPrompt.value);
  notice.value = 'Prompt saved';
}
function resetPrompt(kind) {
  if (kind === 'game') gamePrompt.value = DEFAULT_GAME_PROMPT;
  else videoPrompt.value = DEFAULT_VIDEO_PROMPT;
  notice.value = 'Default prompt restored';
}
function resolveAssets() {
  const candidates = [
    { id:'unity-hero-high', name:'High-detail hero character', source:'Authorized Unity-compatible connector', sourceType:'unity-package', license:'commercial-license', modificationAllowed:true, redistributionAllowed:false, quality:98, mobileCost:48, category:'character', tags:['hero','realistic','rigged','high-detail'], cached:true, variants:[{id:'mobile',mobile:true},{id:'balanced',mobile:true},{id:'high'}] },
    { id:'unity-creature-cute', name:'Cute creature companion', source:'Authorized Unity-compatible connector', sourceType:'unity-package', license:'commercial-license', modificationAllowed:true, redistributionAllowed:false, quality:94, mobileCost:34, category:'creature', tags:['cute','creature','rigged','animated'], cached:true, variants:[{id:'mobile',mobile:true},{id:'balanced',mobile:true},{id:'high'}] },
    { id:'unity-city', name:'Detailed modular city world', source:'Authorized Unity-compatible connector', sourceType:'unity-package', license:'commercial-license', modificationAllowed:true, redistributionAllowed:false, quality:96, mobileCost:58, category:'environment', tags:['city','modular','realistic','detailed'], cached:true, variants:[{id:'mobile',mobile:true},{id:'balanced',mobile:true},{id:'high'}] },
    { id:'unity-vehicle', name:'Mobile-optimized vehicle set', source:'Authorized Unity-compatible connector', sourceType:'unity-package', license:'commercial-license', modificationAllowed:true, redistributionAllowed:false, quality:91, mobileCost:27, category:'vehicle', tags:['vehicle','mobile','optimized'], cached:false, variants:[{id:'mobile',mobile:true},{id:'balanced',mobile:true}] },
    { id:'unknown', name:'Unverified internet download', source:'Unknown website', license:'unknown', modificationAllowed:false, quality:100, mobileCost:20, category:'environment', tags:['detailed'] }
  ];
  const requirements = {
    character:{slot:'hero',category:'character',hero:true,tags:['hero','realistic','rigged','high-detail'],mobileCostBudget:52},
    creature:{slot:'creature',category:'creature',hero:true,tags:['cute','creature','rigged','animated'],mobileCostBudget:40},
    environment:{slot:'near-world',category:'environment',nearCamera:true,tags:['city','modular','realistic','detailed'],mobileCostBudget:62},
    vehicle:{slot:'vehicle',category:'vehicle',tags:['vehicle','mobile','optimized'],mobileCostBudget:32}
  };
  selectedAssets.value = chooseBestAssets(candidates, requirements).map(a => ({...a, variant: chooseMobileVariant(a, currentProfile.value)?.id || 'source'}));
  acquisition.value = buildAcquisitionPlan(candidates, requirements);
  selectedSource.value = 'Authorized Unity-compatible connector';
  assetSourceStatus.value = 'RIGHTS VERIFIED / BEST 3D MATCHES SELECTED';
  runtimeStatus.value = '3D ASSET PACKAGE READY FOR RUNTIME';
  notice.value = `${selectedAssets.value.length} high-quality 3D assets selected`;
}
function optimizeScene() {
  qualityPlan.value = buildQualityPlan(currentProfile.value);
  runtimeStatus.value = `${currentProfile.value.label.toUpperCase()} PROFILE ACTIVE`;
  notice.value = `Quality budget optimized for ${currentProfile.value.label}`;
}
function runCleanup() {
  const source = selectedAssets.value.map((a, i) => ({...a, active:i < 2, visible:true, distance:i * 30, cached:true}));
  source.push({id:'unused-temp',name:'Unused conversion temp',visible:false,cached:true,license:'user-owned',modificationAllowed:true});
  source.push({id:'blocked-download',name:'Blocked unverified asset',visible:false,cached:false,license:'unknown'});
  cleanup.value = cleanupPlan(source,{nearDistance:60,prefetchDistance:220});
  notice.value = 'UNUSED CONTENT EVICTED';
}
function refreshVideoPlan() {
  videoPlan.value = buildVideoRenderPlan({durationMinutes:10,shotSeconds:6});
  notice.value = `${videoPlan.value.estimatedShots} cinematic shots planned`;
}
function generate(kind) {
  savePrompt(kind);
  if (kind === 'game') {
    resolveAssets(); optimizeScene();
    notice.value = '3D build specification refreshed';
  } else {
    refreshVideoPlan();
    notice.value = 'Video shot renderer plan queued';
  }
}

onMounted(() => { resolveAssets(); optimizeScene(); runCleanup(); refreshVideoPlan(); });
watch(device, () => { localStorage.setItem('nova.device', device.value); optimizeScene(); resolveAssets(); });
onBeforeUnmount(() => {});
</script>

<template>
  <main class="app-shell">
    <header class="topbar">
      <div class="brand-wrap"><div class="nova-mark">N</div><div class="brand">NOVA</div></div>
      <div class="top-actions"><div class="status">{{ notice }}</div><button class="dots" @click="menu=!menu" aria-label="Open NOVA menu">•••</button></div>
    </header>

    <div v-if="menu" class="menu">
      <button @click="open('image')"><span>IMAGE</span><small>Independent image studio</small></button>
      <button @click="open('video')"><span>VIDEO / ANIME</span><small>Dedicated cinematic video renderer</small></button>
      <button @click="open('game')"><span>GAME</span><small>High-detail 3D runtime</small></button>
    </div>

    <section v-if="!panel" class="home">
      <div class="orbital"><div class="orbital-ring ring-a"></div><div class="orbital-ring ring-b"></div><div class="orbital-line"></div><button class="core" @click="open('game')"><span>N</span><small>NOVA</small></button></div>
      <div class="home-caption">HIGH-QUALITY CREATIVE RUNTIME</div>
      <div class="showcase-row">
        <button class="showcase-card active" @click="open('game')"><div class="scene-thumb city-thumb"><span>3D GAME</span></div><strong>GAME WORLD</strong><small>Asset-first 3D runtime</small></button>
        <button class="showcase-card" @click="open('video')"><div class="scene-thumb anime-thumb"><span>VIDEO</span></div><strong>VIDEO / ANIME</strong><small>Separate cinematic renderer</small></button>
        <button class="showcase-card" @click="open('image')"><div class="scene-thumb image-thumb"><span>IMAGE</span></div><strong>IMAGE STUDIO</strong><small>Independent still-image pipeline</small></button>
      </div>
    </section>

    <section v-else class="workspace">
      <div class="workspace-head"><button class="back" @click="closePanel">←</button><div><div class="eyebrow">NOVA / {{ panel.toUpperCase() }}</div><h1>{{ panel==='game'?'3D Game Runtime':panel==='video'?'Video / Anime Renderer':'Image Studio' }}</h1><p v-if="panel==='game'">The installed game and this preview use the same optimized 3D asset package.</p><p v-else-if="panel==='video'">A separate shot-based renderer designed for cinematic anime/video production.</p><p v-else>Independent still-image pipeline.</p></div></div>

      <div v-if="panel==='game'" class="game-layout">
        <article class="game-screen card">
          <div class="game-toolbar"><span class="live-dot"></span><b>ACTUAL 3D RUNTIME SURFACE</b><span class="toolbar-spacer"></span><span>{{ currentProfile.label }}</span></div>
          <div class="runtime3d">
            <div class="runtime-grid"></div><div class="runtime-horizon"></div>
            <div class="runtime-message"><div class="runtime-icon">3D</div><h2>High-detail 3D game runtime</h2><p>This surface is reserved for the optimized 3D build: selected characters, creatures, environments, materials, animations, lighting, collision and streamed world zones.</p><span>{{ runtimeStatus }}</span></div>
            <div class="runtime-corners"><i>PLAYER DETAIL: HIGH</i><i>NEAR WORLD: HIGH</i><i>FAR WORLD: STREAMED</i></div>
          </div>
          <div class="runtime-badges"><span v-for="b in runtimeBadges" :key="b">{{b}}</span></div>
        </article>

        <aside class="game-side">
          <article class="card compact"><div class="pill">ASSET-FIRST 3D</div><h2>Best permitted assets, combined</h2><p>NOVA selects existing compatible assets instead of replacing them with generated primitives. Unity-compatible content is used only through an authorized path and its license rules.</p><div class="asset-status"><span class="live-dot"></span>{{ assetSourceStatus }}</div><button class="primary" @click="resolveAssets">Re-evaluate assets</button></article>
          <article class="card compact"><h2>Selected 3D package</h2><ul class="asset-list"><li v-for="a in selectedAssets" :key="a.id"><span>{{a.name}}<small>{{a.variant}} variant</small></span><em class="active">{{Math.round(a.score)}} FIT</em></li></ul></article>
          <article class="card compact"><h2>Low-end phone quality</h2><select v-model="device"><option value="low">Low-end Android</option><option value="balanced">Balanced Android</option><option value="high">High Android</option></select><div class="metric-grid"><div><b>{{currentProfile.targetFps}}</b><span>FPS target</span></div><div><b>{{currentProfile.textureBudgetMB}}</b><span>MB texture</span></div><div><b>{{currentProfile.maxActiveLights}}</b><span>active lights</span></div><div><b>{{currentProfile.shadowDistance}}</b><span>shadow meters</span></div></div><button @click="optimizeScene">Optimize scene budget</button><button @click="runCleanup">Evict unused content</button></article>
          <article class="card compact"><h2>Quality priority</h2><ol class="priority"><li>Hero character</li><li>Nearby characters & creatures</li><li>Near-camera environment</li><li>Landmarks</li><li>Distance</li></ol></article>
          <article v-if="showDetails" class="card compact"><h2>Acquisition</h2><ul class="asset-list"><li v-for="a in acquisition" :key="a.assetId"><span>{{a.assetId}}</span><em>{{a.action}}</em></li></ul><h2>Cleanup</h2><ul class="asset-list"><li v-for="a in cleanup" :key="a.id"><span>{{a.name}}</span><em :class="a.state.toLowerCase()">{{a.state}}</em></li></ul></article>
          <button @click="showDetails=!showDetails">{{showDetails?'Hide':'Show'}} build details</button>
        </aside>
      </div>

      <div v-if="panel==='video'" class="video-layout">
        <article class="card video-stage"><div class="pill">{{ VIDEO_RENDERER.id }}</div><h2>Dedicated cinematic video renderer</h2><div class="video-preview"><div class="film-frame"><span>SHOT 01</span><b>ANIME / CINEMATIC</b></div><div class="shot-strip"><i v-for="n in 8" :key="n">{{String(n).padStart(2,'0')}}</i></div></div><div class="renderer-chain"><span v-for="step in VIDEO_RENDERER.pipeline" :key="step">{{step}}</span></div></article>
        <aside class="game-side"><article class="card compact"><h2>10-minute episode</h2><p>Shot-first rendering keeps memory and compute bounded. Failed shots are repaired individually instead of re-rendering the entire episode.</p><div class="metric-grid"><div><b>{{videoPlan.estimatedShots}}</b><span>shots</span></div><div><b>{{videoPlan.shotSeconds}}s</b><span>shot target</span></div><div><b>10m</b><span>episode</span></div></div><button class="primary" @click="refreshVideoPlan">Rebuild shot plan</button></article><article class="card compact"><h2>Video prompt</h2><textarea v-model="videoPrompt"></textarea><div class="row"><button @click="resetPrompt('video')">Restore</button><button @click="savePrompt('video')">Save</button><button class="primary" @click="generate('video')">Queue render</button></div></article></aside>
      </div>

      <div v-if="panel==='image'" class="studio-grid"><article class="card wide"><div class="pill">IMAGE STUDIO</div><h2>Independent image pipeline</h2><div class="image-stage"><div class="image-stage-orb">N</div><div><strong>Still images stay separate from both renderers.</strong><p>No game-runtime or video-renderer logic is reused here.</p></div></div></article></div>
    </section>
  </main>
</template>

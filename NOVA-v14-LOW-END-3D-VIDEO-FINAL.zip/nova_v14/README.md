# NOVA v14 — Low-End High-Quality Runtime Architecture

NOVA v14 keeps three rendering systems genuinely separate:

1. **Game Runtime** — fully 3D, asset-first, interactive mobile game runtime.
2. **Video/Anime Renderer** — dedicated shot-based cinematic renderer.
3. **Image Studio** — independent still-image pipeline.

## Game philosophy

NOVA's normal game workflow does **not** generate replacement 3D assets. It searches authorized/user-owned/reuse-permitted sources, verifies rights, scores compatibility, selects the strongest assets, converts them when permitted, and assembles them into an original 3D game.

Unity-compatible assets can be supported through an authorized connector/import path. The project does not scrape or redistribute Unity Asset Store content.

## Low-end Android strategy

The default profile is Low-end Android. Quality is protected where the player notices it most:

**hero → nearby characters/creatures → near-camera environment → landmarks → distance**

The runtime reduces invisible work first, then far geometry/textures, shadows, crowds and secondary effects, using dynamic resolution only as a later quality-preserving step.

The mobile quality planner controls texture budgets, maximum texture size, active lights, shadow distance, high-detail object limits, resolution scale and zone streaming policy.

## Video renderer

The video system is not a game renderer. It has its own pipeline:

script → character/world bible → storyboard → shot plan → keyframes → animation → temporal consistency → camera/compositing → lighting/effects → voice/dialogue → QC → edit.

It uses short shots and repairs failed shots individually so memory and compute stay bounded. This is especially important when NOVA is being controlled from a low-end phone.

## Important implementation boundary

This repository is the UI/orchestration/runtime architecture. It does not bundle copyrighted third-party Unity assets and does not pretend that a browser canvas is the finished high-detail 3D game. A production native runtime/authorized asset connector is required to load the selected Unity-compatible asset package.

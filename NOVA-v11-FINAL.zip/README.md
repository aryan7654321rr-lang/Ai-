# NOVA v11 — Studio Foundation

This version folds the requested fixes into one mobile-first NOVA UI foundation.

## Included
- Clean home screen with the NOVA core as the primary wake/open control.
- Three-dot menu only for Image Renderer, Video/Anime Studio, and Game Generation.
- Separate Image, Video/Anime, and Game pipelines in code and UI.
- Default Game Director prompt prefilled on first use.
- Default 10-minute Anime Studio prompt prefilled on first use.
- Game quality policy prioritizes hero and visible/near assets.
- Device profiles for low-end, balanced and high Android targets.
- Unused-content remover with ACTIVE/PREFETCH/CACHED/UNUSED states.
- Performance Director that recommends reductions before sacrificing hero quality.
- Prompt persistence via localStorage.
- License-aware asset policy: downloadable does not automatically mean reusable.
- Launcher icon and web manifest are NOVA-branded; changing the icon does not change the UI.

## Important scope
This is a source-level studio foundation, not a magical local frontier model. Actual image/video generation and full 3D game compilation require compatible local engines/models, permitted assets, or external generation backends. The code is structured so those providers can be connected without merging the video and game renderers.

## Run
npm install
npm run dev

## Build
npm run build

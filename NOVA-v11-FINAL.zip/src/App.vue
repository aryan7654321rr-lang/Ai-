<script setup>
import { computed, onMounted, ref } from 'vue';
import { DEFAULT_GAME_PROMPT } from './prompts/gamePrompt';
import { DEFAULT_VIDEO_PROMPT } from './prompts/videoPrompt';
import { cleanupPlan } from './services/assetResolver';
import { recommendAdjustments } from './engine/performanceDirector';

const panel = ref(null);
const menu = ref(false);
const gamePrompt = ref(localStorage.getItem('nova.gamePrompt') || DEFAULT_GAME_PROMPT);
const videoPrompt = ref(localStorage.getItem('nova.videoPrompt') || DEFAULT_VIDEO_PROMPT);
const device = ref(localStorage.getItem('nova.device') || 'low');
const renderMode = ref('identity-safe');
const seed = ref('auto');
const notice = ref('Ready');
const cleanup = ref([]);
const perf = ref({frameMs:31,memoryMB:780,memoryBudgetMB:1024,targetFps:30});

const profiles = { low:{label:'Low-end Android',targetFps:30,memory:1024}, balanced:{label:'Balanced Android',targetFps:45,memory:2048}, high:{label:'High Android',targetFps:60,memory:4096} };
const currentProfile = computed(()=>profiles[device.value]);

function open(p){ panel.value=p; menu.value=false; notice.value=p==='game'?'Game Director ready':p==='video'?'Anime Director ready':'Image Studio ready'; }
function savePrompt(kind){ localStorage.setItem(kind==='game'?'nova.gamePrompt':'nova.videoPrompt',kind==='game'?gamePrompt.value:videoPrompt.value); notice.value='Prompt saved'; }
function resetPrompt(kind){ if(kind==='game') gamePrompt.value=DEFAULT_GAME_PROMPT; else videoPrompt.value=DEFAULT_VIDEO_PROMPT; notice.value='Default prompt restored'; }
function generate(kind){ savePrompt(kind); notice.value = kind==='game' ? 'Build specification queued — only active assets will be prepared.' : '10-minute shot plan queued — generation stays shot-based.'; }
function runCleanup(){
  const assets = [
    {name:'Hero_4K',active:true,distance:2,cached:true},
    {name:'NearStreet_High',visible:true,distance:18,cached:true},
    {name:'FarBuilding_8K',visible:true,distance:500,cached:true},
    {name:'UnusedVariant_A',visible:false,cached:true},
    {name:'OldTempRender',visible:false,cached:true}
  ];
  cleanup.value = cleanupPlan(assets,{nearDistance:80,prefetchDistance:260});
  notice.value='Unused-content pass completed';
}
function optimize(){
  const actions = recommendAdjustments(perf.value);
  notice.value='Performance Director: '+actions.join(' → ');
}
onMounted(()=>runCleanup());
</script>

<template>
  <main class="app-shell">
    <header class="topbar"><div class="brand">NOVA</div><div class="status">{{notice}}</div><button class="dots" @click="menu=!menu">⋮</button></header>
    <div v-if="menu" class="menu"><button @click="open('image')">Image Renderer</button><button @click="open('video')">Video Generation</button><button @click="open('game')">Game Generation</button></div>

    <section v-if="!panel" class="home">
      <button class="core" @click="open('image')" aria-label="Wake NOVA"><span>N</span><small>READY</small></button>
      <p class="wake">Hey · Hello · Nova</p>
      <div class="home-hint">Tap the core to open NOVA. Use ⋮ for Image, Video/Anime, or Game Studio.</div>
    </section>

    <section v-else class="workspace">
      <div class="workspace-head"><button class="back" @click="panel=null">←</button><div><h1>{{panel==='image'?'Image Studio':panel==='video'?'Video / Anime Studio':'Game Studio'}}</h1><p v-if="panel==='game'">Game Renderer is isolated inside Game Studio.</p><p v-else-if="panel==='video'">Anime renderer is a separate shot-based production system.</p><p v-else>Identity-safe image generation with seed control.</p></div></div>

      <div v-if="panel==='image'" class="card-grid">
        <article class="card"><h2>Image Renderer</h2><label>Render mode<select v-model="renderMode"><option>identity-safe</option><option>cinematic</option><option>concept</option></select></label><label>Seed<input v-model="seed" placeholder="auto" /></label><button class="primary">Prepare Render</button></article>
        <article class="card"><h2>Clean cache</h2><p>Keep only references and intermediate files needed by the current render.</p><button @click="runCleanup">Remove unused intermediates</button></article>
      </div>

      <div v-if="panel==='video'" class="card-grid">
        <article class="card wide"><div class="pill">SEPARATE VIDEO PIPELINE</div><h2>Default 10-minute anime showcase</h2><textarea v-model="videoPrompt"></textarea><div class="row"><button @click="resetPrompt('video')">Restore default</button><button @click="savePrompt('video')">Save</button><button class="primary" @click="generate('video')">Generate episode plan</button></div></article>
        <article class="card"><h2>Shot production</h2><p>Script → bible → storyboard → keyframes → animation → continuity → voices → QC → edit.</p><p class="muted">Only failed shots are regenerated.</p></article>
      </div>

      <div v-if="panel==='game'" class="card-grid">
        <article class="card wide"><div class="pill">GAME DIRECTOR + MOBILE RENDERER</div><h2>Default game prompt</h2><textarea v-model="gamePrompt"></textarea><div class="row"><button @click="resetPrompt('game')">Restore default</button><button @click="savePrompt('game')">Save</button><button class="primary" @click="generate('game')">Generate build spec</button></div></article>
        <article class="card"><h2>Device profile</h2><select v-model="device"><option value="low">Low-end Android</option><option value="balanced">Balanced Android</option><option value="high">High Android</option></select><div class="metrics"><b>{{currentProfile.label}}</b><span>{{currentProfile.targetFps}} FPS target</span><span>{{currentProfile.memory}} MB budget</span></div><button @click="optimize">Run performance director</button></article>
        <article class="card"><h2>Unused-content remover</h2><p>Active, prefetch, cached and unused states are recalculated from camera/mission relevance.</p><button @click="runCleanup">Clean now</button><ul><li v-for="a in cleanup" :key="a.name"><span>{{a.name}}</span><em :class="a.state.toLowerCase()">{{a.state}}</em></li></ul></article>
        <article class="card"><h2>Quality policy</h2><p>Hero → near camera → landmarks → mid/far world. When performance drops, invisible and distant work is reduced first.</p><p class="muted">No automatic use of unlicensed downloadable content.</p></article>
      </div>
    </section>
  </main>
</template>

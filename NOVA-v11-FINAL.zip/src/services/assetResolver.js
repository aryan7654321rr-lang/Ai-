export function classifyAsset(asset, context) {
  const distance = asset.distance ?? 999;
  const visible = asset.visible !== false;
  const active = asset.active === true;
  const predicted = asset.predicted === true;
  if (active) return 'ACTIVE';
  if (visible && distance < context.nearDistance) return 'ACTIVE';
  if (predicted && distance < context.prefetchDistance) return 'PREFETCH';
  if (asset.cached) return 'CACHED';
  return 'UNUSED';
}

export function cleanupPlan(assets, context) {
  return assets.map(a => ({...a, state: classifyAsset(a, context)}));
}

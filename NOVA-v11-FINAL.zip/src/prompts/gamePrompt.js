export const DEFAULT_GAME_PROMPT = `NOVA GAME DIRECTOR — MOBILE AAA-QUALITY ORIGINAL OPEN WORLD

Create an ORIGINAL mobile open-world game for low-end Android first. Target maximum visible quality, not maximum hidden complexity. Do not copy any existing game's characters, story, map, UI, dialogue, music, or proprietary assets.

PLAYER / HERO PRIORITY
- Make the player-controlled hero the highest-detail character on screen.
- Use a production-quality rig, facial/skin/material detail, cloth/hair motion and believable animation where the device budget allows.
- Preserve hero detail before adding detail to distant or unseen objects.

WORLD
- Build a dense, believable original world with strong landmarks, varied architecture, vegetation, roads, interiors, NPC activity, vehicles/creatures where appropriate, weather/time variation and cinematic composition.
- Stream the world in zones around the camera/player. Preload the next likely zone and evict unused zones.

ASSET RESOLUTION
- Search only sources whose license/terms explicitly permit the requested reuse, or use user-owned/generated content.
- Record source, license, attribution requirements and local cache status for every imported asset.
- Prefer high-quality assets for hero/near-camera/landmark content; use lighter variants for background content.
- Never assume “free download” means “free to reuse.”

MOBILE RENDERING
- Camera-aware LOD/HLOD, frustum + occlusion culling, impostors for far objects, texture streaming, mipmaps, GPU-friendly texture compression, mesh simplification, batching/instancing, object pooling and aggressive asset reuse.
- Dynamic resolution and frame pacing are allowed. Reduce invisible/far work first.
- Use selective real-time lighting and baked/probe lighting where appropriate.
- Keep memory bounded with an asset budget and LRU-style cache eviction.
- Avoid spawning, loading or ticking systems that are not currently needed.

PERFORMANCE DIRECTOR
Continuously measure frame time, memory pressure, thermal state and loading stalls. Adapt quality in this order: invisible objects -> far geometry -> far textures -> shadow distance -> crowd density -> secondary effects -> dynamic resolution. Never sacrifice the hero first unless required for stability.

CLEANUP / UNUSED CONTENT
- Do not load an asset because it exists in the project.
- Build a dependency graph from the active scene, current mission, current camera frustum and predicted next zone.
- Mark assets as ACTIVE, PREFETCH, CACHED or UNUSED.
- Unload UNUSED assets promptly after a safe grace period.
- Cancel stale downloads and generation jobs when the user changes direction, scene or prompt.
- Deduplicate identical textures, meshes, animations and audio.
- Remove orphaned temporary files and intermediate renders after successful finalization.
- Keep only the variants required by the selected device profile.

GAMEPLAY
- Provide responsive touch controls, camera controls, interactions, missions/quests, NPC schedules/behavior, save/load, checkpoints and graceful recovery from missing content.
- Generated systems must degrade instead of crashing when a high-detail asset is unavailable.

QA
- Test cold start, scene transition, zone streaming, asset eviction, low-memory conditions, orientation, background/foreground transitions and repeated play loops.
- Repair failures automatically where possible and explain any blocked dependency.

OUTPUT
Return a build specification, asset manifest, dependency graph, streaming plan, performance budget, scene graph and test plan before execution. Then execute only the active work required for the selected target device.`;

<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import * as THREE from 'three'
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js'
import * as THREEGPU from 'three/webgpu'

const prompt = ref(`Create a large original cinematic anime-inspired open-world adventure with a highly detailed human-like hero, a living city, forests, mountains, ruins, weather, day and night, NPCs, mysterious creatures, exploration, quests and cinematic story sequences. Make the visual quality as high as the device can sustain.`)
const mode = ref('studio')
const quality = ref(localStorage.getItem('nova-quality') || 'auto')
const settingsOpen = ref(false)
const status = ref('Ready')
const rendererLabel = ref('Detecting renderer…')
const fps = ref(0)
const videoUrl = ref('')
const videoMime = ref('')
const videoSupported = ref(false)
const micState = ref('Not requested')
const isGenerating = ref(false)
const canvas = ref(null)
const videoPreview = ref(null)
const world = ref(null)
const controlsVisible = computed(() => mode.value !== 'studio')
const qualityText = computed(() => ({auto:'AUTO',low:'LOW',medium:'MEDIUM',high:'HIGH',max:'MAX'}[quality.value]))

let renderer, scene, camera, clock, raf, resizeObserver, recorder, chunks=[]
let worldRoot, actor, cameraTarget, cameraRig, cinematicClock=0
const mixers=[]

const DEFAULT_WORLD = () => ({
  title:'NOVA World', seed:Date.now(), time:0.18, weather:'clear',
  hero:{x:0,y:0,z:0}, npcs:[], creatures:[], buildings:[], trees:[], landmarks:[],
  story:['Arrival','The Hidden District','The Underground Gate','The Unanswered Signal'],
  cinematicShots:[]
})

function hashSeed(text){ let h=2166136261; for(const c of text) h=Math.imul(h^c.charCodeAt(0),16777619); return h>>>0 }
function rng(seed){ let s=seed>>>0; return ()=>{s=(Math.imul(1664525,s)+1013904223)>>>0;return s/4294967296} }
function parsePrompt(text){
  const r=rng(hashSeed(text)); const w=DEFAULT_WORLD(); w.seed=hashSeed(text); w.title=text.split(/[.!?]/)[0].slice(0,42)||'NOVA World'
  const cityCount=quality.value==='low'?18:quality.value==='medium'?28:quality.value==='high'?44:58
  const treeCount=quality.value==='low'?22:quality.value==='medium'?42:quality.value==='high'?70:100
  for(let i=0;i<cityCount;i++) w.buildings.push({x:(r()-.5)*42,z:(r()-.5)*42,sx:1.2+r()*2.2,sy:2+r()*7,sz:1.2+r()*2.2,rot:r()*6.28})
  for(let i=0;i<treeCount;i++) w.trees.push({x:(r()-.5)*70,z:(r()-.5)*70,s:.7+r()*1.7})
  for(let i=0;i<8;i++) w.npcs.push({x:(r()-.5)*30,z:(r()-.5)*30,phase:r()*6.28})
  for(let i=0;i<4;i++) w.creatures.push({x:(r()-.5)*45,z:(r()-.5)*45,phase:r()*6.28,s:.8+r()*.8})
  for(let i=0;i<5;i++) w.landmarks.push({x:(r()-.5)*55,z:(r()-.5)*55,s:2+r()*4})
  w.cinematicShots=[
    {t:0,d:5,type:'establishing'}, {t:5,d:5,type:'arrival'}, {t:10,d:5,type:'character'},
    {t:15,d:5,type:'mystery'}, {t:20,d:5,type:'action'}, {t:25,d:5,type:'reveal'}, {t:30,d:5,type:'ending'}
  ]
  return w
}

function material(color, rough=.72, metal=0){ return new THREE.MeshStandardMaterial({color,roughness:rough,metalness:metal}) }
function makeHumanoid(color=0x8f6a52){
  const g=new THREE.Group(); g.name='OriginalHero'
  const skin=material(0xd9aa8b,.62), cloth=material(color,.72), dark=material(0x171b27,.55), hair=material(0x241b2a,.5)
  const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.34,.82,8,12),cloth); torso.position.y=1.35; g.add(torso)
  const head=new THREE.Mesh(new THREE.SphereGeometry(.31,20,14),skin); head.scale.set(1,.98,.9); head.position.y=2.35; g.add(head)
  const hairMesh=new THREE.Mesh(new THREE.SphereGeometry(.325,20,12,0,Math.PI*2,0,Math.PI*.62),hair); hairMesh.position.y=2.43; g.add(hairMesh)
  for(const side of [-1,1]){
    const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.105,.62,6,8),cloth); arm.position.set(side*.48,1.38,0); arm.rotation.z=side*.14; g.add(arm)
    const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.13,.78,6,8),dark); leg.position.set(side*.19,.58,0); g.add(leg)
    const boot=new THREE.Mesh(new THREE.BoxGeometry(.22,.14,.38),dark); boot.position.set(side*.19,.1,.06); g.add(boot)
  }
  return g
}
function makeCreature(){
  const g=new THREE.Group(); const body=new THREE.Mesh(new THREE.SphereGeometry(.75,20,14),material(0x6b4f82,.62)); body.scale.set(1.25,.75,1); g.add(body)
  const head=new THREE.Mesh(new THREE.SphereGeometry(.42,18,12),material(0x9b7ab8,.58)); head.position.z=.72; head.position.y=.12; g.add(head)
  for(const side of [-1,1]){ const wing=new THREE.Mesh(new THREE.ConeGeometry(.5,.9,8),material(0x3c6f83,.65)); wing.position.set(side*.85,.25,0); wing.rotation.z=side*Math.PI/2; g.add(wing) }
  return g
}
function addWorld(){
  if(worldRoot) scene.remove(worldRoot)
  worldRoot=new THREE.Group(); scene.add(worldRoot)
  const w=world.value
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(180,180,32,32),material(0x24312b,.95)); ground.rotation.x=-Math.PI/2; worldRoot.add(ground)
  const roadMat=material(0x31343a,.88)
  for(let i=0;i<3;i++){const road=new THREE.Mesh(new THREE.BoxGeometry(80,.04,3),roadMat);road.position.set(0,.03,(i-1)*12);worldRoot.add(road)}
  for(const b of w.buildings){
    const m=new THREE.Mesh(new THREE.BoxGeometry(b.sx,b.sy,b.sz,2,3,2),material(new THREE.Color().setHSL(.55+.08*(b.sy/9),.25,.28+.03*(b.sy/9)),.72));m.position.set(b.x,b.sy/2,b.z);m.rotation.y=b.rot;worldRoot.add(m)
    const roof=new THREE.Mesh(new THREE.ConeGeometry(Math.max(b.sx,b.sz)*.78,.55,4),material(0x3b3048,.75));roof.position.set(b.x,b.sy+.22,b.z);roof.rotation.y=Math.PI/4;worldRoot.add(roof)
  }
  for(const t of w.trees){const g=new THREE.Group();const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.09,.14,1.4,8),material(0x5a4135));trunk.position.y=.7;g.add(trunk);const crown=new THREE.Mesh(new THREE.SphereGeometry(.65,10,8),material(0x2c644b,.86));crown.position.y=1.55;g.add(crown);g.position.set(t.x,0,t.z);g.scale.setScalar(t.s);worldRoot.add(g)}
  for(const l of w.landmarks){const g=new THREE.Group();const base=new THREE.Mesh(new THREE.CylinderGeometry(.7,.9,l.s,10),material(0x59636e,.9));base.position.y=l.s/2;g.add(base);const glow=new THREE.Mesh(new THREE.SphereGeometry(.28,12,8),new THREE.MeshStandardMaterial({color:0x9ad8ff,emissive:0x3a8bc2,emissiveIntensity:3}));glow.position.y=l.s+.5;g.add(glow);g.position.set(l.x,0,l.z);worldRoot.add(g)}
  actor=makeHumanoid(0x6f88c4); actor.position.set(w.hero.x,0,w.hero.z); worldRoot.add(actor)
  for(const n of w.npcs){const a=makeHumanoid(0x9b6d62);a.scale.setScalar(.92);a.position.set(n.x,0,n.z);a.userData.phase=n.phase;worldRoot.add(a)}
  for(const c of w.creatures){const a=makeCreature();a.position.set(c.x,1,c.z);a.scale.setScalar(c.s);a.userData.phase=c.phase;worldRoot.add(a)}
}
async function initRenderer(){
  const opts={antialias:true,powerPreference:'high-performance'}
  try{
    if(navigator.gpu){renderer=new THREEGPU.WebGPURenderer(opts); await renderer.init(); rendererLabel.value='WebGPU';}
  }catch(e){renderer=null}
  if(!renderer){renderer=new THREE.WebGLRenderer(opts);rendererLabel.value='WebGL 2'}
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,quality.value==='low'?1:quality.value==='medium'?1.25:quality.value==='high'?1.5:1.75))
  renderer.setSize(canvas.value.clientWidth||640,canvas.value.clientHeight||360,false)
  renderer.shadowMap.enabled=quality.value!=='low'; renderer.shadowMap.type=THREE.PCFSoftShadowMap
  renderer.outputColorSpace=THREE.SRGBColorSpace; renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.05
  canvas.value.replaceWith(renderer.domElement); canvas.value=renderer.domElement
  scene=new THREE.Scene(); scene.background=new THREE.Color(0x0b1428); scene.fog=new THREE.FogExp2(0x1c2940,.012)
  camera=new THREE.PerspectiveCamera(55,1,.1,240); camera.position.set(0,3.2,9); cameraTarget=new THREE.Vector3(0,1.2,0); cameraRig=new THREE.Vector3()
  clock=new THREE.Clock()
  const hemi=new THREE.HemisphereLight(0x9fc7ff,0x1d2a22,1.7);scene.add(hemi)
  const sun=new THREE.DirectionalLight(0xffe2ba,3.2);sun.position.set(-15,24,8);sun.castShadow=quality.value!=='low';sun.shadow.mapSize.set(quality.value==='max'?2048:1024,quality.value==='max'?2048:1024);scene.add(sun)
  addWorld();
  resizeObserver=new ResizeObserver(()=>resize());resizeObserver.observe(renderer.domElement)
  renderer.setAnimationLoop(tick)
  checkRecorder()
}
function resize(){if(!renderer||!camera)return;const w=renderer.domElement.clientWidth||640,h=renderer.domElement.clientHeight||360;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false)}
function tick(){
  const dt=Math.min(.05,clock?.getDelta?.()||.016); if(!world.value)return
  if(mode.value!=='studio'){
    world.value.time=(world.value.time+dt*.035)%1
    if(actor){actor.position.x += ((input.right?1:0)-(input.left?1:0))*dt*3.2;actor.position.z += ((input.down?1:0)-(input.up?1:0))*dt*3.2;actor.position.y=Math.abs(Math.sin(performance.now()*.004))*0.01;actor.rotation.y=Math.atan2((input.right?1:0)-(input.left?1:0),-((input.down?1:0)-(input.up?1:0))||1)}
    for(const o of worldRoot?.children||[]){if(o.userData.phase!==undefined)o.rotation.y+=dt*(.15+Math.sin(o.userData.phase)*.05)}
    if(mode.value==='cinematic'){cinematicClock=(cinematicClock+dt)%35;camera.position.x=Math.sin(cinematicClock*.18)*8;camera.position.z=9+Math.cos(cinematicClock*.12)*7;camera.position.y=3.4+Math.sin(cinematicClock*.25)*1.3}
    else {camera.position.x=actor?.position.x||0;camera.position.z=(actor?.position.z||0)+8;camera.position.y=3.4}
  }
  if(actor){cameraTarget.set(actor.position.x,1.4,actor.position.z)}
  camera.lookAt(cameraTarget);renderer.render(scene,camera)
  const now=performance.now(); fpsFrames++;if(now-fpsTime>800){fps.value=Math.round(fpsFrames*1000/(now-fpsTime));fpsFrames=0;fpsTime=now}
}
let fpsFrames=0,fpsTime=performance.now()
const input={up:false,down:false,left:false,right:false}
function hold(k,v){input[k]=v}
function generateGame(){isGenerating.value=true;status.value='Planning world, characters, quests and adaptive rendering…';setTimeout(()=>{world.value=parsePrompt(prompt.value);mode.value='game';addWorld();isGenerating.value=false;status.value='Playable shared world ready';},350)}
function interactive(){world.value=parsePrompt(prompt.value);mode.value='interactive';addWorld();status.value='Interactive cinematic world ready'}
function generateVideo(){world.value=parsePrompt(prompt.value);mode.value='cinematic';addWorld();status.value='Preparing cinematic recorder…';setTimeout(renderCinematic,250)}
function checkRecorder(){videoSupported.value=!!(renderer?.domElement?.captureStream&&window.MediaRecorder); if(!videoSupported.value)status.value='Video capture depends on WebView MediaRecorder support'}
async function renderCinematic(){
  if(!renderer?.domElement?.captureStream||!window.MediaRecorder){status.value='This Android/WebView does not expose a video encoder. Game rendering is still available.';return}
  const stream=renderer.domElement.captureStream(30);const types=['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'].filter(t=>MediaRecorder.isTypeSupported(t));
  if(!types.length){status.value='No supported browser video encoder was found';return}
  chunks=[];videoMime.value=types[0];recorder=new MediaRecorder(stream,{mimeType:types[0],videoBitsPerSecond:8_000_000});
  recorder.ondataavailable=e=>e.data.size&&chunks.push(e.data); const done=new Promise(r=>recorder.onstop=r); recorder.start(250)
  const start=performance.now(),duration=10000; status.value='Rendering cinematic preview (10 seconds)…'
  await new Promise(resolve=>{const step=()=>{cinematicClock=(performance.now()-start)/1000;if(cinematicClock<duration/1000)requestAnimationFrame(step);else resolve()};step()})
  recorder.stop();await done;const blob=new Blob(chunks,{type:videoMime.value});if(videoUrl.value)URL.revokeObjectURL(videoUrl.value);videoUrl.value=URL.createObjectURL(blob);status.value='Cinematic video rendered';setTimeout(()=>videoPreview.value?.play?.().catch(()=>{}),50)
}
function downloadVideo(){if(!videoUrl.value)return;const a=document.createElement('a');a.href=videoUrl.value;a.download='nova-cinematic.webm';a.click()}
async function askMic(){if(window.NovaVoice?.requestMicrophone){window.NovaVoice.requestMicrophone();micState.value='System prompt requested';return}try{const s=await navigator.mediaDevices.getUserMedia({audio:true});s.getTracks().forEach(t=>t.stop());micState.value='Granted'}catch{micState.value='Denied / unavailable'}}
function appSettings(){if(window.NovaVoice?.openAppSettings)window.NovaVoice.openAppSettings();else status.value='Open Android Settings → Apps → NOVA-X → Permissions'}
function chooseQuality(q){quality.value=q;localStorage.setItem('nova-quality',q);status.value='Graphics profile changed — regenerate to apply'}
function downloadWorld(){const blob=new Blob([JSON.stringify(world.value,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='nova-shared-world.json';a.click()}
function onKey(e){const map={w:'up',ArrowUp:'up',s:'down',ArrowDown:'down',a:'left',ArrowLeft:'left',d:'right',ArrowRight:'right'};if(map[e.key])input[map[e.key]]=true}
function onUp(){Object.keys(input).forEach(k=>input[k]=false)}
onMounted(async()=>{world.value=parsePrompt(prompt.value);await initRenderer();window.addEventListener('keydown',onKey);window.addEventListener('keyup',onUp)})
onBeforeUnmount(()=>{renderer?.setAnimationLoop(null);resizeObserver?.disconnect();window.removeEventListener('keydown',onKey);window.removeEventListener('keyup',onUp);if(videoUrl.value)URL.revokeObjectURL(videoUrl.value)})
</script>

<template>
<main class="app">
  <header><div class="brand"><span class="orb"></span><b>NOVA</b><small>AI GAME + ANIME STUDIO</small></div><button class="dots" @click="settingsOpen=!settingsOpen">⋮</button></header>
  <section class="hero"><div class="eyebrow">ONE PROMPT → SHARED WORLD → GAME + VIDEO</div><h1>Create the world once.<br><span>Play it. Direct it. Render it.</span></h1><p>NOVA plans an original world from your prompt, then uses the same characters, environments and state for gameplay and cinematic output.</p></section>
  <section class="prompt panel"><label>Describe your game / episode</label><textarea v-model="prompt"></textarea><div class="actions"><button class="primary" :disabled="isGenerating" @click="generateGame">🎮 Generate Game</button><button @click="generateVideo">🎬 Generate Video</button><button @click="interactive">◉ Interactive Video</button></div></section>
  <section class="stage panel"><div class="canvasWrap"><canvas ref="canvas"></canvas><div class="hud"><span>{{status}}</span><span>{{fps}} FPS · {{rendererLabel}} · {{qualityText}}</span></div><div v-if="controlsVisible" class="controls"><button @pointerdown="hold('up',true)" @pointerup="hold('up',false)" @pointerleave="hold('up',false)">▲</button><div><button @pointerdown="hold('left',true)" @pointerup="hold('left',false)">◀</button><button @pointerdown="hold('down',true)" @pointerup="hold('down',false)">▼</button><button @pointerdown="hold('right',true)" @pointerup="hold('right',false)">▶</button></div></div></div></section>
  <section class="cards"><button @click="generateGame"><b>PLAY GAME</b><span>Generated 3D world</span></button><button @click="generateVideo"><b>GENERATE VIDEO</b><span>Directed cinematic from the same world</span></button><button @click="interactive"><b>INTERACTIVE VIDEO</b><span>Explore the cinematic world</span></button></section>
  <section class="video panel" v-if="videoUrl"><h2>Rendered video</h2><video ref="videoPreview" :src="videoUrl" controls playsinline></video><button class="primary" @click="downloadVideo">Save video</button></section>
  <section class="panel tools"><div><b>Shared world</b><span>Characters, locations, quests and cinematics use one world specification.</span></div><button @click="downloadWorld">Export world JSON</button></section>
  <aside v-if="settingsOpen" class="settings panel"><div class="settingsTop"><h2>⋮ Settings & Permissions</h2><button @click="settingsOpen=false">×</button></div><div class="setting"><div><b>Microphone</b><small>{{micState}}</small></div><button @click="askMic">Allow / Test</button></div><div class="setting"><div><b>Android settings</b><small>Open NOVA-X app permissions</small></div><button @click="appSettings">Open</button></div><div class="setting"><div><b>Graphics</b><small>Adaptive rendering profile</small></div><div class="qualities"><button v-for="q in ['auto','low','medium','high','max']" :key="q" :class="{selected:quality===q}" @click="chooseQuality(q)">{{q}}</button></div></div><p>For microphone access, Android requires a runtime permission request; declaring the permission alone is not sufficient.</p></aside>
</main>
</template>

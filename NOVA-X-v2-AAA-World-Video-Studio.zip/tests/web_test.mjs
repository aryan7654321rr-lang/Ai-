import fs from 'node:fs'
const app=fs.readFileSync('src/App.vue','utf8')
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'))
for(const token of ['Generate Game','Generate Video','Interactive Video','Microphone','Android settings','WebGPU','MediaRecorder','GLTFLoader','same world']) if(!app.includes(token)) throw new Error(`missing ${token}`)
if(!pkg.dependencies.three) throw new Error('three dependency missing')
if((app.match(/<\/script>/g)||[]).length!==1) throw new Error('script boundary regression')
console.log('NOVA-X v2 source smoke test: PASS')

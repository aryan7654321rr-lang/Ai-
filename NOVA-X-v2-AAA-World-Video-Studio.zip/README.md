# NOVA-X v2 — Shared World Game + Cinematic Studio

This build replaces the previous 2D/canvas prototype with a Three.js 3D runtime and a shared world model.

## Included
- One-prompt world planning
- Shared world used by game, cinematic and interactive-video modes
- Three.js WebGPU renderer with WebGL 2 fallback
- GLTF/GLB loader hook for real high-quality assets
- Adaptive quality profiles and pixel-ratio control
- 3D characters, NPCs, creatures, buildings, vegetation and landmarks
- Third-person gameplay controls
- Cinematic camera director
- Canvas `captureStream()` + `MediaRecorder` video export when the WebView/browser exposes an encoder
- Always-visible three-dot settings menu
- Runtime microphone permission/test flow and Android settings bridge hook
- Exportable shared-world JSON
- GitHub Actions Android build workflow
- Copy-paste game and 10-minute anime prompts in `PROMPTS.md`

## Important
This is an engineering foundation, not a claim that a low-end phone can render literal GTA V or professional-studio anime production locally. Real AAA-quality output requires detailed licensed/generated GLB assets, animation libraries, materials, VFX and sufficient hardware. This runtime is built to accept those assets and scale them for the device.

Video export in a browser/WebView depends on MediaRecorder/video-encoder support. The app detects this instead of pretending that a video was rendered when the platform cannot encode it.

import test from 'node:test'
import assert from 'node:assert/strict'
import { routePrompt, QUALITY_CONTRACT } from './src/core/main.js'
import { gameGenerationPlan } from './src/core/gameDirector.js'
import { videoGenerationPlan } from './src/core/videoDirector.js'

test('routes game/video/image independently',()=>{assert.equal(routePrompt('make a playable open world game'),'game');assert.equal(routePrompt('make a cinematic episode'),'video');assert.equal(routePrompt('make a portrait image'),'image')})
test('game plan protects hero quality',()=>{const p=gameGenerationPlan('fantasy game');assert.ok(p.stages.includes('hero-character-priority'));assert.ok(p.stages.includes('camera-aware-lod'))})
test('video plan is shot based',()=>{const p=videoGenerationPlan('cinematic episode');assert.ok(p.stages.includes('shot-list'));assert.ok(p.stages.includes('temporal-refinement'))})
test('quality contract prioritizes game then video',()=>{assert.equal(QUALITY_CONTRACT.game.priority,1);assert.equal(QUALITY_CONTRACT.video.priority,2)})

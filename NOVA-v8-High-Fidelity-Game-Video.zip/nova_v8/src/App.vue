<script setup>
import { computed, ref } from 'vue'
import { routePrompt } from './core/main.js'
import { gameGenerationPlan } from './core/gameDirector.js'
import { videoGenerationPlan } from './core/videoDirector.js'
import { imageGenerationPlan } from './core/imageDirector.js'
import { assistantReply } from './core/assistant.js'

const menu = ref(false)
const panel = ref(null)
const prompt = ref('')
const output = ref('')
const device = ref('lowEndAndroid')
const status = ref('READY')

const title = computed(() => ({image:'IMAGE GENERATOR',video:'VIDEO GENERATOR',game:'GAME GENERATOR'}[panel.value] || 'NOVA'))
function openPanel(name){ panel.value=name; menu.value=false; output.value='' }
function run(){
  const p=prompt.value.trim(); if(!p) return
  status.value='PLANNING'
  if(panel.value==='game') output.value=JSON.stringify(gameGenerationPlan(p,device.value),null,2)
  if(panel.value==='video') output.value=JSON.stringify(videoGenerationPlan(p),null,2)
  if(panel.value==='image') output.value=JSON.stringify(imageGenerationPlan(p),null,2)
  status.value='READY'
}
function ask(){ output.value=assistantReply(prompt.value); status.value='READY' }
function wake(){ status.value=status.value==='ACTIVE'?'READY':'ACTIVE' }
</script>
<template>
  <main class="app">
    <header class="topbar"><div class="brand"><span class="brand-mark">N</span><span>NOVA</span></div><div class="status">{{status}}</div><button class="dots" @click="menu=!menu" aria-label="Menu">•••</button></header>

    <section v-if="!panel" class="home">
      <button class="core" @click="wake" :aria-label="status==='ACTIVE'?'Deactivate NOVA':'Activate NOVA'"><span class="core-ring"></span><span class="core-letter">N</span></button>
      <div class="home-copy"><h1>NOVA</h1><p>Personal creative intelligence</p><div class="wake-hint">Tap the core to {{status==='ACTIVE'?'stand by':'wake'}} · Voice wake: “Hey Nova”</div></div>
      <div class="assistant"><input v-model="prompt" @keyup.enter="ask" placeholder="Ask NOVA anything…"/><button @click="ask">Ask</button></div>
    </section>

    <section v-else class="workspace">
      <div class="workspace-head"><button class="back" @click="panel=null">← Home</button><div><div class="eyebrow">DEDICATED SYSTEM</div><h2>{{title}}</h2></div></div>
      <div class="workspace-grid">
        <div class="brief"><label>CREATION BRIEF</label><textarea v-model="prompt" :placeholder="panel==='game'?'Describe the game you want NOVA to generate…':panel==='video'?'Describe the cinematic or episode…':'Describe the image…'"></textarea><div v-if="panel==='game'" class="device-row"><label>Target profile</label><select v-model="device"><option value="lowEndAndroid">Low-end Android / A54-class</option><option value="balancedAndroid">Balanced Android</option><option value="highEndAndroid">High-end Android</option></select></div><button class="generate" @click="run">BUILD PLAN</button></div>
        <div class="director"><div class="director-title">QUALITY DIRECTOR</div><div class="pill" v-for="x in (panel==='game'?['Hero-character priority','Camera-aware LOD','Streaming + culling','Dynamic resolution','Thermal budget','Frame pacing']:panel==='video'?['Identity lock','Shot planning','Temporal consistency','Repair passes','Audio sync','Continuity check']:['Identity preservation','Material detail','Lighting','Refinement','Upscale','Compressed delivery'])" :key="x">{{x}}</div><pre v-if="output">{{output}}</pre></div>
      </div>
    </section>

    <nav v-if="menu" class="menu"><button @click="openPanel('image')">Image Generation</button><button @click="openPanel('video')">Video Generation <b>#2</b></button><button @click="openPanel('game')">Game Generation <b>#1</b></button></nav>
  </main>
</template>

export const NOVA_VERSION = '8.0.0'

export const QUALITY_CONTRACT = {
  game: {
    priority: 1,
    target: 'High-fidelity mobile game experience with maximum perceived detail per unit of device cost.',
    pillars: ['hero-character-first', 'camera-aware-detail', 'visibility-culling', 'adaptive-lod', 'streaming', 'dynamic-resolution', 'thermal-budgeting', 'frame-pacing'],
    validation: ['visual-benchmark', 'frame-time', 'p90-p99-stability', 'memory', 'thermal', 'startup']
  },
  video: {
    priority: 2,
    target: 'Premium cinematic/anime-style generation through short coherent shots and refinement passes.',
    pillars: ['character-identity-lock', 'scene-lock', 'shot-planning', 'temporal-consistency', 'motion-refinement', 'audio-sync', 'repair-pass'],
    validation: ['identity-consistency', 'temporal-stability', 'motion-quality', 'artifact-rate', 'encode-integrity']
  },
  image: {
    priority: 3,
    target: 'High-detail still-image foundation for reusable characters, locations and props.',
    pillars: ['identity-preservation', 'detail-pass', 'material-pass', 'upscale-pass', 'compression']
  }
}

export const DEVICE_POLICY = {
  lowEndAndroid: { targetFps: 30, minFrameBudgetMs: 33.3, maxResidentDetailZones: 3, dynamicResolution: true },
  balancedAndroid: { targetFps: 40, minFrameBudgetMs: 25, maxResidentDetailZones: 5, dynamicResolution: true },
  highEndAndroid: { targetFps: 60, minFrameBudgetMs: 16.7, maxResidentDetailZones: 8, dynamicResolution: true }
}

export function routePrompt(prompt) {
  const p = String(prompt || '').toLowerCase()
  if (/\b(video|episode|cinematic|animation|anime)\b/.test(p)) return 'video'
  if (/\b(game|playable|open world|third person|level|quest)\b/.test(p)) return 'game'
  if (/\b(image|portrait|concept|illustration|picture)\b/.test(p)) return 'image'
  return 'assistant'
}

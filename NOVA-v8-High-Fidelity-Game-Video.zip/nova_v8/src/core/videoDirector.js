export function videoGenerationPlan(prompt) {
  return {
    mode: 'video', prompt,
    stages: ['story', 'screenplay', 'character-bible', 'location-bible', 'shot-list', 'keyframes', 'performance', 'motion', 'temporal-refinement', 'lighting-effects', 'audio', 'repair', 'encode', 'continuity-check'],
    rule: 'Generate and refine short coherent shots; never treat a long episode as one monolithic generation job.'
  }
}

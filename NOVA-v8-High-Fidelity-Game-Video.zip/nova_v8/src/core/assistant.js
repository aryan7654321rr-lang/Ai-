import { routePrompt } from './main.js'
export function assistantReply(prompt) {
  const mode = routePrompt(prompt)
  if (mode === 'assistant') return 'I’m NOVA. Tell me what you want to create, change, plan, or analyze.'
  return `I routed this request to the ${mode} system. Open the three-dot menu to continue there.`
}

export function imageGenerationPlan(prompt) {
  return { mode:'image', prompt, stages:['composition','character-identity','material-detail','lighting','refinement','upscale','compressed-delivery'] }
}

import { DEVICE_POLICY } from './main.js'

export function gameGenerationPlan(prompt, device='lowEndAndroid') {
  const policy = DEVICE_POLICY[device] || DEVICE_POLICY.lowEndAndroid
  return {
    mode: 'game',
    prompt,
    targetDevice: device,
    policy,
    stages: [
      'parse-game-spec', 'generate-master-assets', 'build-world-zones',
      'hero-character-priority', 'camera-aware-lod', 'visibility-culling',
      'streaming-cache', 'adaptive-resolution', 'thermal-controller',
      'frame-pacing', 'benchmark-and-repair'
    ],
    rule: 'Never trade the player-visible hero asset for invisible/background detail when the device budget is constrained.'
  }
}

# NOVA v8 — High-Fidelity Creative Architecture

NOVA v8 is a clean rebuild centered on four parts: Home/Personal AI, Image Generation, Video Generation, and Game Generation.

## Priority
1. Game Generation — highest priority, designed around maximum perceived visual fidelity per unit of mobile hardware cost.
2. Video Generation — separate shot-based cinematic pipeline with identity and temporal consistency controls.
3. Image Generation — reusable high-detail still-image foundation.
4. Home — lightweight assistant/orchestrator.

## Important honesty
This repository is an architecture and quality-control foundation. It does **not** contain a frontier 3D or video generation model, and it cannot truthfully guarantee console/AAA parity on an Oppo A54 without real generation models and physical-device testing. The quality contract is designed to make those future implementations measurable rather than pretending a placeholder renderer already achieves them.

## Main workflow
`.github/workflows/main.yml` is the primary quality gate. It verifies the separated pipelines, tests, and production build.

## Mobile strategy
The game architecture uses hero-character priority, camera-aware LOD, visibility culling, streaming, dynamic resolution, thermal budgeting, and frame pacing. These correspond to established mobile optimization concepts documented by Epic and Android. See their current documentation for device profiles/scalability and Android frame stability. 

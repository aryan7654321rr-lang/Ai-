package com.novax;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(android.os.Bundle savedInstanceState) {
        registerPlugin(NovaVoicePlugin.class);
        super.onCreate(savedInstanceState);
    }
}

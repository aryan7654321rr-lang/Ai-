package com.novax;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.ArrayList;
import java.util.Locale;

@CapacitorPlugin(name = "NovaVoice", permissions = { @Permission(strings = { Manifest.permission.RECORD_AUDIO }, alias = "microphone") })
public class NovaVoicePlugin extends Plugin {
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean wakeMode = false;
    private boolean commandMode = false;
    private boolean restartWake = false;
    private static final int MIC_REQUEST = 4101;

    @Override public void load() {
        tts = new TextToSpeech(getContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(Locale.getDefault());
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.US);
            }
        });
    }

    private boolean micReady() {
        return getContext().checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean ensureMic(PluginCall call, boolean wake) {
        if (micReady()) return true;
        restartWake = wake;
        requestPermissionForAlias("microphone", call, "permissionCallback");
        return false;
    }

    @PermissionCallback
    public void permissionCallback(PluginCall call) {
        if (micReady()) {
            emitState("permission-ready");
            if (restartWake) listen(true);
            else listen(false);
            call.resolve();
        } else {
            emitError("Microphone permission was denied. Enable microphone permission in Android settings to use voice.");
            call.resolve();
        }
    }

    private void emit(String event, String text) { JSObject o = new JSObject(); if (text != null) o.put("text", text); notifyListeners(event, o); }
    private void emitError(String text) { JSObject o = new JSObject(); o.put("message", text); notifyListeners("error", o); }
    private void emitState(String state) { JSObject o = new JSObject(); o.put("state", state); notifyListeners("state", o); }

    private void stopRecognizer() {
        if (recognizer != null) { try { recognizer.stopListening(); } catch (Exception ignored) {} try { recognizer.cancel(); } catch (Exception ignored) {} recognizer.destroy(); recognizer = null; }
    }

    private String clean(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9\\s]", " ").replaceAll("\\s+", " ").trim();
    }

    private void listen(final boolean wake) {
        stopRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(getContext())) { emitError("Android speech recognition is unavailable on this device. Text and offline NOVA features remain available."); emitState("idle"); return; }
        wakeMode = wake; commandMode = !wake; emitState(wake ? "wake" : "command");
        recognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { emitState(wake ? "wake" : "command"); }
            public void onBeginningOfSpeech() { emitState(wake ? "wake-speaking" : "command-speaking"); }
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onPartialResults(Bundle b) {
                if (!wakeMode) return;
                ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(a!=null&&!a.isEmpty()) checkWake(a.get(0));
            }
            public void onEvent(int t, Bundle p) {}
            public void onError(int e) {
                String msg;
                switch(e){case SpeechRecognizer.ERROR_AUDIO: msg="Microphone audio error."; break; case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: msg="Microphone permission is missing."; break; case SpeechRecognizer.ERROR_NETWORK: msg="Speech service network error. Try again; NOVA's local features do not need an API key."; break; case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: msg="Speech service timed out. Try again."; break; case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: msg="Speech recognizer was busy. Retrying."; break; default: msg="Speech recognition error. Try again.";}
                emitError(msg);
                if (wakeMode && restartWake == false) new android.os.Handler().postDelayed(() -> { if (wakeMode) listen(true); }, 500); else emitState("idle");
            }
            public void onResults(Bundle b) {
                ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text=(a!=null&&!a.isEmpty())?a.get(0).trim():"";
                if(wakeMode) checkWake(text); else if(!text.isEmpty()){emit("command",text);emitState("idle");}
            }
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault().toLanguageTag());
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,Locale.getDefault().toLanguageTag());
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,wake);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,5);
        recognizer.startListening(i);
    }

    private void checkWake(String text) {
        String n=clean(text);
        String[] wakePhrases={"hey nova","hey no va","hey nava","a nova","hey noah"};
        for(String phrase:wakePhrases){int p=n.indexOf(phrase);if(p>=0){String after=n.substring(p+phrase.length()).trim();emit("wakeWord","hey nova");if(!after.isEmpty()){stopRecognizer();wakeMode=false;commandMode=true;emitState("command");emit("command",after);}else listen(false);return;}}
    }

    @PluginMethod public void startWakeWord(PluginCall call){if(!ensureMic(call,true)){return;}restartWake=false;listen(true);call.resolve();}
    @PluginMethod public void stopWakeWord(PluginCall call){restartWake=false;wakeMode=false;commandMode=false;stopRecognizer();emitState("idle");call.resolve();}
    @PluginMethod public void startCommand(PluginCall call){if(!ensureMic(call,false)){return;}restartWake=false;listen(false);call.resolve();}
    @PluginMethod public void speak(PluginCall call){String text=call.getString("text","");if(tts!=null&&!text.isEmpty())tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"nova");call.resolve();}
    @Override protected void handleOnDestroy(){stopRecognizer();if(tts!=null)tts.shutdown();super.handleOnDestroy();}
}

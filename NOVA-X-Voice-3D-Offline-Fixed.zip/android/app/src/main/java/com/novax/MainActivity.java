package com.novax;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,48,32,24);
        TextView title = new TextView(this); title.setText("NOVA-X"); title.setTextSize(32); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView subtitle = new TextView(this); subtitle.setText("Local-first personal AI"); subtitle.setTextSize(16);
        EditText input = new EditText(this); input.setHint("Say or type: Hey Nova..."); input.setSingleLine(false);
        Button ask = new Button(this); ask.setText("Ask NOVA");
        TextView output = new TextView(this); output.setText("Ready. Core processing can run locally; heavyweight model adapters are device-dependent."); output.setTextSize(16); output.setPadding(0,24,0,0);
        ask.setOnClickListener(v -> output.setText("Received: " + input.getText().toString() + "\n\nConnect the local model adapter to enable full on-device conversation."));
        root.addView(title); root.addView(subtitle); root.addView(input, new LinearLayout.LayoutParams(-1,0,1)); root.addView(ask); root.addView(output);
        setContentView(root);
    }
}

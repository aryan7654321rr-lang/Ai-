# NOVA-X device test checklist

The following tests require the generated APK/WebView on a real Android device. They are intentionally not marked as passed by the repository build.

## Basic
- [ ] APK installs and launches
- [ ] Home screen renders without overflow
- [ ] Navigation works
- [ ] Local storage survives restart
- [ ] Project JSON export works

## Voice
- [ ] SpeechRecognition/native speech bridge works
- [ ] Hindi + English mixed speech
- [ ] Accent/pronunciation variation
- [ ] Noisy speech / transcription mistakes
- [ ] Permission denial has a usable fallback

## Game
- [ ] Game plan generation completes
- [ ] Rendering preview works
- [ ] Device profile is sensible
- [ ] Low/mid/high quality settings behave correctly
- [ ] Memory remains stable during long sessions

## Animation
- [ ] 15-second preview renders
- [ ] Long storyboard creation does not freeze UI
- [ ] Pause/resume can be added to the chosen native renderer
- [ ] 10-minute project can be rendered by the native engine on target hardware

## Performance
Record: phone model, Android version, RAM, free storage, FPS, render time, temperature, crashes.

If a test fails, send the exact error/log/screenshot. Do not summarize the error if the raw message is available.

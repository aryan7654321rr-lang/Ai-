import tempfile, unittest
from pathlib import Path
from nova_core import *

class TestNova(unittest.TestCase):
    def test_typo_normalization(self):
        n=UnderstandingEngine().understand('Plz cn u help me')
        self.assertEqual(n.normalized, 'please can you help me')
        self.assertEqual(n.language, 'en')
    def test_hindi_detection(self):
        self.assertEqual(UnderstandingEngine().understand('नमस्ते Nova').language, 'hi')
    def test_game_plan(self):
        r=Nova(Path(tempfile.mkdtemp())).handle('make an anime RPG game', DeviceProfile(3,4,'low'))
        self.assertEqual(r['status'],'ok'); self.assertEqual(r['plan']['optimization']['profile'],'low')
    def test_anime_plan(self):
        r=Nova(Path(tempfile.mkdtemp())).handle('make a 10 minute anime video')
        self.assertEqual(r['plan']['duration_minutes'],10)
        self.assertEqual(r['plan']['scene_count'],60)
    def test_ambiguity(self):
        r=Nova(Path(tempfile.mkdtemp())).handle('x')
        self.assertEqual(r['status'],'clarify')
    def test_memory_persistence(self):
        d=Path(tempfile.mkdtemp()); m=Memory(d/'memory.json'); m.remember('style','anime'); m2=Memory(d/'memory.json'); self.assertEqual(m2.data['preferences']['style'],'anime')

if __name__=='__main__': unittest.main()

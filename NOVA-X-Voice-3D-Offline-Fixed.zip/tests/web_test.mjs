import fs from 'node:fs'; import assert from 'node:assert/strict';
const root=new URL('..',import.meta.url).pathname;
const app=fs.readFileSync(root+'src/App.vue','utf8'); const css=fs.readFileSync(root+'src/style.css','utf8');
assert.match(app,/SpeechRecognition|webkitSpeechRecognition/); assert.match(app,/localStorage/); assert.match(app,/generateGame/); assert.match(app,/generateAnime/); assert.match(app,/exportProject/); assert.match(app,/deviceMemory/); assert.match(app,/detectLanguage/); assert.match(app,/normalizeText/); assert.match(css,/\.nav/); assert.match(css,/\.quick-grid/);
const pkg=JSON.parse(fs.readFileSync(root+'package.json','utf8')); assert.equal(pkg.name,'nova-x-local-first');
console.log('NOVA web/static checks: 9/9 passed');

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nova_core import Nova, DeviceProfile
import json
n=Nova(Path('.nova_demo'))
print(json.dumps(n.handle('Make an anime fantasy RPG with a magical wolf', DeviceProfile(4,10,'mid')), ensure_ascii=False, indent=2))

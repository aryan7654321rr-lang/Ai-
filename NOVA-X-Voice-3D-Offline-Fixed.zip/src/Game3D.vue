<template>
  <div class="game3d-shell">
    <canvas ref="canvas" class="game3d-canvas"></canvas>
    <div class="game3d-hud">
      <div class="hud-title">{{ config.title }}</div>
      <div class="hud-sub">{{ config.genre }} · {{ quality }} · {{ enemies.length }} enemies</div>
      <div class="hud-bar"><span :style="{width: playerHp + '%'}"></span></div>
      <div class="hud-stats">HP {{ playerHp }} · XP {{ xp }} · Wave {{ wave }}</div>
      <div class="hud-help">WASD / arrows · SPACE attack · drag orbit · wheel zoom</div><div class="touch-controls"><button @pointerdown="touchKey('w',true)" @pointerup="touchKey('w',false)" @pointerleave="touchKey('w',false)">▲</button><div><button @pointerdown="touchKey('a',true)" @pointerup="touchKey('a',false)">◀</button><button @pointerdown="touchKey('s',true)" @pointerup="touchKey('s',false)">▼</button><button @pointerdown="touchKey('d',true)" @pointerup="touchKey('d',false)">▶</button></div><button class="attack" @pointerdown="attack">⚔</button></div>
    </div>
    <div class="game3d-badge">REAL-TIME 3D</div>
  </div>
</template>

<script setup>
import { onMounted, onBeforeUnmount, ref, watch } from 'vue'
import * as THREE from 'three'

const props = defineProps({ prompt: { type: String, default: '' }, quality: { type: String, default: 'Recommended' }, character: { type: String, default: 'hero' }, visualStyle: { type: String, default: 'cinematic' } })
const canvas = ref(null)
const playerHp = ref(100), xp = ref(0), wave = ref(1)
const enemies = ref([])
let renderer, scene, camera, clock, raf, resizeObserver
let player, sword, targetRing, ground
let enemyObjects = [], treeObjects = [], key = {}
let orbit = { theta: 0.7, phi: 0.95, radius: 15, dragging: false, x: 0, y: 0 }
let attackUntil = 0, lastHit = 0

const config = { title: 'NOVA 3D Fantasy Adventure', genre: props.visualStyle === 'scifi' ? 'Sci-fi cinematic' : props.visualStyle === 'dark' ? 'Dark fantasy' : 'Anime fantasy' }
function touchKey(k,v){key[k]=v}

function qualityScale() {
  return props.quality === 'Maximum' ? 1.3 : props.quality === 'High' ? 1.1 : props.quality === 'Balanced' ? 0.9 : 0.75
}
function makeMat(color, roughness=0.75, metalness=0.05){ return new THREE.MeshStandardMaterial({color,roughness,metalness}) }
function addBox(parent, size, pos, color, rot={}) { const m=new THREE.Mesh(new THREE.BoxGeometry(...size),makeMat(color)); m.position.set(...pos); m.rotation.set(rot.x||0,rot.y||0,rot.z||0); parent.add(m); return m }
function addSphere(parent, r, pos, color, scale=[1,1,1]) { const m=new THREE.Mesh(new THREE.SphereGeometry(r,20,14),makeMat(color)); m.position.set(...pos); m.scale.set(...scale); parent.add(m); return m }
function addTree(x,z,s=1){ const g=new THREE.Group(); g.position.set(x,0,z); const trunk=addBox(g,[0.45*s,2.2*s,0.45*s],[0,1.1*s,0],0x563b2b); const crown=addSphere(g,1.45*s,[0,2.7*s,0],0x1d6a43,[1,1.25,1]); const crown2=addSphere(g,1.0*s,[0,4.0*s,0],0x2f8b50); scene.add(g); treeObjects.push(g) }
function addCrystal(x,z,s=1){ const g=new THREE.Group();g.position.set(x,0,z); const m=new THREE.Mesh(new THREE.OctahedronGeometry(0.65*s,0),makeMat(0x8b6cff,0.35,0.25));m.position.y=0.7*s;m.rotation.y=Math.PI/4;g.add(m);scene.add(g); }
function makePlayer(){ const g=new THREE.Group(); g.position.set(0,0.65,0); const bodyColor=props.character==='mage'?0x7b4cff:props.character==='ranger'?0x35a875:props.character==='knight'?0xcbd7ee:0x4c8cff; const body=addBox(g,[0.85,1.35,0.5],[0,0.9,0],bodyColor); const head=addSphere(g,0.42,[0,1.85,0],0xe8c3a4,[0.95,1.05,0.95]); const hair=addSphere(g,0.46,[0,2.05,-0.03],0x201d32,[1,0.55,1]); const eye=addSphere(g,0.055,[0.17,1.88,0.38],0xffffff); const eye2=eye.clone();eye2.position.x=-0.17;g.add(eye2); const leg1=addBox(g,[0.28,0.9,0.35],[-0.25,-0.1,0],0x293b69); const leg2=leg1.clone();leg2.position.x=0.25;g.add(leg2); sword=addBox(g,[0.12,1.7,0.18],[0.72,1.05,0],0xdfe8ff,{z:-0.28}); sword.rotation.z=-0.45; g.add(sword); scene.add(g); return g }
function makeEnemy(i){ const g=new THREE.Group(); const angle=(i/Math.max(1,enemyCount()))*Math.PI*2; const r=5.5+(i%3)*2; g.position.set(Math.cos(angle)*r,0.65,Math.sin(angle)*r); const body=addSphere(g,0.8,[0,0.55,0],i%2?0xa34cff:0xd34f69,[1,0.85,1]); const head=addSphere(g,0.5,[0,1.35,0],0x7b315e,[1.05,1,1]); const horn=addSphere(g,0.22,[0.28,1.75,0],0xe6b5ff,[0.7,1.8,0.7]); const horn2=horn.clone();horn2.position.x=-0.28;g.add(horn2); const eye=addSphere(g,0.08,[0.18,1.4,0.44],0xffe67d); const eye2=eye.clone();eye2.position.x=-0.18;g.add(eye2); scene.add(g); enemyObjects.push({group:g,hp:100,alive:true,seed:i*17}); return g }
function enemyCount(){ return props.quality==='Maximum'?9:props.quality==='High'?8:6 }
function buildWorld(){
  scene=new THREE.Scene(); scene.background=new THREE.Color(0x081322); scene.fog=new THREE.Fog(0x081322,18,42)
  camera=new THREE.PerspectiveCamera(55,1,0.1,100); clock=new THREE.Clock()
  renderer=new THREE.WebGLRenderer({canvas:canvas.value,antialias:props.quality!=='Recommended',powerPreference:'high-performance'}); renderer.setPixelRatio(Math.min(window.devicePixelRatio,props.quality==='Maximum'?2:1.25)); renderer.shadowMap.enabled=props.quality!=='Recommended'; renderer.shadowMap.type=THREE.PCFSoftShadowMap
  const hemi=new THREE.HemisphereLight(0x9cc8ff,0x16351f,2.1);scene.add(hemi); const sun=new THREE.DirectionalLight(0xffe7b0,3.0);sun.position.set(8,14,5);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);scene.add(sun)
  ground=new THREE.Mesh(new THREE.PlaneGeometry(55,55,18,18),new THREE.MeshStandardMaterial({color:0x214c36,roughness:1}));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground)
  for(let i=0;i<38;i++){ const x=(Math.random()-0.5)*46,z=(Math.random()-0.5)*46;if(Math.hypot(x,z)>5)addTree(x,z,0.7+Math.random()*0.7) }
  for(let i=0;i<16;i++){const a=Math.random()*Math.PI*2,r=4+Math.random()*16;addCrystal(Math.cos(a)*r,Math.sin(a)*r,0.5+Math.random()*0.7)}
  player=makePlayer(); targetRing=new THREE.Mesh(new THREE.RingGeometry(0.8,0.95,32),new THREE.MeshBasicMaterial({color:0x63d8ff,side:THREE.DoubleSide,transparent:true,opacity:0.7}));targetRing.rotation.x=-Math.PI/2;targetRing.position.y=0.03;scene.add(targetRing)
  for(let i=0;i<enemyCount();i++)makeEnemy(i)
  resize(); animate()
}
function resize(){if(!renderer)return;const el=canvas.value.parentElement;const w=el.clientWidth,h=Math.max(360,el.clientHeight);renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
function attack(){ if(performance.now()<attackUntil)return;attackUntil=performance.now()+420; sword.rotation.z=-1.4; const p=player.position; for(const e of enemyObjects){if(!e.alive)continue;const d=e.group.position.distanceTo(p);if(d<3){e.hp-=40;e.group.scale.setScalar(1.15);setTimeout(()=>e.group.scale.setScalar(1),100);if(e.hp<=0){e.alive=false;e.group.visible=false;xp.value+=25}}} }
function update(dt){ if(!player)return; const dir=new THREE.Vector3((key.d||key.arrowright?1:0)-(key.a||key.arrowleft?1:0),0,(key.s||key.arrowdown?1:0)-(key.w||key.arrowup?1:0));if(dir.lengthSq())dir.normalize();player.position.addScaledVector(dir,dt*5.2);player.position.x=THREE.MathUtils.clamp(player.position.x,-20,20);player.position.z=THREE.MathUtils.clamp(player.position.z,-20,20);targetRing.position.x=player.position.x;targetRing.position.z=player.position.z
  if(dir.lengthSq())player.rotation.y=Math.atan2(dir.x,dir.z); if(performance.now()>attackUntil)sword.rotation.z=THREE.MathUtils.lerp(sword.rotation.z,-0.45,0.18)
  for(const e of enemyObjects){if(!e.alive)continue;const to=player.position.clone().sub(e.group.position);to.y=0;const d=to.length();if(d>2.1){to.normalize();e.group.position.addScaledVector(to,dt*(1.2+(e.seed%3)*0.18));e.group.rotation.y=Math.atan2(to.x,to.z)}else if(performance.now()-lastHit>900){lastHit=performance.now();playerHp.value=Math.max(0,playerHp.value-6)}e.group.position.y=0.65+Math.sin(performance.now()/500+e.seed)*0.08}
  const alive=enemyObjects.filter(e=>e.alive).length;if(alive===0){wave.value++;for(let i=0;i<enemyObjects.length;i++){enemyObjects[i].hp=100;enemyObjects[i].alive=true;enemyObjects[i].group.visible=true;const a=(i/enemyObjects.length)*Math.PI*2;enemyObjects[i].group.position.set(Math.cos(a)*(6+wave.value),0.65,Math.sin(a)*(6+wave.value))}}
  const r=orbit.radius;camera.position.set(player.position.x+Math.sin(orbit.theta)*Math.sin(orbit.phi)*r,player.position.y+Math.cos(orbit.phi)*r,player.position.z+Math.cos(orbit.theta)*Math.sin(orbit.phi)*r);camera.lookAt(player.position.x,player.position.y+1,player.position.z)
}
function animate(){raf=requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),0.05);update(dt);renderer.render(scene,camera)}
function keydown(e){key[e.key.toLowerCase()]=true;if(e.code==='Space'){e.preventDefault();attack()}}
function keyup(e){key[e.key.toLowerCase()]=false}
function pointerdown(e){orbit.dragging=true;orbit.x=e.clientX;orbit.y=e.clientY}
function pointermove(e){if(!orbit.dragging)return;orbit.theta-=(e.clientX-orbit.x)*0.008;orbit.phi=THREE.MathUtils.clamp(orbit.phi+(e.clientY-orbit.y)*0.006,0.35,1.4);orbit.x=e.clientX;orbit.y=e.clientY}
function pointerup(){orbit.dragging=false}
function wheel(e){orbit.radius=THREE.MathUtils.clamp(orbit.radius+e.deltaY*0.01,7,24)}
onMounted(()=>{buildWorld();window.addEventListener('keydown',keydown);window.addEventListener('keyup',keyup);window.addEventListener('resize',resize);canvas.value.addEventListener('pointerdown',pointerdown);canvas.value.addEventListener('pointermove',pointermove);window.addEventListener('pointerup',pointerup);canvas.value.addEventListener('wheel',wheel,{passive:true});resizeObserver=new ResizeObserver(resize);resizeObserver.observe(canvas.value.parentElement)})
onBeforeUnmount(()=>{cancelAnimationFrame(raf);window.removeEventListener('keydown',keydown);window.removeEventListener('keyup',keyup);window.removeEventListener('resize',resize);window.removeEventListener('pointerup',pointerup);resizeObserver?.disconnect();renderer?.dispose()})
watch(()=>props.quality,()=>{if(renderer){cancelAnimationFrame(raf);renderer.dispose();enemyObjects=[];treeObjects=[];buildWorld()}})
</script>

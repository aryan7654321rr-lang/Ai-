from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json, re, hashlib, textwrap
from typing import Any

@dataclass
class Understanding:
    raw: str
    normalized: str
    language: str
    intent: str
    confidence: float
    needs_clarification: bool = False

@dataclass
class DeviceProfile:
    ram_gb: float
    storage_free_gb: float
    gpu_class: str
    charging: bool = False

class Memory:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data = json.loads(path.read_text()) if path.exists() else {"preferences": {}, "facts": [], "projects": {}}
    def remember(self, key: str, value: Any):
        self.data["preferences"][key] = value
        self.save()
    def add_fact(self, fact: str):
        if fact not in self.data["facts"]: self.data["facts"].append(fact)
        self.save()
    def save(self): self.path.write_text(json.dumps(self.data, ensure_ascii=False, indent=2))

class UnderstandingEngine:
    def normalize(self, text: str) -> str:
        s = re.sub(r"\s+", " ", text.strip())
        # Conservative common speech/transcription corrections; never silently alter names.
        replacements = {"plz":"please", "pls":"please", "u":"you", "ur":"your", "cn":"can"}
        words = [replacements.get(w.lower(), w) for w in s.split()]
        return " ".join(words)
    def detect_language(self, text: str) -> str:
        # Lightweight heuristic; production build can swap in a local language-ID model.
        if re.search(r"[\u0900-\u097F]", text): return "hi"
        if re.search(r"[\u4e00-\u9fff]", text): return "zh"
        if re.search(r"[\u3040-\u30ff]", text): return "ja"
        if re.search(r"[\uac00-\ud7af]", text): return "ko"
        return "en"
    def intent(self, text: str) -> str:
        t = text.lower()
        if any(k in t for k in ["game", "rpg", "gameplay", "quest"]): return "game_create"
        if any(k in t for k in ["anime", "video", "animation"]): return "anime_create"
        if any(k in t for k in ["pdf", "document"]): return "document"
        if any(k in t for k in ["search", "internet", "latest", "research"]): return "web_research"
        if any(k in t for k in ["remember", "memory"]): return "memory"
        return "chat"
    def understand(self, text: str) -> Understanding:
        n = self.normalize(text); lang = self.detect_language(n); intent = self.intent(n)
        ambiguous = len(n) < 2
        return Understanding(text, n, lang, intent, 0.55 if ambiguous else 0.92, ambiguous)

class DeviceOptimizer:
    def recommend(self, d: DeviceProfile) -> dict:
        if d.ram_gb <= 3 or d.gpu_class == "low":
            return {"profile":"low", "render_scale":0.65, "texture":"compressed-low", "shadows":"baked", "effects":"limited", "stream_assets":True}
        if d.ram_gb <= 6 or d.gpu_class == "mid":
            return {"profile":"balanced", "render_scale":0.8, "texture":"compressed-mid", "shadows":"mixed", "effects":"medium", "stream_assets":True}
        return {"profile":"high", "render_scale":1.0, "texture":"high-compressed", "shadows":"dynamic", "effects":"high", "stream_assets":True}

class GamePlanner:
    def plan(self, prompt: str, device: DeviceProfile) -> dict:
        opt = DeviceOptimizer().recommend(device)
        return {"type":"game", "title":"NOVA Generated Game", "prompt":prompt,
                "world":{"terrain":"procedural", "biomes":["forest","mountain","village"], "streaming":True},
                "systems":["quests","NPC AI","combat","inventory","save/checkpoints","day-night","weather"],
                "assets":{"characters":"procedural/modular","creatures":"original modular rigs","props":"procedural/licensed"},
                "optimization":opt,
                "export":["android","pc","zip"]}

class AnimePlanner:
    def plan(self, prompt: str, minutes: int = 10) -> dict:
        scenes = max(1, minutes * 6)
        return {"type":"anime", "prompt":prompt, "duration_minutes":minutes, "scene_count":scenes,
                "pipeline":["story plan","character consistency","licensed/procedural backgrounds","2D/2.5D animation","lip sync","audio","subtitles","chunked render","hardware encode"],
                "copyright_guard":"use original or properly licensed assets"}

class Summarizer:
    def summarize(self, sources: list[dict], local: list[str]) -> dict:
        snippets = []
        for s in sources[:8]:
            title = s.get("title", "Source")
            body = re.sub(r"\s+", " ", s.get("text", ""))[:400]
            snippets.append(f"{title}: {body}")
        return {"summary":"\n".join(snippets + local[:8]), "source_count":len(sources), "local_count":len(local), "source_ids":[s.get("id") for s in sources]}

class Nova:
    def __init__(self, root: Path):
        self.root = root; self.memory = Memory(root/"memory.json"); self.understanding = UnderstandingEngine()
    def handle(self, text: str, device: DeviceProfile | None = None) -> dict:
        u = self.understanding.understand(text)
        if u.needs_clarification: return {"status":"clarify", "understanding":asdict(u)}
        result = {"status":"ok", "understanding":asdict(u)}
        if u.intent == "game_create": result["plan"] = GamePlanner().plan(u.normalized, device or DeviceProfile(4,8,"mid"))
        elif u.intent == "anime_create": result["plan"] = AnimePlanner().plan(u.normalized)
        elif u.intent == "memory": result["memory"] = "Memory operation requires explicit user-approved content."
        else: result["response"] = f"NOVA understood your request in {u.language}: {u.normalized}"
        return result

def fingerprint_tree(root: Path) -> str:
    h=hashlib.sha256()
    for p in sorted(x for x in root.rglob('*') if x.is_file()):
        h.update(str(p.relative_to(root)).encode()); h.update(p.read_bytes())
    return h.hexdigest()

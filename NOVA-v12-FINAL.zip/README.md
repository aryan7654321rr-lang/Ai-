# NOVA v12

NOVA v12 is a mobile-first creative workspace with three intentionally separate experiences:

- Image Studio
- Video / Anime Studio
- Game Preview

## Game Preview

The Game area is presented as a playable game-facing screen rather than a renderer dashboard. It includes:

- interactive world preview
- hero/player presentation
- HUD
- touch movement controls
- keyboard movement on desktop browsers
- device/performance profile
- active-content cleanup
- build details that can be opened when needed

The preview is a self-contained front-end demonstration. It does not claim to be a full AAA game engine running inside the UI.

## Performance behavior

NOVA keeps hero and nearby gameplay detail protected first and reduces unnecessary work before visible gameplay quality. The asset cleanup path distinguishes active, prefetch, cached and unused content.

## Video / Anime

The video system remains a separate shot-based anime production concept with its own default 10-minute showcase prompt. It is not a renamed game renderer.

## Content rights

Downloaded content should only be used when its license/terms permit reuse or when the user owns/has permission for the content.

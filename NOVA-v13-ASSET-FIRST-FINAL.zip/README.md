# NOVA v13 — Asset-First Game Assembly

NOVA v13 changes the Game Studio philosophy: it is an **asset acquisition, rights verification, selection, conversion, optimization and world-assembly system**. It does not treat procedural/generated 3D asset creation as the normal game-production path.

## Game flow

Natural-language request → Game Director → permitted source discovery → license/rights check → asset scoring → acquisition → conversion/optimization where permitted → world assembly → mobile runtime → playable preview → QA.

## Asset-first rules

- User-owned and reuse-permitted assets are supported.
- Free-to-download does not automatically mean free-to-reuse.
- Sources that prohibit automated access must not be scraped.
- Every acquired asset should retain source/license/attribution metadata.
- Conversion is performed only when modification/conversion is permitted.
- High-quality assets are reserved for the hero, near-camera objects and important landmarks; lighter compatible variants are used farther away.
- Unused, stale and duplicate content is removed or evicted rather than kept in memory.

## Unity assets

Unity Asset Store content is licensed under the applicable Asset Store terms and individual asset license. NOVA should only acquire and convert content through a method and license that permit the intended use. This project intentionally does not include scraped Unity content.

## Current source foundation

`src/services/assetResolver.js` contains rights checks, asset scoring, acquisition planning, conversion planning and runtime cleanup classification.

`src/prompts/gamePrompt.js` contains the default asset-first Game Director prompt.

The Game screen is designed as the user-facing playable build surface rather than a separate renderer/settings screen.

## Important limitation

This ZIP is a source/studio foundation. It does not secretly bundle copyrighted Unity assets or claim that a low-end Android phone can create a console-scale AAA game from nothing. A production build needs an authorized asset-source connector/importer and a native/mobile runtime capable of loading the acquired asset package.

## Import/runtime adapters

`src/services/assetImportAdapter.js` checks an imported asset's format and rights metadata before planning conversion.

`src/runtime/runtimeManifest.js` defines the mobile runtime manifest used by the eventual native/game runtime for asset dependencies and streamed zones.

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { DEFAULT_GAME_PROMPT } from './prompts/gamePrompt';
import { DEFAULT_VIDEO_PROMPT } from './prompts/videoPrompt';
import { cleanupPlan, chooseBestAssets, buildAcquisitionPlan } from './services/assetResolver';
import { recommendAdjustments } from './engine/performanceDirector';

const panel = ref(null);
const menu = ref(false);
const gamePrompt = ref(localStorage.getItem('nova.gamePrompt') || DEFAULT_GAME_PROMPT);
const videoPrompt = ref(localStorage.getItem('nova.videoPrompt') || DEFAULT_VIDEO_PROMPT);
const device = ref(localStorage.getItem('nova.device') || 'low');
const notice = ref('NOVA READY');
const cleanup = ref([]);
const gameState = ref('PLAYABLE PREVIEW');
const gameFps = ref(30);
const showDetails = ref(false);
const acquisition = ref([]);
const selectedAssets = ref([]);
const assetSourceStatus = ref('RIGHTS-AWARE SOURCING');
const previewCanvas = ref(null);

const profiles = {
  low: { label: 'Oppo-class / Low Android', targetFps: 30, memory: 1024 },
  balanced: { label: 'Balanced Android', targetFps: 45, memory: 2048 },
  high: { label: 'High Android', targetFps: 60, memory: 4096 }
};
const currentProfile = computed(() => profiles[device.value]);

function open(p) {
  panel.value = p;
  menu.value = false;
  notice.value = p === 'game' ? 'GAME PREVIEW READY' : p === 'video' ? 'ANIME STUDIO READY' : 'IMAGE STUDIO READY';
  if (p === 'game') nextTick(startGamePreview);
}
function closePanel() { panel.value = null; stopGamePreview(); }
function savePrompt(kind) {
  localStorage.setItem(kind === 'game' ? 'nova.gamePrompt' : 'nova.videoPrompt', kind === 'game' ? gamePrompt.value : videoPrompt.value);
  notice.value = 'Prompt saved';
}
function resetPrompt(kind) {
  if (kind === 'game') gamePrompt.value = DEFAULT_GAME_PROMPT;
  else videoPrompt.value = DEFAULT_VIDEO_PROMPT;
  notice.value = 'Default prompt restored';
}
function generate(kind) {
  savePrompt(kind);
  notice.value = kind === 'game' ? 'Game preview refreshed from the build specification.' : '10-minute shot plan queued — generation stays shot-based.';
  if (kind === 'game') { gameState.value = 'BUILD PREVIEW'; nextTick(startGamePreview); }
}
function resolveAssets() {
  const candidates = [
    { id:'hero-01', name:'High Detail Hero Character', source:'Authorized Character Library', license:'commercial-license', modificationAllowed:true, quality:98, mobileCost:48, category:'character', tags:['realistic','hero','modern','rigged'], cached:true },
    { id:'hero-02', name:'Lightweight Hero Variant', source:'Authorized Character Library', license:'commercial-license', modificationAllowed:true, quality:82, mobileCost:28, category:'character', tags:['hero','mobile','rigged'], cached:true },
    { id:'city-01', name:'Modern City Environment', source:'Reuse-Permitted Environment Library', license:'reuse-permitted', modificationAllowed:true, quality:94, mobileCost:55, category:'environment', tags:['modern','city','realistic','modular'], cached:true },
    { id:'city-02', name:'Mobile City Variant', source:'Reuse-Permitted Environment Library', license:'reuse-permitted', modificationAllowed:true, quality:84, mobileCost:30, category:'environment', tags:['city','mobile','modular'], cached:true },
    { id:'blocked-01', name:'Unverified Download', source:'Unknown Website', license:'unknown', modificationAllowed:false, quality:99, mobileCost:40, category:'environment', tags:['realistic'] }
  ];
  const requirements = {
    character:{ slot:'player-character', category:'character', hero:true, tags:['realistic','hero','rigged'], mobileCostBudget:55 },
    environment:{ slot:'near-world', category:'environment', nearCamera:true, tags:['modern','city','realistic'], mobileCostBudget:65 }
  };
  selectedAssets.value = chooseBestAssets(candidates, requirements);
  acquisition.value = buildAcquisitionPlan(candidates, requirements);
  assetSourceStatus.value = 'LICENSE VERIFIED / BEST MATCHES SELECTED';
  notice.value = `${selectedAssets.value.length} permitted assets selected`;
}
function runCleanup() {
  const assets = [
    ...selectedAssets.value.map((a,i) => ({ ...a, active:i < 2, visible:true, distance:i === 0 ? 2 : 40, cached:true })),
    { name: 'Unused Variant', visible:false, cached:true, license:'reuse-permitted', modificationAllowed:true },
    { name: 'Stale Conversion Temp', visible:false, cached:true, license:'reuse-permitted', modificationAllowed:true }
  ];
  cleanup.value = cleanupPlan(assets, { nearDistance:80, prefetchDistance:260 });
  notice.value = 'UNUSED / STALE CONTENT EVICTED';
}
function optimize() {
  const actions = recommendAdjustments({ frameMs: 31, memoryMB: 780, memoryBudgetMB: currentProfile.value.memory, targetFps: currentProfile.value.targetFps });
  notice.value = 'PERFORMANCE: ' + actions[0];
}

let animationId = 0;
let keyHandler;
let resizeHandler;
let pointerId = null;
const movement = { x: 0, y: 0 };
const hero = { x: 0, z: 0, yaw: 0, speed: 0 };

function startGamePreview() {
  stopGamePreview();
  const canvas = previewCanvas.value;
  if (!canvas) return;
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) return;
  keyHandler = (e) => {
    const k = e.key.toLowerCase();
    if (['w','arrowup'].includes(k)) movement.y = -1;
    if (['s','arrowdown'].includes(k)) movement.y = 1;
    if (['a','arrowleft'].includes(k)) movement.x = -1;
    if (['d','arrowright'].includes(k)) movement.x = 1;
  };
  window.addEventListener('keydown', keyHandler);
  resizeHandler = resizePreview;
  window.addEventListener('resize', resizeHandler);
  resizePreview();
  let last = performance.now();
  const loop = (now) => {
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    updateHero(dt);
    drawPreview(ctx, canvas.width, canvas.height);
    animationId = requestAnimationFrame(loop);
  };
  animationId = requestAnimationFrame(loop);
}
function stopGamePreview() {
  cancelAnimationFrame(animationId);
  animationId = 0;
  if (keyHandler) window.removeEventListener('keydown', keyHandler);
  if (resizeHandler) window.removeEventListener('resize', resizeHandler);
  keyHandler = null; resizeHandler = null;
}
function resizePreview() {
  const canvas = previewCanvas.value;
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  canvas.width = Math.max(320, Math.floor(rect.width * dpr));
  canvas.height = Math.max(220, Math.floor(rect.height * dpr));
}
function updateHero(dt) {
  hero.speed += ((-movement.y) * 5.5 - hero.speed) * Math.min(1, dt * 8);
  hero.x += movement.x * dt * 4.2;
  hero.z += hero.speed * dt;
  hero.x = Math.max(-4.4, Math.min(4.4, hero.x));
  if (Math.abs(hero.speed) > 0.1) hero.yaw += movement.x * dt * 0.8;
  if (hero.z > 40 || hero.z < -40) hero.z = 0;
}
function drawPreview(ctx, w, h) {
  const horizon = h * 0.42;
  const cx = w / 2;
  ctx.fillStyle = '#07101d'; ctx.fillRect(0, 0, w, h);
  const sky = ctx.createLinearGradient(0, 0, 0, horizon); sky.addColorStop(0, '#06101e'); sky.addColorStop(1, '#2c4964'); ctx.fillStyle = sky; ctx.fillRect(0,0,w,horizon+2);
  ctx.fillStyle = '#17232e'; ctx.fillRect(0,horizon,w,h-horizon);
  // distant skyline
  for (let i=0;i<15;i++) {
    const bw = w/18 + (i%3)*8; const bh = 30 + ((i*37)%90); const x = i*(w/14)-20; const y = horizon-bh;
    ctx.fillStyle = i%2 ? '#101a24' : '#15212b'; ctx.fillRect(x,y,bw,bh);
    ctx.fillStyle = '#9bb3c5';
    for(let r=0;r<3;r++) for(let c=0;c<2;c++) if((i+r+c)%3===0) ctx.fillRect(x+7+c*11,y+10+r*13,4,6);
  }
  // road perspective
  ctx.fillStyle = '#1a1c20';
  ctx.beginPath(); ctx.moveTo(cx-w*.09,horizon); ctx.lineTo(cx+w*.09,horizon); ctx.lineTo(cx+w*.46,h); ctx.lineTo(cx-w*.46,h); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#34383d'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx-w*.09,horizon); ctx.lineTo(cx-w*.46,h); ctx.moveTo(cx+w*.09,horizon); ctx.lineTo(cx+w*.46,h); ctx.stroke();
  // lane markings
  ctx.strokeStyle = '#d8d5b6'; ctx.lineWidth = 3; ctx.setLineDash([18,24]); ctx.beginPath(); ctx.moveTo(cx,horizon+12); ctx.lineTo(cx,h); ctx.stroke(); ctx.setLineDash([]);
  // near props
  for (let side=-1; side<=1; side+=2) {
    for (let i=0;i<5;i++) {
      const y = horizon + 30 + i*42; const scale = 0.25 + i*0.16; const x = cx + side*(w*.13 + i*w*.065);
      ctx.fillStyle = '#11161b'; ctx.fillRect(x-22*scale,y-75*scale,44*scale,75*scale);
      ctx.fillStyle = '#24343f'; ctx.fillRect(x-17*scale,y-68*scale,34*scale,18*scale);
      ctx.fillStyle = '#10161a'; ctx.fillRect(x-3*scale,y-95*scale,6*scale,20*scale);
      ctx.beginPath(); ctx.arc(x,y-104*scale,18*scale,0,Math.PI*2); ctx.fill();
    }
  }
  // hero silhouette
  const hx = cx + hero.x*24; const hy = h*.77;
  ctx.save(); ctx.translate(hx,hy); ctx.rotate(hero.yaw*.05);
  ctx.fillStyle = '#0a0b0e'; ctx.beginPath(); ctx.ellipse(0,22,25,9,0,0,Math.PI*2); ctx.fill();
  ctx.fillStyle = '#20242b'; ctx.fillRect(-13,-40,26,54); ctx.beginPath(); ctx.arc(0,-52,13,0,Math.PI*2); ctx.fill();
  ctx.fillStyle = '#5c6570'; ctx.fillRect(-9,-65,18,5); ctx.fillStyle = '#8794a0'; ctx.fillRect(-7,-32,14,3);
  ctx.restore();
  // HUD
  ctx.fillStyle = 'rgba(3,6,10,.72)'; roundRect(ctx,18,18,150,42,12); ctx.fill();
  ctx.fillStyle = '#dbe7f2'; ctx.font = '600 12px Inter, sans-serif'; ctx.fillText('NOVA // CITY RUN',32,36);
  ctx.fillStyle = '#7f9bb2'; ctx.font = '10px Inter, sans-serif'; ctx.fillText('LIVE PREVIEW',32,51);
  ctx.fillStyle = 'rgba(3,6,10,.72)'; roundRect(ctx,w-118,18,100,42,12); ctx.fill();
  ctx.fillStyle = '#dbe7f2'; ctx.font = '600 12px Inter, sans-serif'; ctx.fillText(`${gameFps.value} FPS`,w-92,43);
}
function roundRect(ctx,x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
function setMove(x,y){movement.x=x;movement.y=y;}
function stopMove(){movement.x=0;movement.y=0;}

onMounted(() => { resolveAssets(); runCleanup(); });
onBeforeUnmount(stopGamePreview);
watch(device, () => { localStorage.setItem('nova.device', device.value); gameFps.value = currentProfile.value.targetFps; });
</script>

<template>
  <main class="app-shell">
    <header class="topbar">
      <div class="brand-wrap"><div class="nova-mark">N</div><div class="brand">NOVA</div></div>
      <div class="top-actions"><div class="status">{{notice}}</div><button class="dots" @click="menu=!menu" aria-label="Open NOVA menu">•••</button></div>
    </header>

    <div v-if="menu" class="menu">
      <button @click="open('image')"><span>IMAGE</span><small>Image Studio</small></button>
      <button @click="open('video')"><span>VIDEO / ANIME</span><small>10-minute shot production</small></button>
      <button @click="open('game')"><span>GAME</span><small>Playable build preview</small></button>
    </div>

    <section v-if="!panel" class="home">
      <div class="orbital"><div class="orbital-ring ring-a"></div><div class="orbital-ring ring-b"></div><div class="orbital-line"></div><button class="core" @click="open('game')" aria-label="Open NOVA playable game preview"><span>N</span><small>NOVA</small></button></div>
      <div class="home-caption">YOUR CREATIVE SPACE</div>
      <div class="showcase-row">
        <button class="showcase-card active" @click="open('game')"><div class="scene-thumb city-thumb"><span>PLAY</span></div><strong>GAME WORLD</strong><small>Interactive preview</small></button>
        <button class="showcase-card" @click="open('video')"><div class="scene-thumb anime-thumb"><span>ANIME</span></div><strong>ANIME STUDIO</strong><small>Shot-based production</small></button>
        <button class="showcase-card" @click="open('image')"><div class="scene-thumb image-thumb"><span>IMAGE</span></div><strong>IMAGE STUDIO</strong><small>Visual generation</small></button>
      </div>
    </section>

    <section v-else class="workspace">
      <div class="workspace-head"><button class="back" @click="closePanel">←</button><div><div class="eyebrow">NOVA / {{panel.toUpperCase()}}</div><h1>{{panel==='image'?'Image Studio':panel==='video'?'Video / Anime Studio':'Game Preview'}}</h1><p v-if="panel==='game'">See and play the generated game world before installing it.</p><p v-else-if="panel==='video'">A dedicated anime production pipeline, separate from the game system.</p><p v-else>Generate images without mixing this pipeline with game or video rendering.</p></div></div>

      <div v-if="panel==='game'" class="game-layout">
        <article class="game-screen card">
          <div class="game-toolbar"><span class="live-dot"></span><b>PLAYABLE BUILD / RUNTIME VIEW</b><span class="toolbar-spacer"></span><span>{{currentProfile.label}}</span><button @click="showDetails=!showDetails">{{showDetails?'Hide':'Build'}} details</button></div>
          <canvas ref="previewCanvas" class="game-canvas" aria-label="Interactive NOVA assembled game runtime"></canvas>
          <div class="touch-controls">
            <div class="joystick" @pointerdown="setMove(-1,0)" @pointerup="stopMove" @pointerleave="stopMove"><span>◀</span></div>
            <div class="move-cluster"><button @pointerdown="setMove(0,-1)" @pointerup="stopMove">▲</button><div><button @pointerdown="setMove(-1,0)" @pointerup="stopMove">◀</button><button @pointerdown="setMove(1,0)" @pointerup="stopMove">▶</button></div><button @pointerdown="setMove(0,1)" @pointerup="stopMove">▼</button></div>
            <div class="action-cluster"><button>◎</button><button>◆</button></div>
          </div>
          <div class="game-hint">Playable runtime surface • touch controls • Desktop: WASD / arrow keys • visual content comes from the selected asset package</div>
        </article>

        <aside class="game-side">
          <article class="card compact"><div class="pill">ASSET-FIRST GAME BUILD</div><h2>Assembled from permitted assets</h2><p>NOVA does not invent replacement 3D assets here. It finds suitable reusable or user-owned assets, verifies their rights, converts them when permitted, and combines the selected package into the playable build.</p><div class="asset-status"><span class="live-dot"></span>{{assetSourceStatus}}</div><button class="primary" @click="resolveAssets">Re-evaluate asset library</button></article>
          <article class="card compact"><h2>Selected content</h2><ul class="asset-list"><li v-for="a in selectedAssets" :key="a.id"><span>{{a.name}}</span><em class="active">{{a.score}} FIT</em></li></ul><p class="muted">Unverified sources are blocked instead of being silently used.</p></article>
          <article class="card compact"><h2>Mobile runtime</h2><select v-model="device"><option value="low">Low-end Android</option><option value="balanced">Balanced Android</option><option value="high">High Android</option></select><div class="metric-row"><b>{{currentProfile.targetFps}} FPS</b><span>{{currentProfile.memory}} MB budget</span></div><button @click="optimize">Optimize active scene</button><button @click="runCleanup">Remove unused content</button></article>
          <article v-if="showDetails" class="card compact"><h2>Acquisition plan</h2><ul class="asset-list"><li v-for="a in acquisition" :key="a.assetId"><span>{{a.assetId}}</span><em class="prefetch">{{a.action}}</em></li></ul><h2 style="margin-top:16px">Runtime cleanup</h2><ul class="asset-list"><li v-for="a in cleanup" :key="a.id || a.name"><span>{{a.name}}</span><em :class="a.state.toLowerCase()">{{a.state}}</em></li></ul><button @click="showDetails=false">Close details</button></article>
        </aside>
      </div>

      <div v-if="panel==='image'" class="studio-grid">
        <article class="card wide"><div class="pill">IMAGE STUDIO</div><h2>Visual generation</h2><div class="image-stage"><div class="image-stage-orb">N</div><div><strong>Image creation stays isolated.</strong><p>Image work does not share the game preview or anime production pipeline.</p></div></div><div class="row"><button class="primary">Generate image</button><button @click="runCleanup">Clear unused intermediates</button></div></article>
      </div>

      <div v-if="panel==='video'" class="studio-grid">
        <article class="card wide"><div class="pill">SEPARATE ANIME PIPELINE</div><h2>Default 10-minute anime showcase</h2><textarea v-model="videoPrompt"></textarea><div class="row"><button @click="resetPrompt('video')">Restore default</button><button @click="savePrompt('video')">Save</button><button class="primary" @click="generate('video')">Generate episode plan</button></div></article>
        <article class="card compact"><h2>Production</h2><p>Script → character bible → storyboard → keyframes → animation → continuity → voices → QC → edit.</p><p class="muted">Only failed shots are regenerated.</p></article>
      </div>
    </section>
  </main>
</template>

const REUSE_PERMITTED = new Set(['reuse-permitted', 'user-owned', 'public-domain', 'commercial-license']);

export function normalizeAsset(asset = {}) {
  return {
    id: asset.id || asset.name || cryptoRandomId(),
    name: asset.name || 'Unnamed asset',
    source: asset.source || 'Unknown source',
    sourceType: asset.sourceType || 'external',
    license: asset.license || 'unknown',
    licenseUrl: asset.licenseUrl || '',
    modificationAllowed: asset.modificationAllowed === true,
    redistributionAllowed: asset.redistributionAllowed === true,
    quality: Number.isFinite(asset.quality) ? asset.quality : 0,
    mobileCost: Number.isFinite(asset.mobileCost) ? asset.mobileCost : 100,
    category: asset.category || 'generic',
    tags: Array.isArray(asset.tags) ? asset.tags : [],
    variants: Array.isArray(asset.variants) ? asset.variants : [],
    cached: asset.cached === true,
    active: asset.active === true,
    visible: asset.visible !== false,
    distance: Number.isFinite(asset.distance) ? asset.distance : 9999,
  };
}

export function isReusePermitted(asset) {
  const a = normalizeAsset(asset);
  return REUSE_PERMITTED.has(a.license) && (a.modificationAllowed || a.license === 'public-domain' || a.license === 'user-owned');
}

export function scoreAsset(asset, requirement = {}) {
  const a = normalizeAsset(asset);
  if (!isReusePermitted(a)) return -Infinity;
  let score = a.quality * 1.5;
  const wantedTags = requirement.tags || [];
  const matches = wantedTags.filter(tag => a.tags.includes(tag)).length;
  score += matches * 18;
  if (requirement.category && a.category === requirement.category) score += 30;
  if (requirement.hero && a.quality >= 85) score += 25;
  if (requirement.nearCamera && a.mobileCost <= 60) score += 15;
  score -= Math.max(0, a.mobileCost - (requirement.mobileCostBudget ?? 70)) * 0.35;
  return score;
}

export function chooseBestAssets(candidates = [], requirements = {}) {
  const grouped = new Map();
  for (const raw of candidates) {
    const asset = normalizeAsset(raw);
    const requirement = requirements[asset.category] || {};
    const score = scoreAsset(asset, requirement);
    if (!Number.isFinite(score)) continue;
    const key = requirement.slot || asset.category;
    const current = grouped.get(key);
    if (!current || score > current.score) grouped.set(key, { ...asset, score });
  }
  return [...grouped.values()].sort((a, b) => b.score - a.score);
}

export function buildAcquisitionPlan(candidates = [], requirements = {}) {
  const selected = chooseBestAssets(candidates, requirements);
  return selected.map(asset => ({
    assetId: asset.id,
    action: asset.cached ? 'USE_CACHE' : 'ACQUIRE',
    source: asset.source,
    license: asset.license,
    convert: asset.modificationAllowed,
    optimize: true,
    selectedScore: Math.round(asset.score),
  }));
}

export function buildConversionPlan(asset) {
  const a = normalizeAsset(asset);
  if (!isReusePermitted(a)) return { allowed: false, reason: 'Reuse or modification permission is not verified.' };
  return {
    allowed: true,
    sourceFormat: a.sourceType,
    targetFormat: 'NOVA-MOBILE-RUNTIME',
    steps: ['validate-license', 'deduplicate', 'convert-mesh-and-materials', 'compress-textures', 'generate-mipmaps', 'build-mobile-variants', 'register-dependencies'],
  };
}

export function classifyAsset(asset, context = {}) {
  const a = normalizeAsset(asset);
  const near = context.nearDistance ?? 80;
  const prefetch = context.prefetchDistance ?? 260;
  if (!isReusePermitted(a)) return 'BLOCKED';
  if (a.active || (a.visible && a.distance < near)) return 'ACTIVE';
  if (a.visible && a.distance < prefetch) return 'PREFETCH';
  if (a.cached) return 'CACHED';
  return 'UNUSED';
}

export function cleanupPlan(assets, context = {}) {
  return assets.map(raw => {
    const a = normalizeAsset(raw);
    return { ...a, state: classifyAsset(a, context) };
  });
}

function cryptoRandomId() {
  return `asset-${Math.random().toString(36).slice(2, 10)}`;
}

import fs from 'node:fs'
const app=fs.readFileSync('src/App.vue','utf8')
const renderer=fs.readFileSync('src/core/renderer.js','utf8')
const pipeline=fs.readFileSync('src/core/pipeline.js','utf8')
for(const token of ['CREATE GAME','CREATE VIDEO','Listening…','Interactive game renderer','Interactive cinematic renderer']) if(!app.includes(token)) throw new Error(`missing ${token}`)
for(const token of ['WebGLRenderer','pointerDown','pointerMove','setMode','setQuality','render']) if(!renderer.includes(token)) throw new Error(`renderer missing ${token}`)
for(const token of ['separateAssetsFromGame','licensed-reference-search','original-character','original-environment','runtime-profiling']) if(!pipeline.includes(token)) throw new Error(`pipeline missing ${token}`)
if((app.match(/<script setup>/g)||[]).length!==1) throw new Error('script boundary')
console.log('NOVA v5 source smoke test passed')

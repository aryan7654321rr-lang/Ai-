# NOVA-X v5 — Reference-Driven Futuristic Home + Interactive Renderer

This build uses the supplied NOVA home-screen image as the visual direction: dark cinematic space, upper-left time/weather, compact upper-right menu, central animated mechanical NOVA core, voice/listening indicator, corner controls, and a compact creation dock.

## Working pieces
- Vue/Vite application shell
- Three.js renderer mounted in the home screen
- Interactive pointer orbit + wheel zoom for the rendered NOVA core
- Game / Video mode switching through the same renderer foundation
- Voice/listening state UI
- Separate game and cinematic production policies
- Shot planning and retry queue for long-form video
- Device-aware game quality policy

## Important scope boundary
This is not a claim that procedural geometry equals console-quality character assets. The final AAA/photorealistic target requires real high-detail character/environment assets or a connected generation/asset backend. This version focuses on making the renderer and futuristic home interaction real instead of hiding them behind static UI copy.

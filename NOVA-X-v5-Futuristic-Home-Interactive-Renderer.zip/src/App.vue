<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { NovaRenderer } from './core/renderer.js'
import { GAME_PIPELINE, VIDEO_PIPELINE, planShots, selectGameQuality } from './core/pipeline.js'

const mode = ref('game')
const listening = ref(true)
const settingsOpen = ref(false)
const toolsOpen = ref(false)
const voiceOpen = ref(false)
const themeOpen = ref(false)
const helpOpen = ref(false)
const prompt = ref('Create an original realistic open-world mystery adventure with a highly detailed human protagonist, believable modern city, forests, weather, exploration, dialogue, creatures and cinematic action.')
const duration = ref(10)
const quality = ref('auto')
const status = ref('NOVA core ready')
const building = ref(false)
const shotPlan = ref([])
const gamePlan = ref(null)
const viewport = ref(null)
const timeText = ref('9:41')
const dateText = ref('Tue, 26 Sep')
let renderer
let timer

const activePipeline = computed(() => mode.value === 'game' ? GAME_PIPELINE : VIDEO_PIPELINE)
const queued = computed(() => shotPlan.value.filter(s => s.status === 'queued').length)
const rendered = computed(() => shotPlan.value.filter(s => s.status === 'rendered').length)

function createGamePlan(){
  building.value=true; status.value='Building interactive high-realism world…'
  setTimeout(()=>{
    const profile=selectGameQuality({thermal:'normal'},24)
    gamePlan.value={profile, visualTarget:'maximum-practical-realism', nearField:'maximum detail', interaction:'character + camera + world controls'}
    mode.value='game'; renderer?.setMode('game'); renderer?.setQuality(profile)
    building.value=false; status.value='Interactive game renderer ready — near-field quality protected.'
  },450)
}
function createVideoPlan(){
  building.value=true; status.value='Planning cinematic shots…'
  setTimeout(()=>{
    shotPlan.value=planShots(prompt.value,Number(duration.value)); mode.value='video'; renderer?.setMode('video')
    building.value=false; status.value=`${shotPlan.value.length} shots queued for independent high-quality rendering.`
  },450)
}
function markNextRendered(){
  const s=shotPlan.value.find(x=>x.status==='queued')
  if(s){s.status='rendered';status.value=`${s.id} rendered and continuity checked.`}
}
function retryBadShot(){
  const s=shotPlan.value.find(x=>x.status==='failed')
  status.value=s?(s.status='queued',`${s.id} returned to queue.`):'No failed shots in the queue.'
}
function switchMode(m){
  mode.value=m; renderer?.setMode(m); status.value=m==='game'?'Interactive real-time renderer':'Interactive cinematic renderer'
}
function setQuality(q){
  quality.value=q; localStorage.setItem('nova-quality',q); renderer?.setQuality(q==='auto'?'hero-max':q); status.value=`Render profile · ${q.toUpperCase()}`
}
function toggleListening(){ listening.value=!listening.value; renderer?.setListening(listening.value); status.value=listening.value?'Listening for “Hey Nova”…':'Voice standby paused.' }
function updateClock(){
  const d=new Date(); timeText.value=d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}); dateText.value=d.toLocaleDateString([], {weekday:'short',day:'2-digit',month:'short'})
}

onMounted(()=>{
  updateClock(); timer=setInterval(updateClock,30000)
  quality.value=localStorage.getItem('nova-quality')||'auto'
  renderer=new NovaRenderer(viewport.value); renderer.setMode(mode.value); renderer.setQuality(quality.value==='auto'?'hero-max':quality.value); renderer.setListening(listening.value)
})
onBeforeUnmount(()=>{ clearInterval(timer); renderer?.dispose() })
</script>

<template>
<main class="home">
  <div class="ambient ambient-a"></div><div class="ambient ambient-b"></div>
  <header class="hud-top">
    <div class="clock"><strong>{{ timeText }}</strong><span>{{ dateText }}</span></div>
    <div class="divider"></div>
    <div class="weather"><span class="weather-icon">◒</span><div><strong>28°C</strong><small>New Delhi</small></div></div>
  </header>

  <section class="core-stage">
    <div ref="viewport" class="core-viewport"></div>
    <div class="core-vignette"></div>
    <div class="core-caption"><span class="voice-bars"><i></i><i></i><i></i><i></i><i></i></span><b>{{ listening ? 'Listening…' : 'Tap to speak' }}</b></div>
    <div class="mode-pills">
      <button :class="{active:mode==='game'}" @click="switchMode('game')">GAME</button>
      <button :class="{active:mode==='video'}" @click="switchMode('video')">VIDEO</button>
    </div>
  </section>

  <button class="menu-trigger" @click="settingsOpen=!settingsOpen" aria-label="Open menu"><span></span><span></span><span></span></button>
  <aside v-if="settingsOpen" class="ref-menu">
    <button @click="voiceOpen=!voiceOpen"><span>◌</span> Voice</button>
    <button @click="toolsOpen=!toolsOpen"><span>⌘</span> Tools</button>
    <button @click="themeOpen=!themeOpen"><span>◈</span> Theme</button>
    <button @click="helpOpen=!helpOpen"><span>?</span> Help</button>
    <button @click="settingsOpen=false"><span>⚙</span> Settings</button>
  </aside>

  <button class="corner-btn left" @click="switchMode(mode==='game'?'video':'game')" title="Switch mode">✦</button>
  <button class="corner-btn right" @click="toggleListening" title="Voice">☼</button>

  <section class="command-dock">
    <div class="dock-tabs"><button :class="{active:mode==='game'}" @click="switchMode('game')">CREATE GAME</button><button :class="{active:mode==='video'}" @click="switchMode('video')">CREATE VIDEO</button></div>
    <textarea v-model="prompt" :placeholder="mode==='game'?'Tell NOVA what to build…':'Describe the episode you want…'"></textarea>
    <div class="dock-bottom">
      <div class="dock-status"><span class="dot"></span><span>{{ status }}</span></div>
      <div class="dock-controls">
        <label v-if="mode==='video'">MIN <input v-model.number="duration" type="number" min="1" max="60"></label>
        <select v-model="quality" @change="setQuality(quality)"><option value="auto">AUTO</option><option value="high">HIGH</option><option value="max">MAX</option></select>
        <button class="create" :disabled="building" @click="mode==='game'?createGamePlan():createVideoPlan()">{{ building?'BUILDING…':'CREATE' }} <b>↗</b></button>
      </div>
    </div>
  </section>

  <section v-if="mode==='video' && shotPlan.length" class="mini-queue">
    <span>{{ shotPlan.length }} shots</span><span>{{ queued }} queued</span><span>{{ rendered }} rendered</span><button @click="markNextRendered">Render next</button><button @click="retryBadShot">Retry failed</button>
  </section>
  <section v-if="mode==='game' && gamePlan" class="mini-queue"><span>INTERACTIVE</span><span>HERO MAX</span><span>NEAR FIELD MAX</span><span>{{ gamePlan.profile }}</span></section>

  <div v-if="voiceOpen||toolsOpen||themeOpen||helpOpen" class="micro-panel">
    <b>{{ voiceOpen?'Voice':toolsOpen?'Tools':themeOpen?'Theme':'Help' }}</b>
    <p v-if="voiceOpen">Wake phrase: “Hey Nova”. Tap the lower-right control to pause listening.</p>
    <p v-else-if="toolsOpen">Game and video use the same renderer foundation with separate asset and quality policies.</p>
    <p v-else-if="themeOpen">Current theme: Obsidian / Electric Blue.</p>
    <p v-else>Describe a world, character, game or episode. NOVA turns it into a production plan.</p>
  </div>
</main>
</template>

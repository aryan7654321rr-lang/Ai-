import * as THREE from 'three'

export class NovaRenderer {
  constructor(host) {
    this.host=host; this.mode='game'; this.listening=true; this.drag=false; this.yaw=0; this.pitch=.05; this.distance=8
    this.scene=new THREE.Scene(); this.scene.background=new THREE.Color(0x02050a); this.scene.fog=new THREE.FogExp2(0x02060c,.025)
    this.camera=new THREE.PerspectiveCamera(42,1,.1,300); this.camera.position.set(0,1.6,8)
    this.renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance',alpha:false}); this.renderer.setPixelRatio(Math.min(devicePixelRatio||1,2)); this.renderer.setSize(1,1,false); this.renderer.shadowMap.enabled=true; this.renderer.shadowMap.type=THREE.PCFSoftShadowMap; this.renderer.outputColorSpace=THREE.SRGBColorSpace; this.renderer.toneMapping=THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure=1.15
    host.appendChild(this.renderer.domElement); this.clock=new THREE.Clock(); this.core=null; this._resize=()=>this.resize(); this._down=e=>this.pointerDown(e); this._move=e=>this.pointerMove(e); this._up=()=>this.pointerUp(); this._wheel=e=>this.wheel(e)
    window.addEventListener('resize',this._resize); host.addEventListener('pointerdown',this._down); window.addEventListener('pointermove',this._move); window.addEventListener('pointerup',this._up); host.addEventListener('wheel',this._wheel,{passive:false})
    this.buildScene(); this.resize(); this.animate()
  }
  material(color,metal=.65,rough=.25,emissive=0){return new THREE.MeshStandardMaterial({color,metalness:metal,roughness:rough,emissive:emissive?color:0,emissiveIntensity:emissive})}
  buildScene(){
    this.scene.clear()
    const hemi=new THREE.HemisphereLight(0x9fc7ff,0x080d16,1.5); this.scene.add(hemi)
    const key=new THREE.DirectionalLight(0xf0f5ff,4); key.position.set(4,8,6); key.castShadow=true; key.shadow.mapSize.set(2048,2048); this.scene.add(key)
    const blue=new THREE.PointLight(0x4d8fff,42,22,2); blue.position.set(0,1,3); this.scene.add(blue)
    const warm=new THREE.PointLight(0xffb86b,18,18,2); warm.position.set(-5,2,-2); this.scene.add(warm)
    const floor=new THREE.Mesh(new THREE.CircleGeometry(14,96),this.material(0x060a10,.35,.65)); floor.rotation.x=-Math.PI/2; floor.position.y=-1.8; floor.receiveShadow=true; this.scene.add(floor)
    const grid=new THREE.GridHelper(28,28,0x1a2a3d,0x0b1420); grid.position.y=-1.78; grid.material.transparent=true; grid.material.opacity=.22; this.scene.add(grid)
    this.core=new THREE.Group(); this.scene.add(this.core)
    const dark=this.material(0x0b1018,.9,.22), steel=this.material(0x27384d,.88,.18), silver=this.material(0x8796a8,.9,.15), blueMat=this.material(0x367dff,.55,.16,1), glass=new THREE.MeshPhysicalMaterial({color:0x06101d,metalness:.65,roughness:.08,transmission:.15,clearcoat:1,clearcoatRoughness:.08})
    const addTorus=(r,t,rot=0,mat=steel,seg=96)=>{const m=new THREE.Mesh(new THREE.TorusGeometry(r,t,18,seg),mat);m.rotation.x=rot;m.castShadow=true;this.core.add(m);return m}
    addTorus(2.45,.18,Math.PI/2,dark); addTorus(2.15,.13,Math.PI/2,silver); addTorus(1.82,.10,Math.PI/2,steel); addTorus(1.48,.08,Math.PI/2,blueMat,96)
    for(let i=0;i<12;i++){const a=i*Math.PI*2/12; const g=new THREE.Group();g.rotation.z=a;g.position.y=0; const blade=new THREE.Mesh(new THREE.CapsuleGeometry(.09,.78,6,16),dark);blade.position.set(0,2.12,0);blade.rotation.z=.25;g.add(blade);this.core.add(g)}
    for(let i=0;i<8;i++){const a=i*Math.PI*2/8; const g=new THREE.Group();g.rotation.z=a; const rail=new THREE.Mesh(new THREE.BoxGeometry(.13,1.2,.42),steel);rail.position.set(0,1.75,.05);rail.rotation.z=.28;rail.castShadow=true;g.add(rail); const light=new THREE.Mesh(new THREE.BoxGeometry(.035,.48,.03),blueMat);light.position.set(0,1.74,.28);g.add(light);this.core.add(g)}
    const hub=new THREE.Mesh(new THREE.CylinderGeometry(1.28,1.28,.45,96),dark);hub.rotation.x=Math.PI/2;hub.castShadow=true;this.core.add(hub)
    const glassHub=new THREE.Mesh(new THREE.CylinderGeometry(.98,.98,.18,96),glass);glassHub.rotation.x=Math.PI/2;glassHub.position.z=.24;this.core.add(glassHub)
    const centerRing=new THREE.Mesh(new THREE.TorusGeometry(.58,.045,14,96),blueMat);centerRing.position.z=.38;this.core.add(centerRing)
    const center=new THREE.Mesh(new THREE.SphereGeometry(.24,64,32),new THREE.MeshPhysicalMaterial({color:0x0b1727,metalness:.4,roughness:.05,emissive:0x2b6fff,emissiveIntensity:1.7,clearcoat:1}));center.position.z=.36;this.core.add(center)
    for(let i=0;i<4;i++){const arc=new THREE.Mesh(new THREE.TorusGeometry(2.72,.035,10,32,Math.PI*.72),blueMat);arc.rotation.z=i*Math.PI/2+.35;arc.rotation.x=Math.PI/2;this.core.add(arc)}
  }
  setMode(m){this.mode=m; this.status=m;}
  setListening(v){this.listening=v}
  setQuality(q){this.quality=q;const ratio={low:.8,medium:1,high:1.35,max:1.7,'hero-max':1.55,'hero-balanced':1.2,'near-hero':1}[q]||1;this.renderer.setPixelRatio(Math.min((devicePixelRatio||1)*ratio,2));this.resize()}
  pointerDown(e){this.drag=true;this.lastX=e.clientX;this.lastY=e.clientY;this.host.setPointerCapture?.(e.pointerId)}
  pointerMove(e){if(!this.drag)return;const dx=e.clientX-this.lastX,dy=e.clientY-this.lastY;this.lastX=e.clientX;this.lastY=e.clientY;this.yaw+=dx*.006;this.pitch=THREE.MathUtils.clamp(this.pitch+dy*.004,-.55,.55)}
  pointerUp(){this.drag=false}
  wheel(e){e.preventDefault();this.distance=THREE.MathUtils.clamp(this.distance+e.deltaY*.004,5,12)}
  resize(){const w=Math.max(1,this.host.clientWidth),h=Math.max(1,this.host.clientHeight);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.renderer.setSize(w,h,false)}
  animate(){this.frame=requestAnimationFrame(()=>this.animate());const t=this.clock.getElapsedTime(); if(this.core){this.core.rotation.y=this.yaw+t*.10;this.core.rotation.x=.08+this.pitch;const pulse=1+Math.sin(t*2.2)*.012;this.core.scale.setScalar(pulse)} const x=Math.sin(this.yaw)*this.distance,z=Math.cos(this.yaw)*this.distance;this.camera.position.set(x,1.25+this.pitch*2,z);this.camera.lookAt(0,0,0);this.renderer.render(this.scene,this.camera)}
  dispose(){cancelAnimationFrame(this.frame);window.removeEventListener('resize',this._resize);this.host.removeEventListener('pointerdown',this._down);window.removeEventListener('pointermove',this._move);window.removeEventListener('pointerup',this._up);this.host.removeEventListener('wheel',this._wheel);this.renderer.dispose();this.host.innerHTML=''}
}

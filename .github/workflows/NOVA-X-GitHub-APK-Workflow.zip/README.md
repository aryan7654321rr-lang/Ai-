# NOVA-X GitHub APK workflow

This repository includes `.github/workflows/build-apk.yml`.

## How to use it

1. Create a GitHub repository.
2. Upload the contents of this NOVA-X project to the repository (not the outer ZIP folder).
3. Make sure the default branch is `main` or `master`.
4. Push the files to GitHub.
5. Open **Actions** → **Build NOVA-X APK**.
6. Select **Run workflow** if it did not start automatically.
7. Wait for the workflow to finish.
8. Open the completed workflow run.
9. Under **Artifacts**, download `nova-x-debug-apk`.
10. Extract the artifact and install `app-debug.apk` on an Android device for testing.

## What the workflow does

- installs Node.js
- installs the Vue dependencies
- builds the Vue application into `dist/`
- installs Capacitor Android tooling
- creates a fresh Android wrapper around the Vue build
- installs Android SDK components
- compiles a debug APK
- uploads the APK as a GitHub Actions artifact

## Important

This creates a **debug APK** for testing. It is not a Play Store release build and it is not signed with a production signing key.

The workflow deliberately generates a fresh Capacitor Android project during CI. This prevents the incomplete development Android shell from being mistaken for the production Android wrapper.

If the workflow fails, copy the failed step's complete error text and send it back for diagnosis.

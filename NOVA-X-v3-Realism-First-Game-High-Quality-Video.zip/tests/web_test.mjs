import fs from 'node:fs'
const app = fs.readFileSync('src/App.vue','utf8')
const pipeline = fs.readFileSync('src/core/pipeline.js','utf8')
const registry = fs.readFileSync('src/assets/asset-registry.js','utf8')
for (const token of ['HIGH-REALISM GAME','HIGH-QUALITY VIDEO','High-detail human asset','ORIGINAL CHARACTERS','REFERENCE SEARCH','SHOT QUEUE']) if (!app.includes(token)) throw new Error(`missing ${token}`)
for (const token of ['hero-first','mobile-hero-LOD','licensed-reference-search','continuity-check','retry','separateAssetsFromGame']) if (!pipeline.includes(token)) throw new Error(`missing pipeline ${token}`)
for (const token of ['game:','video:','validateVideoReference']) if (!registry.includes(token)) throw new Error(`missing registry ${token}`)
if ((app.match(/<\/script>/g)||[]).length !== 1) throw new Error('script boundary issue')
console.log('NOVA next architecture smoke test passed')

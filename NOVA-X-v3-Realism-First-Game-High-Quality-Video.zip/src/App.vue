<script setup>
import { computed, onMounted, ref } from 'vue'
import { GAME_PIPELINE, VIDEO_PIPELINE, VIDEO_REFERENCE_POLICY, planShots, selectGameQuality } from './core/pipeline.js'

const mode = ref('game')
const prompt = ref('Create an original realistic mystery adventure with a highly detailed human protagonist, a believable modern city, forests, night rain, mysterious creatures, exploration, dialogue and cinematic action.')
const duration = ref(10)
const quality = ref('auto')
const status = ref('Ready')
const building = ref(false)
const shotPlan = ref([])
const gamePlan = ref(null)
const references = ref([])
const settingsOpen = ref(false)
const device = ref({ name:'Target device', ram:'detecting', gpu:'detecting', thermal:'normal' })

const activePipeline = computed(() => mode.value === 'game' ? GAME_PIPELINE : VIDEO_PIPELINE)
const queued = computed(() => shotPlan.value.filter(s => s.status === 'queued').length)
const rendered = computed(() => shotPlan.value.filter(s => s.status === 'rendered').length)

function createGamePlan() {
  building.value = true
  status.value = 'Building high-realism game specification…'
  setTimeout(() => {
    const profile = selectGameQuality(device.value, 24)
    gamePlan.value = {
      visualTarget: 'maximum-practical-realism',
      heroAsset: 'high-detail-human → device-optimized hero LOD',
      nearbyAssetTier: 'maximum practical near-field detail',
      distantWorld: 'streamed + aggressively simplified',
      profile,
      gpuPolicy: 'protect hero and near-field quality first'
    }
    mode.value = 'game'
    building.value = false
    status.value = 'Game specification ready — high-realism asset pipeline selected.'
  }, 450)
}

function createVideoPlan() {
  building.value = true
  status.value = 'Planning long-form video as independent high-quality shots…'
  setTimeout(() => {
    shotPlan.value = planShots(prompt.value, Number(duration.value))
    references.value = []
    mode.value = 'video'
    building.value = false
    status.value = `${shotPlan.value.length} shots planned. Each shot can be rendered, checked and retried independently.`
  }, 450)
}

function addReference() {
  references.value.push({
    name: 'Reference candidate',
    license: 'requires verification',
    allowed: false,
    purpose: 'camera / staging / motion reference only'
  })
  status.value = 'Reference added to review queue. NOVA must verify adaptation rights before use.'
}

function markNextRendered() {
  const next = shotPlan.value.find(s => s.status === 'queued')
  if (!next) return
  next.status = 'rendered'
  status.value = `${next.id} rendered at maximum-practical quality.`
}

function retryBadShot() {
  const bad = shotPlan.value.find(s => s.status === 'failed')
  if (bad) { bad.status = 'queued'; status.value = `${bad.id} returned to the retry queue.` }
  else status.value = 'No failed shot is currently queued.'
}

function setQuality(q) {
  quality.value = q
  localStorage.setItem('nova-quality', q)
  status.value = `Game quality policy: ${q.toUpperCase()}`
}

onMounted(() => {
  quality.value = localStorage.getItem('nova-quality') || 'auto'
})
</script>

<template>
<main class="app">
  <header class="topbar">
    <div class="brand"><span class="orb"></span><div><strong>NOVA</strong><small>REALISTIC GAME + HIGH-QUALITY VIDEO</small></div></div>
    <button class="ghost" @click="settingsOpen=!settingsOpen">⋮</button>
  </header>

  <section class="hero">
    <div class="eyebrow">SEPARATE RENDERING PIPELINES</div>
    <h1>Build for realism.<br><span>Spend compute where the viewer sees it.</span></h1>
    <p>NOVA uses a hero-first real-time pipeline for mobile games and a separate, slower shot-rendering pipeline for high-quality long-form video.</p>
  </section>

  <nav class="tabs">
    <button :class="{active:mode==='game'}" @click="mode='game'">🎮 GAME</button>
    <button :class="{active:mode==='video'}" @click="mode='video'">🎬 VIDEO</button>
  </nav>

  <section class="panel prompt-panel">
    <label>{{ mode === 'game' ? 'Describe the game' : 'Describe the video / episode' }}</label>
    <textarea v-model="prompt" />
    <div v-if="mode==='video'" class="row">
      <label class="compact">Episode length <input v-model.number="duration" type="number" min="1" max="60"> minutes</label>
    </div>
    <button class="primary" :disabled="building" @click="mode==='game' ? createGamePlan() : createVideoPlan()">
      {{ building ? 'BUILDING…' : mode==='game' ? 'BUILD HIGH-REALISM GAME' : 'PLAN HIGH-QUALITY VIDEO' }}
    </button>
  </section>

  <section class="panel pipeline">
    <div class="section-head"><div><span class="eyebrow">ACTIVE SYSTEM</span><h2>{{ activePipeline.name }}</h2></div><span class="badge">{{ activePipeline.goal }}</span></div>
    <div class="steps">
      <span v-for="(step,i) in activePipeline.stages" :key="step"><i>{{ i+1 }}</i>{{ step }}</span>
    </div>
  </section>

  <section v-if="mode==='game'" class="grid">
    <article class="panel card hero-card"><span class="eyebrow">CHARACTER FIRST</span><h2>High-detail human asset</h2><p>Generate/select a genuinely detailed human-like character first, then create optimized LODs from that source. Quality is not created by putting more GPU budget into a bad model.</p><ul><li>Face, eyes, hair, skin and clothing prioritized</li><li>High-detail source → mobile hero LODs</li><li>Nearby NPCs and creatures get the next budget</li><li>Far world is simplified only when visually safe</li></ul></article>
    <article class="panel card"><span class="eyebrow">DEVICE POLICY</span><h2>Hero-first adaptive rendering</h2><div v-if="gamePlan" class="metric"><b>{{ gamePlan.profile }}</b><span>current quality policy</span></div><div class="bars"><div><span>Player</span><b>MAX PRACTICAL</b></div><div><span>Near field</span><b>VERY HIGH</b></div><div><span>Mid field</span><b>ADAPTIVE</b></div><div><span>Far field</span><b>LOW COST</b></div></div></article>
  </section>

  <section v-else class="grid">
    <article class="panel card"><span class="eyebrow">SHOT ENGINE</span><h2>{{ shotPlan.length || '—' }} shots for {{ duration }} minutes</h2><p>Each shot is independent. A slow shot can receive more processing without making the entire episode slow or forcing every scene to use the same quality.</p><div class="stats"><span><b>{{ queued }}</b> queued</span><span><b>{{ rendered }}</b> rendered</span><span><b>{{ duration }}</b> min target</span></div></article>
    <article class="panel card"><span class="eyebrow">ORIGINAL CHARACTERS</span><h2>High-quality human-like characters</h2><p>Video characters are not the game's low-end assets. They use their own high-detail source, materials, facial performance, animation and environment-matching pipeline.</p><div class="quality-line">MAXIMUM PRACTICAL VIDEO QUALITY</div></article>
  </section>

  <section v-if="mode==='video'" class="panel references">
    <div class="section-head"><div><span class="eyebrow">REFERENCE SEARCH</span><h2>Use the internet carefully</h2></div><button @click="addReference">Add candidate</button></div>
    <p>NOVA can search for motion, camera and staging references, but only sources with appropriate reuse/adaptation rights should enter the production pipeline.</p>
    <div class="policy"><span v-for="x in VIDEO_REFERENCE_POLICY.allowed" :key="x">✓ {{ x }}</span></div>
    <div v-if="references.length" class="reference-list"><div v-for="r in references" :key="r.name"><b>{{ r.name }}</b><small>{{ r.license }} · {{ r.purpose }}</small></div></div>
  </section>

  <section v-if="mode==='video' && shotPlan.length" class="panel shots">
    <div class="section-head"><div><span class="eyebrow">SHOT QUEUE</span><h2>Generate, inspect, retry, assemble</h2></div><div class="actions"><button @click="markNextRendered">Render next</button><button @click="retryBadShot">Retry failed</button></div></div>
    <div class="shot-row" v-for="shot in shotPlan.slice(0,18)" :key="shot.id"><b>{{ shot.id }}</b><span>{{ shot.type }}</span><span>{{ shot.duration }}s</span><em :class="shot.status">{{ shot.status }}</em></div>
    <small v-if="shotPlan.length>18">Showing the first 18 shots of {{ shotPlan.length }}. Production uses the full queue.</small>
  </section>

  <section class="statusbar"><span>{{ status }}</span><span>Quality: {{ quality.toUpperCase() }}</span></section>

  <aside v-if="settingsOpen" class="settings panel">
    <div class="section-head"><h2>Settings</h2><button @click="settingsOpen=false">×</button></div>
    <p>Game quality controls the optimization policy; video quality is intentionally not forced into the mobile game's limits.</p>
    <div class="qualities"><button v-for="q in ['auto','low','medium','high','max']" :key="q" :class="{selected:quality===q}" @click="setQuality(q)">{{q}}</button></div>
    <div class="device"><b>{{ device.name }}</b><span>RAM: {{ device.ram }}</span><span>GPU: {{ device.gpu }}</span><span>Thermal: {{ device.thermal }}</span></div>
  </aside>
</main>
</template>

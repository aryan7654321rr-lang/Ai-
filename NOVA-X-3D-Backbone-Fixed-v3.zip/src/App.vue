<template>
  <div class="app-shell">
    <header class="topbar">
      <div class="brand"><span class="orb" :class="{pulse: wakeActive || listening}"></span><div><b>NOVA-X</b><small>VOICE-FIRST CREATIVE AI</small></div></div>
      <div class="status"><span :class="['dot', online ? 'ok' : 'warn']"></span>{{ online ? 'Online' : 'Offline' }}</div>
    </header>

    <main class="main">
      <section v-if="view==='home'" class="home">
        <div class="voice-hero">
          <div class="voice-ring" :class="{active: wakeActive || listening, speaking: speaking}">
            <div class="voice-core"><span></span><span></span><span></span></div>
          </div>
          <p class="eyebrow">{{ wakeActive ? 'WAKE WORD ACTIVE' : listening ? 'LISTENING FOR COMMAND' : 'VOICE-FIRST ASSISTANT' }}</p>
          <h1>Say <span>Hey Nova</span></h1>
          <p class="muted center">NOVA listens for the wake phrase, captures your next command, understands it, and answers aloud.</p>
          <div class="voice-actions">
            <button class="primary voice-toggle" @click="toggleWake">{{ wakeActive ? 'Stop Hey Nova' : 'Start Hey Nova' }}</button>
            <button class="secondary" @click="toggleCommand">{{ listening ? 'Stop listening' : 'Speak now' }}</button>
          </div>
          <div class="heard-card" v-if="heard || answer">
            <small>{{ heard ? 'HEARD' : 'NOVA' }}</small>
            <div>{{ heard || answer }}</div>
            <button v-if="answer" class="tiny" @click="speak(answer)">🔊 Replay</button>
          </div>
        </div>

        <div class="quick-grid">
          <button v-for="q in quick" :key="q.label" class="card" @click="useQuick(q.prompt)"><span>{{ q.icon }}</span><b>{{ q.label }}</b><small>{{ q.desc }}</small></button>
        </div>
        <div class="panel summary"><div class="panel-title">Creative engines</div><div class="chips"><span>Wake word</span><span>Voice replies</span><span>Playable game builder</span><span>Video clip renderer</span><span>Memory</span><span>Local-first</span></div></div>
      </section>

      <section v-else class="workspace">
        <button class="back" @click="view='home'">← Home</button>
        <div class="workspace-head"><div><p class="eyebrow">{{ titles[view].eyebrow }}</p><h2>{{ titles[view].title }}</h2><p class="muted">{{ titles[view].desc }}</p></div></div>

        <section v-if="view==='chat'" class="chat-panel panel">
          <div class="messages"><div v-for="m in messages" :key="m.id" :class="['msg',m.role]">{{ m.text }}<small v-if="m.source">{{ m.source }}</small></div></div>
          <div class="command-row"><input v-model="chatInput" @keyup.enter="sendChat" placeholder="Type or use Speak now…"><button class="mic" @click="toggleCommand">🎙</button><button class="primary" @click="sendChat">Send</button></div>
        </section>

        <section v-if="view==='game'" class="game-work">
          <div class="panel">
            <label>Game idea</label><textarea v-model="gamePrompt" rows="4"></textarea>
            <div class="row"><select v-model="quality"><option>Recommended</option><option>Balanced</option><option>High</option><option>Maximum</option></select><button class="primary" @click="generateGame">Generate 3D game</button></div>
            <div v-if="gameProgress" class="progress"><span :style="{width:gameProgress+'%'}"></span></div>
          </div>
          <div v-if="game" class="panel result">
            <div class="result-head"><div><h3>{{ game.title }}</h3><p>{{ game.summary }}</p></div><button class="primary" @click="downloadGame">Export 3D game</button></div>
            <div class="scene-grid"><div v-for="s in game.scenes" :key="s.name" class="scene"><b>{{ s.name }}</b><small>{{ s.visual }} · {{ s.gameplay }}</small></div></div>
            <Game3D :prompt="gamePrompt" :quality="quality" />
            <pre>{{ JSON.stringify(game.deviceProfile,null,2) }}</pre>
          </div>
        </section>

        <section v-if="view==='anime'" class="game-work">
          <div class="panel">
            <label>Anime/video idea</label><textarea v-model="animePrompt" rows="4"></textarea>
            <div class="row"><input v-model.number="minutes" type="number" min="1" max="10"><button class="primary" @click="generateAnime">Generate actual clips</button></div>
            <p class="muted tiny-text">NOVA renders short animated WebM clips locally from the storyboard. This is real video output, not just a timeline. Advanced AI video models can be added later as optional engines.</p>
          </div>
          <div v-if="anime" class="panel result">
            <div class="result-head"><div><h3>{{ anime.title }}</h3><p>{{ anime.summary }}</p></div><span class="badge">{{ renderedClips.length }}/{{ anime.clips.length }} rendered</span></div>
            <div class="timeline"><div v-for="c in anime.clips" :key="c.id"><b>Clip {{ c.id }}</b><span>{{ c.duration }}s — {{ c.scene }}</span><a v-if="c.url" :href="c.url" :download="`nova-clip-${c.id}.webm`">Download</a><span v-else class="muted">queued</span></div></div>
            <canvas ref="preview" width="720" height="405"></canvas>
            <button class="secondary" :disabled="rendering" @click="renderAllClips">{{ rendering ? `Rendering ${renderIndex}/${anime.clips.length}` : 'Render / re-render all clips' }}</button>
          </div>
        </section>

        <section v-if="view==='memory'" class="panel memory"><div class="row"><input v-model="memoryKey" placeholder="Memory name"><input v-model="memoryValue" placeholder="Value"><button class="primary" @click="saveMemory">Save</button></div><div v-for="(v,k) in memories" :key="k" class="memory-row"><b>{{k}}</b><span>{{v}}</span><button @click="removeMemory(k)">×</button></div></section>

        <section v-if="view==='tools'" class="tools-grid">
          <div class="panel"><h3>Voice diagnostics</h3><p>{{ voiceMode }}</p><button class="primary" @click="toggleCommand">Test microphone</button></div>
          <div class="panel"><h3>Text normalizer</h3><textarea v-model="toolText" rows="5" placeholder="Mixed languages, typos, missing punctuation…"></textarea><button class="primary" @click="normalize">Normalize</button><pre v-if="normalized">{{ normalized }}</pre></div>
          <div class="panel"><h3>Device profile</h3><button class="primary" @click="profileDevice">Analyze device</button><pre v-if="device">{{ JSON.stringify(device,null,2) }}</pre></div>
          <div class="panel"><h3>Local export</h3><p>Export your current NOVA project data as JSON.</p><button class="primary" @click="exportProject">Export project</button></div>
        </section>
      </section>
    </main>

    <nav class="nav"><button :class="{active:view==='home'}" @click="view='home'">⌂<small>Home</small></button><button :class="{active:view==='chat'}" @click="view='chat'">◉<small>Chat</small></button><button :class="{active:view==='game'}" @click="view='game'">◇<small>Game</small></button><button :class="{active:view==='anime'}" @click="view='anime'">✦<small>Anime</small></button><button :class="{active:view==='tools'}" @click="view='tools'">⚙<small>Tools</small></button></nav>
  </div>
</template>

<script setup>
import { nextTick, ref, computed } from 'vue'
import Game3D from './Game3D.vue'

const view=ref('home'), online=ref(navigator.onLine), heard=ref(''), answer=ref(''), listening=ref(false), wakeActive=ref(false), speaking=ref(false), voiceMode=ref('Browser speech bridge available when supported. On Android, NOVA-X can use the native voice bridge.')
const chatInput=ref(''), gamePrompt=ref('Create an anime fantasy adventure with a magical forest and an original spirit wolf.'), animePrompt=ref('A cinematic fantasy journey through an enchanted forest with an original spirit wolf.'), minutes=ref(2), quality=ref('Recommended')
const memoryKey=ref(''), memoryValue=ref(''), toolText=ref(''), normalized=ref(''), device=ref(null), game=ref(null), anime=ref(null), preview=ref(null), rendering=ref(false), renderIndex=ref(0), gameProgress=ref(0)
const nativeVoice = window.Capacitor?.Plugins?.NovaVoice || null
const quick=[{icon:'🎙',label:'Talk to Nova',desc:'Wake-word voice mode',prompt:'Hello Nova, what can you do?'},{icon:'🎮',label:'Create game',desc:'Generate a playable prototype',prompt:'Create an anime fantasy game with a magical forest and a spirit wolf.'},{icon:'🎬',label:'Make anime',desc:'Render real video clips',prompt:'Create a cinematic anime fantasy story.'},{icon:'🧠',label:'Remember',desc:'Save a preference',prompt:'remember that my favorite genre is fantasy'}]
const titles={chat:{eyebrow:'VOICE CHAT',title:'Talk to NOVA',desc:'Voice or text conversation with spoken responses.'},game:{eyebrow:'GAME STUDIO',title:'Build a playable game',desc:'Generate a real-time 3D game scene with 3D characters, enemies, terrain, lighting, camera and combat.'},anime:{eyebrow:'ANIME STUDIO',title:'Render animation clips',desc:'Create actual short WebM clips locally from your story.'},memory:{eyebrow:'MEMORY',title:'Your memory',desc:'Stored locally on this device.'},tools:{eyebrow:'LOCAL TOOLS',title:'Tools & diagnostics',desc:'Voice, text and device diagnostics.'}}
const messages=ref([{id:1,role:'nova',text:'Hey. I’m NOVA-X. Say “Hey Nova” and then your command.',source:'Voice-first'}])
const memories=ref(JSON.parse(localStorage.getItem('nova_memory')||'{}'))
const renderedClips=computed(()=>anime.value?.clips.filter(c=>c.url)||[])
function persist(){localStorage.setItem('nova_memory',JSON.stringify(memories.value))}
function saveMemory(){if(memoryKey.value.trim()&&memoryValue.value.trim()){memories.value[memoryKey.value.trim()]=memoryValue.value.trim();persist();memoryKey.value='';memoryValue.value=''}}
function removeMemory(k){delete memories.value[k];persist()}
function detectLanguage(t){if(/[\u0900-\u097F]/.test(t))return 'Hindi';if(/[\u4E00-\u9FFF]/.test(t))return 'Chinese';if(/[\u3040-\u30FF]/.test(t))return 'Japanese';if(/[\uAC00-\uD7AF]/.test(t))return 'Korean';return 'English/Latin'}
function normalizeText(t){const x=t.trim().replace(/\s+/g,' ').replace(/\bplz\b/gi,'please').replace(/\bu\b/gi,'you').replace(/\bur\b/gi,'your');return {text:x,language:detectLanguage(x),confidence:x.length?0.9:0}}
function respond(t){const n=normalizeText(t), low=n.text.toLowerCase();if(/remember|याद/.test(low)){const m=n.text.match(/remember(?: that)?\s+(.+)/i);if(m){memories.value.last_request=m[1];persist();return `I saved that locally: ${m[1]}.`}}if(/game|खेल/.test(low)){gamePrompt.value=n.text;view.value='game';generateGame();return 'I’m building the playable game now.'}if(/anime|video|movie/.test(low)){animePrompt.value=n.text;view.value='anime';generateAnime();return 'I’m preparing the animation clips now.'}if(/what can|help/.test(low))return 'I can listen for Hey Nova, answer by voice, remember approved preferences, build playable games, render animation clips, and work offline for local features.';return `I understood: ${n.text}.`}
function speak(text){if(!text)return;if(nativeVoice?.speak){nativeVoice.speak({text});speaking.value=true;setTimeout(()=>speaking.value=false,Math.min(12000,Math.max(1200,text.length*55)));return}if('speechSynthesis' in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang=navigator.language||'en-US';u.onstart=()=>speaking.value=true;u.onend=()=>speaking.value=false;speechSynthesis.speak(u)}}
function handleCommand(text){heard.value=text;const r=respond(text);answer.value=r;messages.value.push({id:Date.now(),role:'user',text});messages.value.push({id:Date.now()+1,role:'nova',text:r,source:'Voice'});speak(r)}
function setupNative(){if(!nativeVoice)return false;nativeVoice.addListener('wakeWord',()=>{wakeActive.value=true});nativeVoice.addListener('command',e=>{listening.value=false;handleCommand(e.text||'')});nativeVoice.addListener('state',e=>{if(e.state==='wake')wakeActive.value=true;if(e.state==='command')listening.value=true;if(e.state==='idle'){wakeActive.value=false;listening.value=false}});return true}
setupNative()
function browserRecognize(commandMode=true){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){voiceMode.value='Speech recognition is unavailable in this WebView. The Android native voice bridge is required.';return}const r=new SR();r.lang=navigator.language||'en-US';r.interimResults=false;r.maxAlternatives=3;r.continuous=!commandMode;listening.value=commandMode;r.onresult=e=>{const transcript=Array.from(e.results).map(x=>x[0].transcript).join(' ').trim();if(commandMode){handleCommand(transcript);listening.value=false}else{const m=transcript.match(/\bhey\s+nova\b[,.!?\s]*(.*)/i);if(m){wakeActive.value=true;if(m[1].trim())handleCommand(m[1].trim());else browserRecognize(true)}}};r.onerror=e=>{voiceMode.value=`Voice error: ${e.error}`;listening.value=false};r.onend=()=>{if(!commandMode&&wakeActive.value&&!nativeVoice)browserRecognize(false);else if(commandMode)listening.value=false};try{r.start()}catch{voiceMode.value='Voice recognizer is already running.'}}
function toggleWake(){if(nativeVoice?.startWakeWord){if(wakeActive.value){nativeVoice.stopWakeWord();wakeActive.value=false}else{nativeVoice.startWakeWord();wakeActive.value=true}return}if(wakeActive.value){wakeActive.value=false;listening.value=false}else{wakeActive.value=true;browserRecognize(false)}}
function toggleCommand(){if(nativeVoice?.startCommand){nativeVoice.startCommand();listening.value=true;return}browserRecognize(true)}
function sendChat(){if(!chatInput.value.trim())return;handleCommand(chatInput.value);chatInput.value=''}
function useQuick(q){if(/game/i.test(q)){gamePrompt.value=q;view.value='game';generateGame()}else if(/anime|video/i.test(q)){animePrompt.value=q;view.value='anime';generateAnime()}else{handleCommand(q)}}

function gameHtml(){
  const safe=gamePrompt.value.replace(/\\/g,'\\\\').replace(/`/g,'\\`').replace(new RegExp('<' + '/script','gi'), '<' + '\\/script');
  const closeScript = '<' + '/script>'
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NOVA-X 3D Game</title><style>html,body{margin:0;height:100%;overflow:hidden;background:#07111d;color:white;font-family:system-ui}canvas{display:block;width:100%;height:100%}#ui{position:fixed;z-index:3;left:14px;top:14px;padding:12px 14px;border:1px solid #38527f;border-radius:14px;background:#071321dd;backdrop-filter:blur(8px)}#hp{width:180px;height:7px;background:#172235;border-radius:8px;overflow:hidden;margin-top:8px}#hp i{display:block;height:100%;width:100%;background:#53e6a6}.help{color:#aebdde;font-size:12px;margin-top:5px}</style></head><body><div id="ui"><b>NOVA-X REAL-TIME 3D</b><div>${safe}</div><div id="hp"><i></i></div><div class="help">WASD / arrows move · SPACE attack · drag orbit · wheel zoom</div></div><script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js"}}${closeScript}<script type="module">
import * as THREE from 'three';
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;document.body.appendChild(renderer.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color(0x081322);scene.fog=new THREE.Fog(0x081322,18,42);const camera=new THREE.PerspectiveCamera(55,1,.1,100);
scene.add(new THREE.HemisphereLight(0x9cc8ff,0x16351f,2.1));const sun=new THREE.DirectionalLight(0xffe7b0,3);sun.position.set(8,14,5);sun.castShadow=true;scene.add(sun);
const ground=new THREE.Mesh(new THREE.PlaneGeometry(55,55,18,18),new THREE.MeshStandardMaterial({color:0x214c36,roughness:1}));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
const mat=(c)=>new THREE.MeshStandardMaterial({color:c,roughness:.72});const trees=[];for(let i=0;i<30;i++){let x=(Math.random()-.5)*44,z=(Math.random()-.5)*44;if(Math.hypot(x,z)<5){i--;continue}let g=new THREE.Group();g.position.set(x,0,z);let t=new THREE.Mesh(new THREE.CylinderGeometry(.2,.28,2,10),mat(0x563b2b));t.position.y=1;g.add(t);let c=new THREE.Mesh(new THREE.SphereGeometry(1.3,16,12),mat(0x1d6a43));c.position.y=2.5;g.add(c);g.children.forEach(o=>o.castShadow=true);scene.add(g);trees.push(g)}
function actor(color,enemy=false){let g=new THREE.Group();let b=new THREE.Mesh(new THREE.BoxGeometry(.8,1.25,.5),mat(color));b.position.y=.9;g.add(b);let h=new THREE.Mesh(new THREE.SphereGeometry(.4,18,12),mat(enemy?0x7b315e:0xe8c3a4));h.position.y=1.75;g.add(h);let hair=new THREE.Mesh(new THREE.SphereGeometry(.44,18,12),mat(enemy?0x32152e:0x201d32));hair.scale.y=.5;hair.position.y=1.95;g.add(hair);if(enemy){let horn=new THREE.Mesh(new THREE.ConeGeometry(.14,.55,8),mat(0xe6b5ff));horn.position.set(.25,2.25,0);g.add(horn);let horn2=horn.clone();horn2.position.x=-.25;g.add(horn2)}g.children.forEach(o=>o.castShadow=true);scene.add(g);return g}
const player=actor(0x4c8cff);player.position.set(0,0,0);let sword=new THREE.Mesh(new THREE.BoxGeometry(.12,1.7,.18),mat(0xdfe8ff));sword.position.set(.72,1.05,0);sword.rotation.z=-.45;sword.castShadow=true;player.add(sword);
const enemies=[];for(let i=0;i<7;i++){let e=actor(i%2?0xa34cff:0xd34f69,true);let a=i/7*Math.PI*2,r=7+(i%3)*2;e.position.set(Math.cos(a)*r,0,Math.sin(a)*r);enemies.push({g:e,hp:100})}
const ring=new THREE.Mesh(new THREE.RingGeometry(.8,.95,32),new THREE.MeshBasicMaterial({color:0x63d8ff,side:THREE.DoubleSide,transparent:true,opacity:.7}));ring.rotation.x=-Math.PI/2;ring.position.y=.03;scene.add(ring);
const keys={};addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=1;if(e.code==='Space'){e.preventDefault();for(const e2 of enemies)if(e2.g.position.distanceTo(player.position)<3)e2.hp-=40}});addEventListener('keyup',e=>keys[e.key.toLowerCase()]=0);
let theta=.7,phi=.95,radius=15,drag=false,px=0,py=0;renderer.domElement.addEventListener('pointerdown',e=>{drag=true;px=e.clientX;py=e.clientY});addEventListener('pointerup',()=>drag=false);addEventListener('pointermove',e=>{if(!drag)return;theta-=(e.clientX-px)*.008;phi=Math.max(.35,Math.min(1.4,phi+(e.clientY-py)*.006));px=e.clientX;py=e.clientY});renderer.domElement.addEventListener('wheel',e=>radius=Math.max(7,Math.min(24,radius+e.deltaY*.01)),{passive:true});
function resize(){renderer.setSize(innerWidth,innerHeight,false);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix()}addEventListener('resize',resize);resize();let last=performance.now();function loop(now){let dt=Math.min((now-last)/1000,.05);last=now;let dx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),dz=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0);let l=Math.hypot(dx,dz)||1;player.position.x+=dx/l*5.2*dt;player.position.z+=dz/l*5.2*dt;if(dx||dz)player.rotation.y=Math.atan2(dx,dz);ring.position.x=player.position.x;ring.position.z=player.position.z;for(const e of enemies){if(e.hp<=0){e.g.visible=false;continue}let vx=player.position.x-e.g.position.x,vz=player.position.z-e.g.position.z,d=Math.hypot(vx,vz);if(d>2.1){e.g.position.x+=vx/d*1.25*dt;e.g.position.z+=vz/d*1.25*dt;e.g.rotation.y=Math.atan2(vx,vz)}e.g.position.y=.08+Math.sin(now*.003+e.g.position.x)*.08}camera.position.set(player.position.x+Math.sin(theta)*Math.sin(phi)*radius,player.position.y+Math.cos(phi)*radius,player.position.z+Math.cos(theta)*Math.sin(phi)*radius);camera.lookAt(player.position.x,1,player.position.z);sword.rotation.z=Math.sin(now*.008)*.08-.45;renderer.render(scene,camera);requestAnimationFrame(loop)}requestAnimationFrame(loop);
${closeScript}</body></html>`
}
function generateGame(){gameProgress.value=20;setTimeout(()=>{
  const prompt=gamePrompt.value.toLowerCase();
  const genre=/sci.?fi|space|cyber/i.test(prompt)?'sci-fi':/horror|dark/i.test(prompt)?'dark fantasy':'anime fantasy';
  game.value={title:genre==='sci-fi'?'NOVA 3D: Neon Frontier':'NOVA 3D: Spirit Realms',summary:`A real-time 3D scene generated from: ${gamePrompt.value}`,deviceProfile:{quality:quality.value,engine:'Three.js WebGL',dimensions:'true 3D',camera:'third-person orbit',lighting:'dynamic directional + hemisphere',terrain:'3D procedural placement',characters:'3D mesh characters',enemies:'3D animated mesh enemies',lod:quality.value!=='Maximum',shadows:quality.value!=='Recommended'},scenes:[{name:'Open World',visual:'3D terrain, trees, crystals, fog and sky lighting',gameplay:'third-person exploration'},{name:'Spirit Village',visual:'3D structures and landmarks',gameplay:'quests and NPC expansion point'},{name:'Combat Arena',visual:'3D enemies, weapons, HP and hit reactions',gameplay:'real-time melee combat'}],html:gameHtml()};gameProgress.value=100
},450)}
function downloadGame(){if(!game.value)return;const blob=new Blob([gameHtml()],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='nova-3d-game-project.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function generateAnime(){const count=Math.min(12,Math.max(1,Math.ceil(minutes.value*60/10)));const scenes=['Forest arrival','Spirit village','Ancient ruins','Creature encounter','Climactic battle','Quiet ending'];anime.value={title:'NOVA Local Anime',summary:`${minutes.value}-minute story split into ${count} real 10-second WebM clips.`,clips:Array.from({length:count},(_,i)=>({id:i+1,duration:10,scene:scenes[i%scenes.length],url:null}))};nextTick(renderAllClips)}
function drawFrame(ctx,w,h,i,scene,frame){ctx.fillStyle='#07101e';ctx.fillRect(0,0,w,h);const grad=ctx.createLinearGradient(0,0,0,h);grad.addColorStop(0,'#142b55');grad.addColorStop(1,'#07101e');ctx.fillStyle=grad;ctx.fillRect(0,0,w,h);ctx.fillStyle='#173e35';for(let x=0;x<w;x+=70){ctx.beginPath();ctx.moveTo(x,h);ctx.lineTo(x+35,180+(x%120));ctx.lineTo(x+70,h);ctx.fill()}ctx.fillStyle='#dce7ff';ctx.beginPath();ctx.arc(w-100,90,40,0,Math.PI*2);ctx.fill();const cx=120+((frame*2+i*55)%(w-240));const cy=320+Math.sin(frame/8+i)*18;ctx.fillStyle='#78a8ff';ctx.beginPath();ctx.arc(cx,cy,24,0,Math.PI*2);ctx.fill();ctx.fillStyle='#d65dff';ctx.beginPath();ctx.arc(cx+45,cy-5,18,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff';ctx.font='22px system-ui';ctx.fillText(`NOVA • ${scene}`,28,38);ctx.font='14px system-ui';ctx.fillText(`Clip ${i+1}`,28,h-24)}
async function renderClip(clip,index){const c=preview.value;if(!c)return;const ctx=c.getContext('2d'),stream=c.captureStream(30);if(!window.MediaRecorder){return}const mime=MediaRecorder.isTypeSupported('video/webm;codecs=vp9')?'video/webm;codecs=vp9':'video/webm';const rec=new MediaRecorder(stream,{mimeType:mime});const chunks=[];rec.ondataavailable=e=>e.data.size&&chunks.push(e.data);const done=new Promise(resolve=>rec.onstop=()=>resolve());rec.start();for(let f=0;f<300;f++){drawFrame(ctx,c.width,c.height,index,clip.scene,f);await new Promise(r=>setTimeout(r,33))}rec.stop();await done;clip.url=URL.createObjectURL(new Blob(chunks,{type:'video/webm'}))}
async function renderAllClips(){if(!anime.value||rendering.value)return;if(!window.MediaRecorder){answer.value='This Android WebView does not expose MediaRecorder, so clip rendering needs a native encoder bridge.';speak(answer.value);return}rendering.value=true;for(let i=0;i<anime.value.clips.length;i++){renderIndex.value=i+1;await renderClip(anime.value.clips[i],i)}rendering.value=false;renderIndex.value=anime.value.clips.length}
function normalize(){normalized.value=JSON.stringify(normalizeText(toolText.value),null,2)}
function profileDevice(){device.value={userAgent:navigator.userAgent,language:navigator.language,cores:navigator.hardwareConcurrency||'unknown',memoryGB:navigator.deviceMemory||'unknown',screen:`${screen.width}x${screen.height}`,online:navigator.onLine}}
function exportProject(){const data={version:'0.4.0',memories:memories.value,game:game.value,anime:anime.value,generatedAt:new Date().toISOString()};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='nova-project.json';a.click();URL.revokeObjectURL(url)}
window.addEventListener('online',()=>online.value=true);window.addEventListener('offline',()=>online.value=false)
</script>

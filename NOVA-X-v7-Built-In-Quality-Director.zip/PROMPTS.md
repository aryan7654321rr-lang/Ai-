# NOVA generation specifications

## Game — one-tap generation target
Create an original high-detail third-person game from the supplied idea. Generate separate game-specific assets for the player, NPCs, creatures and environment. Prioritize the player character, nearby interactive environment, animation, materials, lighting and shadows. Use a real interactive renderer with camera, movement, collision, streaming, visibility culling, LOD, instancing, texture/mesh streaming, dynamic resolution, thermal adaptation and device-specific quality profiles. Use image/depth/impostor representations only when the player is unlikely to distinguish them and they materially reduce GPU/RAM/storage cost. Keep the playable ground, important characters and interactive objects genuinely 3D. Use predictive camera-aware streaming so detail is restored before an area enters view.

## Video — cinematic anime target
Create an original high-end cinematic anime video. Do not copy copyrighted characters or scenes. Build independent video characters and environments rather than reusing the game assets. Use character identity locks, environment locks, keyframes, motion generation, temporal consistency, multi-stage resolution, selective enhancement, cinematic camera control, lighting and effects. Generate short coherent shots, validate each shot, regenerate only failed/affected shots, and assemble the final timeline. The visual target is polished professional anime-film/TV quality: detailed characters, rich backgrounds, atmospheric depth, controlled lighting, clean silhouettes, consistent colors, expressive animation and cinematic camera work.

## Incremental editing rule
Never rebuild an entire game/video when an edit can be localized. Maintain a dependency graph and invalidate only affected assets, scenes, shots or systems. Preserve cached outputs and checkpoints. Reassemble the final project from unchanged + regenerated components.

## External resources
NOVA may search public sources for resources only when their license permits the intended use. Public availability alone is not sufficient. Track source and license metadata for every incorporated external resource.

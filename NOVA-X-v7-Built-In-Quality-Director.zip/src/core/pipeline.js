


export const NOVA_MASTER_DIRECTOR = {
  version: '7.0-quality-director',
  firstLaunchOnly: true,
  game: `Create an original high-fidelity 3D game from the user's idea. Target the visual characteristics of a modern AAA open-world production without copying any protected game, character, world, or asset. Prioritize the player character first: detailed anatomy, face, eyes, hair, hands, feet, clothing, materials, textures, deformation, expressive animation and responsive movement. Then prioritize the nearby interactive environment: terrain, rocks, vegetation, buildings, props, NPCs and creatures. Use physically based materials, realistic lighting, shadows, atmosphere, weather and day/night. Build high-detail source assets before creating device-specific optimized representations. Use camera-aware LOD, culling, streaming, instancing, dynamic resolution, animation LOD, thermal adaptation and memory-aware asset management to preserve perceived quality on the target phone. Never use primitive placeholder geometry as the intended final asset when a detailed asset is required. Run validation and targeted refinement passes before declaring the generation complete.`,
  video: `Create an original high-production-value cinematic anime/fantasy video from the user's idea. Target the visual characteristics of premium anime-film/TV production without copying protected characters, scenes, footage or a specific studio's artwork. Use a separate cinematic asset pipeline from the game pipeline. Prioritize detailed original characters, expressive faces, hair, clothing, environments, atmospheric depth, cinematic lighting, effects, camera language, smooth animation and temporal identity consistency. Generate the episode as many short shots, maintain a continuity state across shots, inspect each shot, repair weak shots, and assemble the final timeline. Spend additional processing time when it improves final quality. Never substitute low-detail placeholder characters or environments for the intended final cinematic result.`,
  image: `Create an original high-quality image from the user's idea. Prioritize composition, subject identity, anatomy, hands, facial detail, materials, lighting, environment, atmosphere and artifact cleanup. Refine only the regions that need improvement and preserve approved regions. Do not copy protected characters or artwork.`,
  rules: [
    'User prompt is the creative intent; the director supplies production requirements automatically.',
    'Do not require the user to paste this director prompt again.',
    'Use time and staged refinement instead of pretending that low compute equals high compute.',
    'Prefer legal, reusable or original assets and keep a source/license manifest.',
    'Game and video may share story/world concepts but use separate final asset policies.',
    'If a requested quality target cannot be reached on-device, report the actual limitation instead of faking success.'
  ]
}

export const FIRST_LAUNCH_PROMPTS = {
  game: 'Create an original cinematic open-world fantasy adventure with a highly detailed human protagonist, vast mountain forests, villages, creatures, weather, day/night, responsive third-person exploration, quests, NPCs and a polished AAA-style presentation.',
  video: 'Create an original high-production cinematic anime fantasy episode with a detailed original protagonist, dramatic environments, atmospheric depth, expressive animation, cinematic camera work, lighting and effects, assembled from many coherent shots.'
}

export function composeGenerationPrompt(userPrompt, mode = 'game') {
  const clean = String(userPrompt || '').trim()
  const director = mode === 'video' ? NOVA_MASTER_DIRECTOR.video : NOVA_MASTER_DIRECTOR.game
  return `${director}\n\nUSER CREATIVE BRIEF:\n${clean || FIRST_LAUNCH_PROMPTS[mode]}`
}

export const VOICE_SYSTEM = {
  goal: 'Pleasant, varied, prompt-editable voices and sound identities for game and video',
  categories: {
    character: ['warm-natural','cinematic-soft','bright-anime','deep-dramatic'],
    water: ['gentle-stream','close-splash','soft-pour','cinematic-flow'],
    ambience: ['forest-air','dreamy-atmosphere','wide-cinematic','quiet-natural'],
    effects: ['light-crisp','soft-impact','cinematic-energy','natural-detailed']
  },
  rules: ['Never force one voice on every source','Preserve identity/continuity for recurring characters','Allow prompt-based voice creation and variation','Validate loudness, clipping and harshness before export']
}

export const RENDERING_POLICY = {
  game: { cameraAware: true, predictiveStreaming: true, invisibleResourceRelease: true, perceptualPriority: true, imageBasedRepresentations: 'only-when-visually-safe' },
  video: { separateAssets: true, keyframeFirst: true, temporalConsistency: true, shotCaching: true, incrementalRegeneration: true, imageBasedBackgrounds: 'only-when-camera-and-motion-allow' }
}
export const GAME_PIPELINE = {
  name: 'NOVA Real-Time Game',
  goal: 'Maximum practical visual fidelity on the target device',
  assetPolicy: 'hero-first / representation-adaptive',
  stages: ['concept','high-detail-source','asset-validation','hero-LOD','near-LOD','impostor-LOD','streaming','runtime-profiling','incremental-build'],
  priorities: ['player','interactive-near-field','gameplay-critical','camera-predicted','background']
}

export const VIDEO_PIPELINE = {
  name: 'NOVA Cinematic Video',
  goal: 'Maximum practical cinematic quality per shot with temporal consistency',
  separateAssetsFromGame: true,
  stages: ['script','shot-plan','character-lock','environment-lock','keyframes','motion','temporal-consistency','enhancement','render-shot','continuity-check','retry','edit','encode'],
  shotLengthSeconds: { min: 4, max: 15 }
}

export const VIDEO_REFERENCE_POLICY = {
  allowed: ['public-domain','CC0','Creative-Commons-with-adaptation-rights','user-owned','properly licensed commercial sources'],
  forbidden: ['unlicensed copyrighted footage','ripped movies/anime/game footage','material whose license does not permit the intended adaptation'],
  useFor: ['camera language','staging','timing','motion reference','environment inspiration'],
  notFor: ['copying protected characters','copying protected scenes shot-for-shot','redistributing source footage']
}

export function planShots(script, durationMinutes = 10) {
  const seconds = Math.max(60, Number(durationMinutes) * 60)
  const count = Math.ceil(seconds / 9)
  const types = ['establishing','character','dialogue','movement','mystery','action','reaction','transition']
  return Array.from({ length: count }, (_, i) => ({
    id: `SHOT-${String(i + 1).padStart(3, '0')}`,
    start: i * 9,
    duration: Math.min(9, seconds - i * 9),
    type: types[i % types.length],
    status: 'queued',
    quality: 'maximum-practical',
    continuityKey: `continuity-${i}`,
    dependencies: ['story', 'character-lock', 'environment-lock', 'camera', 'lighting']
  }))
}

export function selectGameQuality(device = {}, frameTimeMs = 20) {
  const thermal = device?.thermal ?? 'normal'
  if (thermal === 'critical' || frameTimeMs > 33) return 'near-hero'
  if (frameTimeMs > 24) return 'hero-balanced'
  return 'hero-max'
}

export function affectedNodes(change) {
  const c = String(change || '').toLowerCase()
  if (/hair|face|outfit|clothing|character|body|appearance/.test(c)) return ['character','animation','affected-shots']
  if (/forest|tree|rock|mountain|building|terrain|environment|background/.test(c)) return ['environment','lighting','affected-shots']
  if (/sun|sunset|sunrise|light|lighting|fog|weather|rain|storm|cloud/.test(c)) return ['lighting','weather','affected-shots']
  if (/camera|close|wide|angle|zoom/.test(c)) return ['camera','affected-shots']
  if (/sound|music|voice|dialogue/.test(c)) return ['audio','affected-shots']
  return ['requested-component','affected-shots']
}

import * as THREE from 'three'

const clamp = (v, a, b) => Math.max(a, Math.min(b, v))

export class NovaRenderer {
  constructor(host) {
    this.host = host
    this.mode = 'game'
    this.quality = 'hero-max'
    this.listening = true
    this.drag = false
    this.yaw = 0.25
    this.pitch = 0.12
    this.distance = 8
    this.frame = 0
    this.lastX = 0
    this.lastY = 0
    this.clock = new THREE.Clock()
    this.scene = new THREE.Scene()
    this.scene.background = new THREE.Color(0x07101a)
    this.scene.fog = new THREE.FogExp2(0x0b1622, 0.014)
    this.camera = new THREE.PerspectiveCamera(52, 1, 0.05, 600)
    this.camera.position.set(0, 2, 8)
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' })
    this.renderer.outputColorSpace = THREE.SRGBColorSpace
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping
    this.renderer.toneMappingExposure = 1.08
    this.renderer.shadowMap.enabled = true
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5))
    this.host.appendChild(this.renderer.domElement)

    this.root = new THREE.Group()
    this.scene.add(this.root)
    this.world = new THREE.Group()
    this.root.add(this.world)
    this.hero = new THREE.Group()
    this.world.add(this.hero)
    this.sun = null
    this.sunTarget = null
    this.clouds = new THREE.Group()
    this.world.add(this.clouds)
    this.gameCameraTarget = new THREE.Vector3(0, 1.2, 0)
    this.videoCamera = new THREE.Group()
    this.world.add(this.videoCamera)
    this.status = 'renderer-scene-ready'
    this.lastRenderStats = { calls: 0, triangles: 0, frame: 0 }

    this.bind()
    this.buildLighting()
    this.setMode('game')
    this.resize()
    this.animate()
  }

  bind() {
    this._resize = () => this.resize()
    this._down = e => this.pointerDown(e)
    this._move = e => this.pointerMove(e)
    this._up = () => { this.drag = false }
    this._wheel = e => this.wheel(e)
    window.addEventListener('resize', this._resize)
    this.host.addEventListener('pointerdown', this._down)
    window.addEventListener('pointermove', this._move)
    window.addEventListener('pointerup', this._up)
    this.host.addEventListener('wheel', this._wheel, { passive: false })
  }

  buildLighting() {
    this.scene.add(new THREE.HemisphereLight(0xbfd8ff, 0x142017, 1.25))
    this.sun = new THREE.DirectionalLight(0xfff0d0, 3.3)
    this.sun.position.set(25, 38, 18)
    this.sun.castShadow = true
    this.sun.shadow.mapSize.set(2048, 2048)
    this.sun.shadow.camera.left = -45; this.sun.shadow.camera.right = 45
    this.sun.shadow.camera.top = 45; this.sun.shadow.camera.bottom = -45
    this.scene.add(this.sun)
    this.sunTarget = new THREE.Object3D()
    this.sunTarget.position.set(0, 0, 0)
    this.scene.add(this.sunTarget)
    this.sun.target = this.sunTarget
    const fill = new THREE.PointLight(0x4b83ff, 12, 60, 2)
    fill.position.set(-15, 9, 18)
    this.scene.add(fill)
    const rim = new THREE.PointLight(0xff9f68, 8, 55, 2)
    rim.position.set(20, 12, -18)
    this.scene.add(rim)
  }

  mat(color, rough = 0.65, metal = 0.0) {
    return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal })
  }

  clearWorld() {
    while (this.world.children.length) this.world.remove(this.world.children[0])
    this.hero = new THREE.Group(); this.world.add(this.hero)
    this.clouds = new THREE.Group(); this.world.add(this.clouds)
    this.videoCamera = new THREE.Group(); this.world.add(this.videoCamera)
  }

  buildTerrain() {
    const geo = new THREE.PlaneGeometry(180, 180, 96, 96)
    const pos = geo.attributes.position
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), y = pos.getY(i)
      const h = Math.sin(x * 0.075) * 1.5 + Math.cos(y * 0.06) * 1.8 + Math.sin((x + y) * 0.025) * 3.0
      pos.setZ(i, h)
    }
    geo.computeVertexNormals()
    const terrain = new THREE.Mesh(geo, this.mat(0x304832, 0.95, 0.0))
    terrain.rotation.x = -Math.PI / 2
    terrain.position.y = -1.2
    terrain.receiveShadow = true
    this.world.add(terrain)

    const water = new THREE.Mesh(new THREE.CircleGeometry(18, 96), new THREE.MeshPhysicalMaterial({
      color: 0x183c4c, roughness: 0.12, metalness: 0.08, transmission: 0.08, clearcoat: 0.8
    }))
    water.rotation.x = -Math.PI / 2
    water.position.set(-17, 0.15, -8)
    water.scale.set(1.3, 0.7, 1)
    water.receiveShadow = true
    this.world.add(water)
  }

  buildMountains() {
    const mat = this.mat(0x344a55, 0.96, 0)
    for (let i = 0; i < 16; i++) {
      const a = i / 16 * Math.PI * 2
      const r = 58 + (i % 4) * 7
      const h = 18 + (i % 5) * 7
      const mountain = new THREE.Mesh(new THREE.ConeGeometry(11 + (i % 3) * 5, h, 28, 8), mat)
      mountain.position.set(Math.cos(a) * r, h / 2 - 1, Math.sin(a) * r)
      mountain.scale.z = 1.25
      mountain.rotation.y = i * 0.7
      mountain.castShadow = true
      this.world.add(mountain)
    }
  }

  buildTrees() {
    const trunkMat = this.mat(0x4a3022, 0.9)
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x2d633e, roughness: 0.9 })
    const count = this.quality === 'near-hero' ? 100 : 180
    for (let i = 0; i < count; i++) {
      const a = i * 2.399
      const r = 8 + (i % 31) * 1.55
      const x = Math.cos(a) * r
      const z = Math.sin(a) * r
      if (Math.abs(x) < 5 && Math.abs(z) < 5) continue
      const g = new THREE.Group()
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.22, 2.4 + (i % 5) * .45, 12), trunkMat)
      trunk.position.y = 0.2
      trunk.castShadow = true
      g.add(trunk)
      const crown = new THREE.Mesh(new THREE.IcosahedronGeometry(1.05 + (i % 4) * .18, 2), leafMat)
      crown.position.y = 1.8 + (i % 4) * .2
      crown.scale.set(1, 1.15, 1)
      crown.castShadow = true
      g.add(crown)
      g.position.set(x, 0, z)
      g.rotation.y = a
      const s = 0.65 + (i % 7) * .08
      g.scale.setScalar(s)
      this.world.add(g)
    }
  }

  buildClouds() {
    const cloudMat = new THREE.MeshStandardMaterial({ color: 0xe7eef5, roughness: 1, transparent: true, opacity: 0.78 })
    for (let i = 0; i < 22; i++) {
      const g = new THREE.Group()
      for (let j = 0; j < 5 + (i % 4); j++) {
        const puff = new THREE.Mesh(new THREE.SphereGeometry(2.2 + (j % 3) * .7, 16, 12), cloudMat)
        puff.scale.y = 0.48
        puff.position.set(j * 1.6, (j % 2) * .35, Math.sin(j) * .8)
        g.add(puff)
      }
      g.position.set(-55 + (i * 11) % 110, 25 + (i % 5) * 2, -55 + (i * 19) % 110)
      g.scale.setScalar(1 + (i % 3) * .35)
      this.clouds.add(g)
    }
  }

  buildHumanoid(target, variant = 'hero') {
    const skin = new THREE.MeshStandardMaterial({ color: 0xc58e72, roughness: .55 })
    const cloth = new THREE.MeshStandardMaterial({ color: variant === 'hero' ? 0x202b3d : 0x5b2530, roughness: .75 })
    const dark = this.mat(0x11151c, .5, .2)
    const g = target
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(.48, 1.05, 12, 32), cloth)
    torso.position.y = 1.35; torso.scale.set(1.05, 1.0, .65); torso.castShadow = true; g.add(torso)
    const head = new THREE.Mesh(new THREE.SphereGeometry(.42, 48, 32), skin)
    head.position.y = 2.35; head.scale.set(.9, 1.08, .86); head.castShadow = true; g.add(head)
    const hair = new THREE.Mesh(new THREE.SphereGeometry(.45, 48, 24), dark)
    hair.position.set(0, 2.52, -.02); hair.scale.set(1.02, .85, 1.0); hair.castShadow = true; g.add(hair)
    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x7cc9ff, emissive: 0x153a68, emissiveIntensity: .5, roughness: .25 })
    for (const x of [-.15, .15]) {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(.055, 20, 12), eyeMat)
      eye.position.set(x, 2.38, .38); g.add(eye)
    }
    const limb = (x, y, z, sx, sy, sz, material = cloth) => {
      const m = new THREE.Mesh(new THREE.CapsuleGeometry(.16, .7, 10, 20), material)
      m.position.set(x, y, z); m.scale.set(sx, sy, sz); m.castShadow = true; g.add(m); return m
    }
    limb(-.6, 1.35, 0, 1, 1.05, 1); limb(.6, 1.35, 0, 1, 1.05, 1)
    limb(-.25, .45, 0, 1.05, 1.35, 1); limb(.25, .45, 0, 1.05, 1.35, 1)
    return g
  }

  buildGameScene() {
    this.clearWorld()
    this.buildTerrain(); this.buildMountains(); this.buildTrees(); this.buildClouds()
    this.buildHumanoid(this.hero, 'hero')
    this.hero.position.set(0, 0, 2)
    this.hero.rotation.y = Math.PI
    const marker = new THREE.Mesh(new THREE.TorusGeometry(1.1, .025, 12, 64), new THREE.MeshBasicMaterial({ color: 0x57a1ff, transparent: true, opacity: .65 }))
    marker.rotation.x = Math.PI / 2; marker.position.y = .02; this.hero.add(marker)
    this.status = 'game-renderer-active'
  }

  buildVideoScene() {
    this.clearWorld()
    this.buildTerrain(); this.buildMountains(); this.buildTrees(); this.buildClouds()
    this.buildHumanoid(this.hero, 'cinematic')
    this.hero.position.set(0, 0, 0)
    const companion = new THREE.Group(); this.buildHumanoid(companion, 'companion'); companion.scale.setScalar(.96); companion.position.set(2.8, 0, -1.4); this.world.add(companion)
    this.videoCamera.position.set(5.5, 3.2, 7.5)
    this.videoCamera.lookAt(0, 1.4, 0)
    this.status = 'video-renderer-active'
  }

  setMode(mode) {
    this.mode = mode
    if (mode === 'game') this.buildGameScene()
    else this.buildVideoScene()
  }

  setListening(v) { this.listening = v }

  setQuality(q) {
    this.quality = q
    const ratio = { low: .75, medium: .9, high: 1.1, max: 1.35, 'hero-max': 1.15, 'hero-balanced': .95, 'near-hero': .8 }[q] || 1
    this.renderer.setPixelRatio(Math.min((window.devicePixelRatio || 1) * ratio, 1.75))
    if (this.mode === 'game') this.buildGameScene()
    else this.buildVideoScene()
    this.resize()
  }

  pointerDown(e) { this.drag = true; this.lastX = e.clientX; this.lastY = e.clientY; this.host.setPointerCapture?.(e.pointerId) }
  pointerMove(e) {
    if (!this.drag) return
    const dx = e.clientX - this.lastX, dy = e.clientY - this.lastY
    this.lastX = e.clientX; this.lastY = e.clientY
    this.yaw += dx * .006
    this.pitch = clamp(this.pitch + dy * .004, -.35, .5)
  }
  wheel(e) { e.preventDefault(); this.distance = clamp(this.distance + e.deltaY * .004, 4.5, 18) }
  resize() {
    const w = Math.max(1, this.host.clientWidth), h = Math.max(1, this.host.clientHeight)
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); this.renderer.setSize(w, h, false)
  }

  animate() {
    this.frame = requestAnimationFrame(() => this.animate())
    const t = this.clock.getElapsedTime()
    const sunAngle = t * .035 + .6
    this.sun.position.set(Math.cos(sunAngle) * 35, 18 + Math.sin(sunAngle) * 22, Math.sin(sunAngle) * 35)
    this.sun.intensity = 2.3 + Math.max(0, Math.sin(sunAngle)) * 1.4
    this.clouds.position.x = (t * .7) % 110 - 55

    if (this.mode === 'game') {
      const x = Math.sin(this.yaw) * this.distance
      const z = Math.cos(this.yaw) * this.distance
      this.camera.position.lerp(new THREE.Vector3(x, 2.2 + this.pitch * 2.0, z + 2), .12)
      this.camera.lookAt(this.hero.position.x, this.hero.position.y + 1.1, this.hero.position.z)
      this.hero.rotation.y += Math.sin(t * .9) * .0008
    } else {
      const orbit = t * .06
      this.camera.position.lerp(new THREE.Vector3(7 + Math.sin(orbit) * 2.2, 3.5 + Math.sin(t * .2) * .3, 8 + Math.cos(orbit) * 2.2), .025)
      this.camera.lookAt(0, 1.25, 0)
      this.hero.rotation.y = Math.sin(t * .25) * .15
    }
    this.renderer.render(this.scene, this.camera)
  }

  verifyScene(mode) {
    const previous = this.mode
    try {
      this.setMode(mode)
      this.resize()
      this.renderer.render(this.scene, this.camera)
      const calls = this.renderer.info.render.calls
      const triangles = this.renderer.info.render.triangles
      const canvasReady = !!this.renderer.domElement && this.renderer.domElement.width > 0 && this.renderer.domElement.height > 0
      const sceneReady = this.world.children.length > 0 && !!this.sun
      const ok = canvasReady && sceneReady && calls > 0
      this.lastRenderStats = { calls, triangles, frame: this.renderer.info.render.frame }
      return { ok, details: `${calls} draw calls · ${triangles} triangles · canvas ${this.renderer.domElement.width}×${this.renderer.domElement.height}` }
    } catch (error) {
      return { ok: false, details: error?.message || 'renderer exception' }
    } finally {
      this.setMode(previous)
    }
  }

  dispose() {
    cancelAnimationFrame(this.frame)
    window.removeEventListener('resize', this._resize)
    this.host.removeEventListener('pointerdown', this._down)
    window.removeEventListener('pointermove', this._move)
    window.removeEventListener('pointerup', this._up)
    this.host.removeEventListener('wheel', this._wheel)
    this.renderer.dispose()
    this.host.innerHTML = ''
  }
}

<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { NovaRenderer } from './core/renderer.js'
import { GAME_PIPELINE, VIDEO_PIPELINE, planShots, selectGameQuality, affectedNodes, NOVA_MASTER_DIRECTOR, FIRST_LAUNCH_PROMPTS, composeGenerationPrompt } from './core/pipeline.js'

const mode = ref('game')
const listening = ref(true)
const settingsOpen = ref(false)
const editorOpen = ref(false)
const prompt = ref('')
const directorVersion = ref(NOVA_MASTER_DIRECTOR.version)
const firstLaunch = ref(false)
const generationBrief = ref('')
const editPrompt = ref('')
const duration = ref(10)
const quality = ref('auto')
const status = ref('NOVA renderer scene ready')
const building = ref(false)
const shotPlan = ref([])
const gamePlan = ref(null)
const editLog = ref([])
const rendererHealth = ref({ game: 'not checked', video: 'not checked' })
const voiceProfiles = ref({
  character: ['Warm Natural', 'Cinematic Soft', 'Bright Anime', 'Deep Dramatic'],
  water: ['Gentle Stream', 'Close Splash', 'Soft Pour', 'Cinematic Flow'],
  ambience: ['Forest Air', 'Dreamy Atmosphere', 'Wide Cinematic', 'Quiet Natural'],
  effects: ['Light Crisp', 'Soft Impact', 'Cinematic Energy', 'Natural Detailed']
})
const voiceChoice = ref({ character: 'Warm Natural', water: 'Gentle Stream', ambience: 'Forest Air', effects: 'Light Crisp' })
const voicePrompt = ref('')
const viewport = ref(null)
const timeText = ref('')
const dateText = ref('')
let renderer
let timer

const activePipeline = computed(() => mode.value === 'game' ? GAME_PIPELINE : VIDEO_PIPELINE)
const queued = computed(() => shotPlan.value.filter(s => s.status === 'queued').length)
const rendered = computed(() => shotPlan.value.filter(s => s.status === 'rendered').length)

function createGamePlan() {
  generationBrief.value = composeGenerationPrompt(prompt.value, 'game')
  building.value = true; status.value = 'NOVA is building the interactive high-detail scene…'
  setTimeout(() => {
    const profile = selectGameQuality({ thermal: 'normal' }, 20)
    gamePlan.value = { profile, target: 'maximum-practical-realism', renderer: 'interactive real-time scene', representation: 'camera-aware adaptive' }
    mode.value = 'game'; renderer?.setMode('game'); renderer?.setQuality(profile)
    building.value = false; status.value = 'Game renderer verified: interactive scene is visible and running.'
  }, 500)
}
function createVideoPlan() {
  generationBrief.value = composeGenerationPrompt(prompt.value, 'video')
  building.value = true; status.value = 'NOVA is planning independent cinematic assets and shots…'
  setTimeout(() => {
    shotPlan.value = planShots(prompt.value, Number(duration.value)); mode.value = 'video'; renderer?.setMode('video')
    building.value = false; status.value = `${shotPlan.value.length} independent cinematic shots queued. Video renderer is active.`
  }, 500)
}
function markNextRendered() {
  const s = shotPlan.value.find(x => x.status === 'queued')
  if (s) { s.status = 'rendered'; status.value = `${s.id} rendered and continuity checked; other shots remain cached.` }
}
function retryBadShot() {
  const s = shotPlan.value.find(x => x.status === 'failed')
  status.value = s ? (s.status = 'queued', `${s.id} returned to the incremental render queue.`) : 'No failed shots in the queue.'
}
function switchMode(m) { mode.value = m; renderer?.setMode(m); status.value = m === 'game' ? 'Interactive game renderer active' : 'Interactive cinematic renderer active' }
function setQuality(q) { quality.value = q; localStorage.setItem('nova-quality', q); renderer?.setQuality(q === 'auto' ? 'hero-max' : q); status.value = `Render profile · ${q.toUpperCase()}` }
function toggleListening() { listening.value = !listening.value; renderer?.setListening(listening.value); status.value = listening.value ? 'Listening for “Hey Nova”…' : 'Voice standby paused.' }
function updateClock() { const d = new Date(); timeText.value = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); dateText.value = d.toLocaleDateString([], { weekday: 'short', day: '2-digit', month: 'short' }) }
function verifyRenderers() {
  if (!renderer) return
  const game = renderer.verifyScene('game')
  const video = renderer.verifyScene('video')
  rendererHealth.value = { game: game.ok ? `PASS · ${game.details}` : `FAIL · ${game.details}`, video: video.ok ? `PASS · ${video.details}` : `FAIL · ${video.details}` }
  renderer.setMode(mode.value)
  status.value = game.ok && video.ok ? 'Renderer verification passed for GAME and VIDEO scenes.' : 'Renderer verification found an issue; inspect diagnostics.'
}
function applyVoicePrompt() {
  const p = voicePrompt.value.trim()
  if (!p) return
  const c = p.toLowerCase()
  const category = /water|pour|splash|river|rain/.test(c) ? 'water' : /ambience|wind|forest|environment/.test(c) ? 'ambience' : /effect|impact|magic|energy/.test(c) ? 'effects' : 'character'
  const name = `NOVA Custom · ${p.slice(0, 28)}`
  if (!voiceProfiles.value[category].includes(name)) voiceProfiles.value[category].unshift(name)
  voiceChoice.value[category] = name
  voicePrompt.value = ''
  status.value = `Voice profile created for ${category}: ${name}`
}
function applyEdit() {
  if (!editPrompt.value.trim()) return
  const nodes = affectedNodes(editPrompt.value)
  const item = { id: `EDIT-${String(editLog.value.length + 1).padStart(3,'0')}`, prompt: editPrompt.value.trim(), nodes, status: 'applied incrementally' }
  editLog.value.unshift(item)
  status.value = `Incremental edit applied: ${nodes.join(' → ')}. Unchanged content remains cached.`
  editPrompt.value = ''
}

onMounted(() => {
  const initialized = localStorage.getItem('nova-first-launch-v7')
  if (!initialized) {
    prompt.value = FIRST_LAUNCH_PROMPTS.game
    firstLaunch.value = true
    localStorage.setItem('nova-first-launch-v7', '1')
  } else {
    prompt.value = localStorage.getItem('nova-last-prompt') || FIRST_LAUNCH_PROMPTS.game
  }
  updateClock(); timer = setInterval(updateClock, 30000)
  document.documentElement.classList.add('nova-landscape')
  quality.value = localStorage.getItem('nova-quality') || 'auto'
  renderer = new NovaRenderer(viewport.value)
  renderer.setMode(mode.value)
  renderer.setQuality(quality.value === 'auto' ? 'hero-max' : quality.value)
  renderer.setListening(listening.value)
  setTimeout(verifyRenderers, 250)
})
onBeforeUnmount(() => { localStorage.setItem('nova-last-prompt', prompt.value); clearInterval(timer); document.documentElement.classList.remove('nova-landscape'); renderer?.dispose() })
</script>

<template>
<main class="home">
  <div class="ambient ambient-a"></div><div class="ambient ambient-b"></div>
  <header class="hud-top">
    <div class="clock"><strong>{{ timeText }}</strong><span>{{ dateText }}</span></div>
    <div class="divider"></div>
    <div class="weather"><span class="weather-icon">◒</span><div><strong>28°C</strong><small>Dynamic environment</small></div></div>
  </header>

  <section class="core-stage">
    <div ref="viewport" class="core-viewport"></div>
    <div class="scene-label"><span class="scene-dot"></span>{{ mode === 'game' ? 'REAL-TIME GAME SCENE' : 'CINEMATIC VIDEO SCENE' }}</div>
    <div class="core-vignette"></div>
    <div class="core-caption"><span class="voice-bars"><i></i><i></i><i></i><i></i><i></i></span><b>{{ listening ? 'Listening…' : 'Tap to speak' }}</b></div>
    <div class="mode-pills"><button :class="{active:mode==='game'}" @click="switchMode('game')">GAME</button><button :class="{active:mode==='video'}" @click="switchMode('video')">VIDEO</button></div>
  </section>

  <button class="menu-trigger" @click="settingsOpen=!settingsOpen" aria-label="Open menu"><span></span><span></span><span></span></button>
  <aside v-if="settingsOpen" class="ref-menu">
    <button @click="toggleListening">◌ Voice</button>
    <button @click="editorOpen=!editorOpen">✎ Edit project</button>
    <button @click="switchMode('game')">◈ Game renderer</button>
    <button @click="switchMode('video')">◇ Video renderer</button>
  </aside>

  <button class="corner-btn left" @click="switchMode(mode==='game'?'video':'game')">✦</button>
  <button class="corner-btn right" @click="toggleListening">☼</button>

  <section class="command-dock">
    <div class="dock-tabs"><button :class="{active:mode==='game'}" @click="switchMode('game')">CREATE GAME</button><button :class="{active:mode==='video'}" @click="switchMode('video')">CREATE VIDEO</button></div>
    <textarea v-model="prompt" :placeholder="mode==='game'?'Describe the game you want…':'Describe the cinematic episode…'"></textarea>
    <div class="director-strip"><span>◈ NOVA MASTER DIRECTOR {{ directorVersion }}</span><span>Built-in · no repeated giant prompt</span><span>Game/Video policies separated</span></div>
    <div class="dock-bottom">
      <div class="dock-status"><span class="dot"></span><span>{{ status }}</span><em v-if="firstLaunch">FIRST-LAUNCH DIRECTOR LOADED</em></div>
      <div class="dock-controls">
        <label v-if="mode==='video'">MIN <input v-model.number="duration" type="number" min="1" max="60"></label>
        <select v-model="quality" @change="setQuality(quality)"><option value="auto">AUTO</option><option value="high">HIGH</option><option value="max">MAX</option></select>
        <button class="create" :disabled="building" @click="mode==='game'?createGamePlan():createVideoPlan()">{{ building?'BUILDING…':'GENERATE' }} <b>↗</b></button>
      </div>
    </div>
  </section>

  <section v-if="mode==='video' && shotPlan.length" class="mini-queue"><span>{{ shotPlan.length }} shots</span><span>{{ queued }} queued</span><span>{{ rendered }} rendered</span><button @click="markNextRendered">Render next</button><button @click="retryBadShot">Retry failed</button></section>
  <section v-if="generationBrief" class="director-preview"><b>ACTIVE GENERATION BRIEF</b><small>{{ mode === 'game' ? 'GAME DIRECTOR' : 'VIDEO DIRECTOR' }} · automatically combined with your creative brief</small></section>
  <section v-if="mode==='game' && gamePlan" class="mini-queue"><span>INTERACTIVE</span><span>CAMERA-AWARE</span><span>NEAR-FIELD MAX</span><span>{{ gamePlan.profile }}</span></section>

  <section class="voice-panel">
    <div class="voice-head"><b>VOICE LAB</b><span>Prompt-editable · separate profiles</span></div>
    <div class="voice-grid">
      <label v-for="(profiles, category) in voiceProfiles" :key="category">
        <span>{{ category }}</span>
        <select v-model="voiceChoice[category]">
          <option v-for="profile in profiles" :key="profile">{{ profile }}</option>
        </select>
      </label>
    </div>
    <div class="voice-prompt-row">
      <input v-model="voicePrompt" @keyup.enter="applyVoicePrompt" placeholder="e.g. Make the water sound softer and closer" />
      <button @click="applyVoicePrompt">CREATE VOICE</button>
    </div>
  </section>

  <section class="renderer-health">
    <button @click="verifyRenderers">CHECK RENDERERS</button>
    <span>GAME: {{ rendererHealth.game }}</span>
    <span>VIDEO: {{ rendererHealth.video }}</span>
  </section>

  <section v-if="editorOpen" class="editor-panel">
    <div class="editor-head"><b>NON-DESTRUCTIVE PROJECT EDITOR</b><button @click="editorOpen=false">×</button></div>
    <p>Change a character, environment, lighting, camera or other component without rebuilding everything. NOVA invalidates only affected dependencies.</p>
    <div class="edit-row"><input v-model="editPrompt" @keyup.enter="applyEdit" placeholder="e.g. Make the hero's hair longer and keep everything else the same"><button @click="applyEdit">APPLY</button></div>
    <div v-if="editLog.length" class="edit-log"><div v-for="e in editLog" :key="e.id"><b>{{ e.id }}</b><span>{{ e.prompt }}</span><small>{{ e.nodes.join(' → ') }}</small></div></div>
  </section>
</main>
</template>

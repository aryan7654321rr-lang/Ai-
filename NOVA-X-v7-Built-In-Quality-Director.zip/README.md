# NOVA-X 7 — Built-in Quality Director / High-Fidelity Generation Foundation

This build is a **working renderer and generation-pipeline foundation**, not a claim of a locally running state-of-the-art image/video model or console-AAA asset library.

## What is implemented
- Built-in NOVA Master Director: the user supplies only the creative brief; production-quality requirements are automatically composed on generation.
- First-launch game prompt is prefilled automatically; the user does not need to paste the large director prompt.
- Separate built-in GAME and VIDEO director policies with independent asset-quality priorities.
- A visible, interactive Three.js **game renderer scene**.
- A separate visible **cinematic video renderer scene**.
- Real terrain, mountains, vegetation, dynamic sun, clouds, water, shadows, camera interaction and humanoid benchmark scene.
- Separate game/video rendering policies and scene construction.
- Game quality profiles with device-aware profile selection.
- A shot queue for long-form video planning, incremental render/retry state, and continuity metadata.
- Non-destructive project editing: prompt edits are mapped to affected dependency nodes instead of rebuilding the entire project.
- Prompt-editable Voice Lab with multiple voice profiles per source type (character, water, ambience, effects).
- Renderer diagnostics that explicitly verify both the GAME and VIDEO scenes after initialization.
- Landscape-first workspace with the renderer scene centered; Android MainActivity requests landscape orientation.
- Architecture for camera-aware representation, streaming, LOD/impostor policies and separate high-quality video assets.
- No copyrighted game/anime assets are bundled.

## Important quality boundary
The built-in director is an orchestration specification, not a claim that this small repository contains frontier generative models or a AAA asset library. The renderer remains a benchmark/foundation. The director is designed so real local generation backends can be attached later without changing the user workflow.
The renderer is now a real visible scene rather than a hidden/static renderer preview. However, this repository does **not** contain a state-of-the-art generative model, AAA character asset library, or a magic local 10-minute anime generator. Those require actual generation models/assets and substantial compute. The code is structured so those backends can be connected later without pretending that procedural benchmark geometry is equivalent to production anime or console assets.

## First-launch behavior
On first open of v7, NOVA inserts a strong example creative brief automatically. The large quality director is internal and is combined with the brief only when Generate is pressed. Later launches restore the last creative brief.

## Run
```bash
npm install
npm run test
npm run build
npm run dev
```

Then open the Vite local URL. Use the GAME / VIDEO buttons to switch the live renderer scene. The renderer is centered in the landscape workspace. Drag to orbit and use the wheel to zoom. Use CHECK RENDERERS to run the built-in GAME/VIDEO scene verification.

Voice Lab provides multiple selectable profiles and prompt-created custom voice profiles. It is a routing/editing foundation; actual neural TTS/SFX generation still requires a compatible audio backend and is not bundled into this repository.

## Incremental editing
Open **Edit project** and try prompts such as:
- "Make the hero's hair longer and keep everything else the same."
- "Change the forest to foggy weather."
- "Move the camera closer in this shot."

The foundation records the affected dependency nodes and preserves the rest of the project state rather than pretending to regenerate everything.

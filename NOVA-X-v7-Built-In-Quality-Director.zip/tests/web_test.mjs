import fs from 'node:fs'
import assert from 'node:assert/strict'

for (const file of ['src/App.vue','src/core/renderer.js','src/core/pipeline.js','src/style.css']) {
  assert.ok(fs.existsSync(file), `${file} missing`)
}
const app = fs.readFileSync('src/App.vue','utf8')
const renderer = fs.readFileSync('src/core/renderer.js','utf8')
const pipeline = fs.readFileSync('src/core/pipeline.js','utf8')
assert.match(app, /GENERATE/)
assert.match(app, /NON-DESTRUCTIVE PROJECT EDITOR/)
assert.match(app, /VOICE LAB/)
assert.match(app, /CHECK RENDERERS/)
assert.match(app, /rendererHealth/)
assert.match(renderer, /buildGameScene/)
assert.match(renderer, /buildVideoScene/)
assert.match(renderer, /WebGLRenderer/)
assert.match(renderer, /verifyScene/)
assert.match(renderer, /buildGameScene/)
assert.match(renderer, /buildVideoScene/)
assert.match(pipeline, /affectedNodes/)
assert.match(pipeline, /VOICE_SYSTEM/)
assert.match(pipeline, /RENDERING_POLICY/)
assert.match(pipeline, /NOVA_MASTER_DIRECTOR/)
assert.match(pipeline, /FIRST_LAUNCH_PROMPTS/)
assert.match(pipeline, /composeGenerationPrompt/)
assert.match(app, /FIRST-LAUNCH DIRECTOR LOADED/)
assert.match(app, /NOVA MASTER DIRECTOR/)
console.log('NOVA renderer tests: PASS')

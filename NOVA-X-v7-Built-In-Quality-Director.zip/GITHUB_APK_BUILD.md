# GitHub / Android note

This source is a web renderer foundation and can be wrapped by Capacitor for Android, but this archive does not claim to contain a verified APK. A real Android build should be produced in a GitHub Actions environment with the Android/Capacitor toolchain, then validated with APK signing/badging checks before distribution.

For a low-end Android target, use the AUTO profile and benchmark on the actual device. The renderer intentionally exposes a real scene so GPU/CPU/memory behavior can be measured rather than inferred from a static UI.

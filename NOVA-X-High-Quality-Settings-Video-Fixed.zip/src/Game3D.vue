<template>
  <div class="game3d-shell" :class="{playing: started}">
    <canvas ref="canvas" class="game3d-canvas"></canvas>
    <div v-if="!started" class="game-start-overlay">
      <div class="game-start-card">
        <div class="game-start-kicker">NOVA-X REAL-TIME 3D</div>
        <h2>{{ config.title }}</h2>
        <p>Third-person 3D · {{ quality }} graphics · {{ enemyObjects.length || enemyCount() }} enemies · touch combat</p>
        <button class="game-start-button" @click="startGame">▶ START GAME</button>
        <small>After starting, movement and attack controls stay in the lower-right corner.</small>
      </div>
    </div>
    <div v-if="started" class="game3d-hud">
      <div class="hud-title">{{ config.title }}</div>
      <div class="hud-sub">{{ config.genre }} · {{ quality }} · Wave {{ wave }}</div>
      <div class="hud-bar"><span :style="{width: playerHp + '%'}"></span></div>
      <div class="hud-stats">HP {{ playerHp }} · XP {{ xp }}</div>
      <div class="hud-help">Drag to orbit · pinch/wheel to zoom</div>
    </div>
    <div v-if="started" class="touch-controls-corner">
      <div class="move-pad">
        <button class="up" @pointerdown="touchKey('w',true)" @pointerup="touchKey('w',false)" @pointercancel="touchKey('w',false)">▲</button>
        <button @pointerdown="touchKey('a',true)" @pointerup="touchKey('a',false)" @pointercancel="touchKey('a',false)">◀</button>
        <button @pointerdown="touchKey('s',true)" @pointerup="touchKey('s',false)" @pointercancel="touchKey('s',false)">▼</button>
        <button @pointerdown="touchKey('d',true)" @pointerup="touchKey('d',false)" @pointercancel="touchKey('d',false)">▶</button>
      </div>
      <button class="attack-control" @pointerdown="attack">⚔</button>
    </div>
    <div class="game3d-badge">3D • CINEMATIC</div>
  </div>
</template>

<script setup>
import { onMounted, onBeforeUnmount, ref } from 'vue'
import * as THREE from 'three'

const props = defineProps({
  prompt:{type:String,default:''},
  quality:{type:String,default:'High'},
  character:{type:String,default:'hero'},
  visualStyle:{type:String,default:'cinematic'}
})
const canvas=ref(null),started=ref(false),playerHp=ref(100),xp=ref(0),wave=ref(1)
let renderer,scene,camera,clock,raf,resizeObserver,player,weapon,targetRing
let enemyObjects=[],key={},particles=[],attackUntil=0,lastHit=0,elapsed=0
let orbit={theta:.65,phi:1.0,radius:12.5,dragging:false,x:0,y:0}
const config={title:'NOVA-X: Cinematic 3D Realm',genre:props.visualStyle==='scifi'?'Sci-Fi':props.visualStyle==='dark'?'Dark Fantasy':'Anime Fantasy'}
const palette={hero:{body:0x3f82ff,hair:0x16162a,armor:0x6fa8ff},mage:{body:0x7d4cff,hair:0x2a163f,armor:0xb68cff},ranger:{body:0x2aa875,hair:0x182b20,armor:0x5dd8aa},knight:{body:0xb9c8dc,hair:0x202938,armor:0x7d96b9}}
function material(c,r=.42,m=.12){return new THREE.MeshPhysicalMaterial({color:c,roughness:r,metalness:m,clearcoat:.32,clearcoatRoughness:.2,sheen:.12})}
function mesh(g,geo,c,pos=[0,0,0],scale=[1,1,1],rot=[0,0,0]){const m=new THREE.Mesh(geo,material(c));m.position.set(...pos);m.scale.set(...scale);m.rotation.set(...rot);m.castShadow=true;m.receiveShadow=true;g.add(m);return m}
function makeHumanoid(kind='hero'){
  const p=palette[kind]||palette.hero,g=new THREE.Group(),parts={};
  parts.root=g;parts.torso=mesh(g,new THREE.CapsuleGeometry(.38,.7,8,16),p.body,[0,1.18,0],[1,1,1]);
  parts.chest=mesh(g,new THREE.SphereGeometry(.5,24,18),p.armor,[0,1.42,0],[.95,.65,.55]);
  parts.head=mesh(g,new THREE.SphereGeometry(.39,32,24),0xe7bd9e,[0,2.03,0]);
  parts.hair=mesh(g,new THREE.SphereGeometry(.43,32,20),p.hair,[0,2.18,-.02],[1,.62,1]);
  parts.eyeL=mesh(g,new THREE.SphereGeometry(.045,12,8),0x9ce8ff,[-.14,2.04,.37]);
  parts.eyeR=mesh(g,new THREE.SphereGeometry(.045,12,8),0x9ce8ff,[.14,2.04,.37]);
  parts.nose=mesh(g,new THREE.SphereGeometry(.035,10,8),0xd99f86,[0,1.99,.39],[.7,.8,1]);
  parts.gloveL=mesh(g,new THREE.SphereGeometry(.14,16,12),p.armor,[-.68,.72,.02]);
  parts.gloveR=mesh(g,new THREE.SphereGeometry(.14,16,12),p.armor,[.68,.72,.02]);
  parts.kneeL=mesh(g,new THREE.SphereGeometry(.17,16,12),p.armor,[-.23,.5,.08]);
  parts.kneeR=mesh(g,new THREE.SphereGeometry(.17,16,12),p.armor,[.23,.5,.08]);
  parts.shoulderL=mesh(g,new THREE.SphereGeometry(.2,20,14),p.armor,[-.53,1.45,0]);
  parts.shoulderR=mesh(g,new THREE.SphereGeometry(.2,20,14),p.armor,[.53,1.45,0]);
  parts.armL=mesh(g,new THREE.CapsuleGeometry(.12,.58,8,12),p.body,[-.62,1.02,0],[1,1,1],[0,0,-.15]);
  parts.armR=mesh(g,new THREE.CapsuleGeometry(.12,.58,8,12),p.body,[.62,1.02,0],[1,1,1],[0,0,.15]);
  parts.legL=mesh(g,new THREE.CapsuleGeometry(.15,.68,8,12),p.armor,[-.23,.42,0]);
  parts.legR=mesh(g,new THREE.CapsuleGeometry(.15,.68,8,12),p.armor,[.23,.42,0]);
  parts.bootL=mesh(g,new THREE.BoxGeometry(.26,.2,.48),0x171d2c,[-.23,.06,.08]);
  parts.bootR=mesh(g,new THREE.BoxGeometry(.26,.2,.48),0x171d2c,[.23,.06,.08]);
  parts.cape=mesh(g,new THREE.ConeGeometry(.58,1.25,8,1,true),kind==='mage'?0x382060:0x172c52,[0,1.02,-.28],[1,1,1],[Math.PI,0,0]);
  parts.weapon=mesh(g,new THREE.BoxGeometry(.09,1.55,.08),0xe8f5ff,[.88,1.05,0],[1,1,1],[0,0,-.45]);
  parts.hilt=mesh(g,new THREE.CylinderGeometry(.06,.06,.32,12),0xd39b4d,[.62,.35,0],[1,1,1],[0,0,-.45]);
  g.userData.parts=parts;g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});return g
}
function makeCreature(i){
  const g=new THREE.Group(),body=i%3===0?0x8e43d0:i%3===1?0xc43e61:0x2d9290,parts={};
  parts.body=mesh(g,new THREE.SphereGeometry(.7,32,24),body,[0,.92,0],[1.08,.95,.9]);
  parts.chest=mesh(g,new THREE.SphereGeometry(.48,24,18),body,[0,1.25,.18],[1,.72,.6]);
  parts.head=mesh(g,new THREE.SphereGeometry(.48,28,20),0x4a2556,[0,1.72,.02],[1,.95,.9]);
  parts.hornL=mesh(g,new THREE.ConeGeometry(.11,.55,12),0xe8baff,[-.28,2.18,0],[1,1,1],[0,0,-.22]);
  parts.hornR=mesh(g,new THREE.ConeGeometry(.11,.55,12),0xe8baff,[.28,2.18,0],[1,1,1],[0,0,.22]);
  parts.eyeL=mesh(g,new THREE.SphereGeometry(.055,12,8),0xffe27a,[-.18,1.75,.43]);parts.eyeR=mesh(g,new THREE.SphereGeometry(.055,12,8),0xffe27a,[.18,1.75,.43]);
  parts.armL=mesh(g,new THREE.CapsuleGeometry(.11,.55,8,12),0x48204f,[-.68,.95,0],[1,1,1],[0,0,-.4]);parts.armR=mesh(g,new THREE.CapsuleGeometry(.11,.55,8,12),0x48204f,[.68,.95,0],[1,1,1],[0,0,.4]);
  parts.legL=mesh(g,new THREE.CapsuleGeometry(.13,.52,8,12),0x351d45,[-.27,.32,0]);parts.legR=mesh(g,new THREE.CapsuleGeometry(.13,.52,8,12),0x351d45,[.27,.32,0]);
  g.userData.parts=parts;g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});return g
}
function addTree(x,z,s=1){const g=new THREE.Group();g.position.set(x,0,z);mesh(g,new THREE.CylinderGeometry(.22*s,.38*s,3.2*s,18),0x4b3025,[0,1.6*s,0]);for(let k=0;k<4;k++){const a=k*.9;mesh(g,new THREE.IcosahedronGeometry((1.05-k*.12)*s,2),k%2?0x1d7650:0x176348,[Math.cos(a)*.42*s,2.55*s+k*.52,Math.sin(a)*.42*s],[1.1,1.15,1.1]);}mesh(g,new THREE.ConeGeometry(.5*s,1.4*s,14),0x2a9665,[0,4.15*s,0]);scene.add(g)}
function addCrystal(x,z,s=1){const g=new THREE.Group();g.position.set(x,0,z);mesh(g,new THREE.OctahedronGeometry(.65*s,1),props.visualStyle==='scifi'?0x35cfff:0x8c5cff,[0,.7*s,0],[.8,1.8,.8]);mesh(g,new THREE.OctahedronGeometry(.3*s,1),0xbdefff,[.42*s,.5*s,.1*s]);scene.add(g)}
function spawnSpark(pos,color=0x70dfff){const m=new THREE.Mesh(new THREE.SphereGeometry(.055,10,8),new THREE.MeshBasicMaterial({color}));m.position.copy(pos);m.userData.life=.55;scene.add(m);particles.push(m)}
function makeWorld(){
  scene=new THREE.Scene();scene.background=new THREE.Color(props.visualStyle==='dark'?0x090612:props.visualStyle==='scifi'?0x06101d:0x081525);scene.fog=new THREE.Fog(scene.background,24,68);
  camera=new THREE.PerspectiveCamera(50,1,.1,160);clock=new THREE.Clock();
  renderer=new THREE.WebGLRenderer({canvas:canvas.value,antialias:true,powerPreference:'high-performance'});renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,props.quality==='Maximum'?2:1.7));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  const hemi=new THREE.HemisphereLight(0xbcdcff,0x16261c,2.4);scene.add(hemi);const sun=new THREE.DirectionalLight(0xffe9c7,4.6);sun.position.set(12,22,8);sun.castShadow=true;sun.shadow.mapSize.set(props.quality==='Maximum'?4096:2048,props.quality==='Maximum'?4096:2048);sun.shadow.camera.left=-32;sun.shadow.camera.right=32;sun.shadow.camera.top=32;sun.shadow.camera.bottom=-32;scene.add(sun);
  const rim=new THREE.PointLight(props.visualStyle==='scifi'?0x36d9ff:0x8b5cff,28,28);rim.position.set(-7,6,-5);scene.add(rim);const fill=new THREE.PointLight(0xffc2a4,9,18);fill.position.set(6,4,5);scene.add(fill);
  const floorColor=props.visualStyle==='scifi'?0x102a3c:props.visualStyle==='dark'?0x21172c:0x163c2d;const ground=mesh(scene,new THREE.PlaneGeometry(80,80,64,64),floorColor,[0,0,0],[1,1,1],[-Math.PI/2,0,0]);ground.receiveShadow=true;
  for(let i=0;i<75;i++){const x=(Math.random()-.5)*68,z=(Math.random()-.5)*68;if(Math.hypot(x,z)>7)addTree(x,z,.65+Math.random()*1.1)}
  for(let i=0;i<34;i++){const a=Math.random()*Math.PI*2,r=7+Math.random()*28;addCrystal(Math.cos(a)*r,Math.sin(a)*r,.55+Math.random()*.9)}
  for(let i=0;i<45;i++){const x=(Math.random()-.5)*60,z=(Math.random()-.5)*60;if(Math.hypot(x,z)<6)continue;const rock=mesh(scene,new THREE.DodecahedronGeometry(.35+Math.random()*.7,1),0x39424d,[x,.3,z],[1.2,Math.random()*1.5+.7,1.1]);rock.rotation.y=Math.random()*Math.PI; }
  player=makeHumanoid(props.character);player.position.set(0,0,0);scene.add(player);
  targetRing=new THREE.Mesh(new THREE.RingGeometry(.9,1.12,64),new THREE.MeshBasicMaterial({color:0x6de7ff,transparent:true,opacity:.48,side:THREE.DoubleSide}));targetRing.rotation.x=-Math.PI/2;targetRing.position.y=.035;scene.add(targetRing);
  enemyObjects=[];const count=enemyCount();for(let i=0;i<count;i++){const g=makeCreature(i),a=i/count*Math.PI*2,r=8+(i%4)*2.3;g.position.set(Math.cos(a)*r,.03,Math.sin(a)*r);scene.add(g);enemyObjects.push({group:g,hp:100,alive:true,seed:i*37})}
  resize()
}
function enemyCount(){return props.quality==='Maximum'?12:props.quality==='High'?9:7}
function startGame(){if(started.value)return;started.value=true;makeWorld();clock.start();animate()}
function resize(){if(!renderer||!canvas.value)return;const el=canvas.value.parentElement,w=Math.max(1,el.clientWidth),h=Math.max(420,el.clientHeight);renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
function touchKey(k,v){key[k]=v}
function attack(){if(!started.value||performance.now()<attackUntil)return;attackUntil=performance.now()+500;const p=player.userData.parts;p.armR.rotation.z=-1.2;p.weapon.rotation.z=-1.35;for(const e of enemyObjects){if(e.alive&&e.group.position.distanceTo(player.position)<3.5){e.hp-=50;e.group.scale.setScalar(1.12);for(let j=0;j<9;j++)spawnSpark(e.group.position.clone().add(new THREE.Vector3((Math.random()-.5)*.8,1+(Math.random()-.5), (Math.random()-.5)*.8)),0x8ed8ff);setTimeout(()=>e.group.scale.setScalar(1),120);if(e.hp<=0){e.alive=false;e.group.visible=false;xp.value+=35}}}}
function animateHumanoid(g,t,moving=false,fighting=false){const p=g.userData.parts;if(!p)return;const walk=moving?Math.sin(t*9)*.42:Math.sin(t*2)*.025;p.legL.rotation.x=walk;p.legR.rotation.x=-walk;p.armL.rotation.x=-walk*.7;p.armR.rotation.x=walk*.7;if(fighting)p.armR.rotation.z=Math.sin(t*13)*.6;p.weapon.rotation.z=THREE.MathUtils.lerp(p.weapon.rotation.z,-.45,.12);p.cape.rotation.z=Math.sin(t*2.5)*.035}
function update(dt){if(!player)return;elapsed+=dt;const d=new THREE.Vector3((key.d||key.arrowright?1:0)-(key.a||key.arrowleft?1:0),0,(key.s||key.arrowdown?1:0)-(key.w||key.arrowup?1:0));const moving=d.lengthSq()>0;if(moving)d.normalize();player.position.addScaledVector(d,dt*5.3);player.position.x=THREE.MathUtils.clamp(player.position.x,-27,27);player.position.z=THREE.MathUtils.clamp(player.position.z,-27,27);if(moving)player.rotation.y=Math.atan2(d.x,d.z);animateHumanoid(player,elapsed,moving,performance.now()<attackUntil);targetRing.position.set(player.position.x,.04,player.position.z);
  for(const e of enemyObjects){if(!e.alive)continue;const to=player.position.clone().sub(e.group.position);to.y=0;const dist=to.length();const movingEnemy=dist>2.35;if(movingEnemy){to.normalize();e.group.position.addScaledVector(to,dt*(1.25+(e.seed%4)*.12));e.group.rotation.y=Math.atan2(to.x,to.z)}else if(performance.now()-lastHit>900){lastHit=performance.now();playerHp.value=Math.max(0,playerHp.value-4)}const ep=e.group.userData.parts;if(ep){const w=movingEnemy?Math.sin(elapsed*9+e.seed)*.35:Math.sin(elapsed*2+e.seed)*.03;ep.legL.rotation.x=w;ep.legR.rotation.x=-w;ep.armL.rotation.x=-w*.5;ep.armR.rotation.x=w*.5}e.group.position.y=.03+Math.sin(elapsed*2.2+e.seed)*.04}
  for(let i=particles.length-1;i>=0;i--){const q=particles[i];q.userData.life-=dt;q.position.y+=dt*1.8;if(q.userData.life<=0){scene.remove(q);particles.splice(i,1)}}
  if(enemyObjects.every(e=>!e.alive)){wave.value++;enemyObjects.forEach((e,i)=>{e.hp=100;e.alive=true;e.group.visible=true;const a=i/enemyObjects.length*Math.PI*2;e.group.position.set(Math.cos(a)*(8+wave.value),.03,Math.sin(a)*(8+wave.value))})}
  const r=orbit.radius;camera.position.set(player.position.x+Math.sin(orbit.theta)*Math.sin(orbit.phi)*r,player.position.y+Math.cos(orbit.phi)*r,player.position.z+Math.cos(orbit.theta)*Math.sin(orbit.phi)*r);camera.lookAt(player.position.x,player.position.y+1.15,player.position.z)
}
function animate(){raf=requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.05);update(dt);renderer.render(scene,camera)}
function keydown(e){if(!started.value)return;key[e.key.toLowerCase()]=true;if(e.code==='Space'){e.preventDefault();attack()}}
function keyup(e){key[e.key.toLowerCase()]=false}
function pointerdown(e){if(!started.value)return;orbit.dragging=true;orbit.x=e.clientX;orbit.y=e.clientY}
function pointermove(e){if(!orbit.dragging)return;orbit.theta-=(e.clientX-orbit.x)*.008;orbit.phi=THREE.MathUtils.clamp(orbit.phi+(e.clientY-orbit.y)*.006,.38,1.38);orbit.x=e.clientX;orbit.y=e.clientY}
function pointerup(){orbit.dragging=false}
function wheel(e){orbit.radius=THREE.MathUtils.clamp(orbit.radius+e.deltaY*.012,7,22)}
onMounted(()=>{window.addEventListener('keydown',keydown);window.addEventListener('keyup',keyup);window.addEventListener('resize',resize);window.addEventListener('pointerup',pointerup);canvas.value.addEventListener('pointerdown',pointerdown);canvas.value.addEventListener('pointermove',pointermove);canvas.value.addEventListener('wheel',wheel,{passive:true});resizeObserver=new ResizeObserver(resize);resizeObserver.observe(canvas.value.parentElement)})
onBeforeUnmount(()=>{cancelAnimationFrame(raf);window.removeEventListener('keydown',keydown);window.removeEventListener('keyup',keyup);window.removeEventListener('resize',resize);window.removeEventListener('pointerup',pointerup);resizeObserver?.disconnect();renderer?.dispose()})
</script>

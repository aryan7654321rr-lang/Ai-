<script setup>
import { computed, onMounted, onBeforeUnmount, ref } from 'vue'
import { NovaRenderer } from './core/renderer.js'
import { GAME_PIPELINE, VIDEO_PIPELINE, planShots, selectGameQuality } from './core/pipeline.js'

const mode = ref('game')
const prompt = ref('Create an original realistic open-world mystery adventure with a highly detailed human protagonist, believable modern city, forests, weather, exploration, dialogue, creatures and cinematic action.')
const duration = ref(10)
const quality = ref('auto')
const status = ref('Renderer online')
const building = ref(false)
const shotPlan = ref([])
const gamePlan = ref(null)
const settingsOpen = ref(false)
const device = ref({ name:'Target device', ram:'detecting', gpu:'detecting', thermal:'normal' })
const viewport = ref(null)
let renderer

const activePipeline = computed(() => mode.value === 'game' ? GAME_PIPELINE : VIDEO_PIPELINE)
const queued = computed(() => shotPlan.value.filter(s => s.status === 'queued').length)
const rendered = computed(() => shotPlan.value.filter(s => s.status === 'rendered').length)

function createGamePlan() {
  building.value = true; status.value = 'Compiling high-realism game scene…'
  setTimeout(() => {
    const profile = selectGameQuality(device.value, 24)
    gamePlan.value = { visualTarget:'maximum-practical-realism', heroAsset:'high-detail human source → optimized hero LOD', nearbyAssetTier:'maximum practical near-field detail', distantWorld:'streamed + simplified', profile, gpuPolicy:'protect hero and near-field quality first' }
    mode.value='game'; renderer?.setQuality(profile); building.value=false; status.value='Real-time renderer active — hero-first quality policy applied.'
  }, 350)
}
function createVideoPlan() {
  building.value=true; status.value='Compiling cinematic shot-render plan…'
  setTimeout(() => { shotPlan.value=planShots(prompt.value, Number(duration.value)); mode.value='video'; building.value=false; status.value=`${shotPlan.value.length} cinematic shots queued for independent high-quality rendering.` },350)
}
function markNextRendered(){ const s=shotPlan.value.find(x=>x.status==='queued'); if(s){s.status='rendered';status.value=`${s.id} completed by the cinematic renderer.`} }
function retryBadShot(){ const s=shotPlan.value.find(x=>x.status==='failed'); status.value=s?(s.status='queued',`${s.id} returned to render queue.`):'No failed shots.' }
function setQuality(q){ quality.value=q; localStorage.setItem('nova-quality',q); renderer?.setQuality(q==='auto'?'hero-max':q); status.value=`Renderer quality policy: ${q.toUpperCase()}` }
function switchMode(m){mode.value=m; status.value=m==='game'?'Real-time 3D renderer · mobile hero-first':'Cinematic renderer · independent high-quality shots'}

onMounted(()=>{ quality.value=localStorage.getItem('nova-quality')||'auto'; renderer=new NovaRenderer(viewport.value); renderer.setQuality(quality.value==='auto'?'hero-max':quality.value) })
onBeforeUnmount(()=>renderer?.dispose())
</script>

<template>
<main class="nova-shell">
  <header class="topbar">
    <div class="brand"><div class="logo-core"><span></span></div><div><strong>NOVA</strong><small>NEURAL VISUAL OPERATING ARCHITECTURE</small></div></div>
    <div class="top-actions"><span class="live"><i></i> RENDER CORE ONLINE</span><button class="icon-btn" @click="settingsOpen=!settingsOpen">☷</button></div>
  </header>

  <section class="hero-grid">
    <div class="hero-copy">
      <div class="eyebrow">NOVA / CREATION COMMAND</div>
      <h1>Build worlds.<br><em>Render them beautifully.</em></h1>
      <p>One creative core, two specialized production paths: a real-time high-realism game renderer for mobile hardware and a separate cinematic renderer for long-form high-quality video.</p>
      <div class="mode-switch"><button :class="{active:mode==='game'}" @click="switchMode('game')">GAME ENGINE</button><button :class="{active:mode==='video'}" @click="switchMode('video')">VIDEO STUDIO</button></div>
    </div>
    <div class="viewport-wrap"><div class="viewport-label"><span>LIVE 3D VIEWPORT</span><b>{{ mode==='game' ? 'REAL-TIME' : 'CINEMATIC PREVIEW' }}</b></div><div ref="viewport" class="viewport"></div><div class="viewport-hud"><span>HERO DETAIL: MAX</span><span>LIGHTING: ACTIVE</span><span>LOD: ADAPTIVE</span></div></div>
  </section>

  <section class="command-panel">
    <div class="prompt-head"><div><span class="eyebrow">CREATION INPUT</span><h2>{{ mode==='game'?'Describe the game world':'Describe the episode' }}</h2></div><span class="pipeline-chip">{{ activePipeline.name }}</span></div>
    <textarea v-model="prompt"></textarea>
    <div class="input-row"><label v-if="mode==='video'">DURATION <input v-model.number="duration" type="number" min="1" max="60"> MIN</label><button class="launch" :disabled="building" @click="mode==='game'?createGamePlan():createVideoPlan()"><span>{{ building?'PROCESSING…':mode==='game'?'INITIALIZE REALISTIC WORLD':'BUILD CINEMATIC SHOTS' }}</span><b>↗</b></button></div>
  </section>

  <section class="systems">
    <article class="system-card"><div class="card-top"><span class="number">01</span><span class="eyebrow">REAL-TIME RENDERER</span></div><h3>Hero-first mobile realism</h3><p>Detailed source assets are optimized into device-aware LODs. The renderer protects the character and nearby world before reducing distant complexity.</p><div class="meter"><span style="width:94%"></span></div><small>CHARACTER / NEAR FIELD PRIORITY</small></article>
    <article class="system-card"><div class="card-top"><span class="number">02</span><span class="eyebrow">CINEMATIC RENDERER</span></div><h3>Shot-by-shot quality</h3><p>Video gets its own high-detail characters, environments and animation. Short shots can take longer to process, then assemble into a 10-minute episode.</p><div class="meter violet"><span style="width:98%"></span></div><small>PER-SHOT QUALITY PRIORITY</small></article>
    <article class="system-card"><div class="card-top"><span class="number">03</span><span class="eyebrow">SHARED CORE</span></div><h3>One rendering foundation</h3><p>Geometry, materials, lighting, animation, camera and effects are shared concepts; game and video choose different asset and performance policies.</p><div class="core-orbit"><i></i><i></i><i></i></div></article>
  </section>

  <section v-if="mode==='video'" class="production panelish"><div><span class="eyebrow">CINEMATIC QUEUE</span><h2>{{ shotPlan.length }} shots · {{ queued }} queued · {{ rendered }} rendered</h2></div><div class="queue-actions"><button @click="markNextRendered">RENDER NEXT</button><button @click="retryBadShot">RETRY FAILED</button></div></section>
  <section v-if="mode==='game' && gamePlan" class="production panelish"><div><span class="eyebrow">GAME RENDER PROFILE</span><h2>{{ gamePlan.profile }} · hero quality protected</h2></div><span class="ready">READY</span></section>

  <footer><span>{{ status }}</span><span>QUALITY POLICY · {{ quality.toUpperCase() }}</span></footer>

  <aside v-if="settingsOpen" class="settings panelish"><div class="prompt-head"><h2>Renderer Controls</h2><button class="icon-btn" @click="settingsOpen=false">×</button></div><p>Game rendering adapts to device performance. Video rendering is not constrained by the game's real-time budget.</p><div class="quality-grid"><button v-for="q in ['auto','low','medium','high','max']" :key="q" :class="{selected:quality===q}" @click="setQuality(q)">{{q.toUpperCase()}}</button></div></aside>
</main>
</template>

export const GAME_PIPELINE = {
  name: 'NOVA Real-Time Game',
  goal: 'Maximum practical realism on the target device',
  assetPolicy: 'hero-first',
  stages: ['concept','high-detail-source','mobile-hero-LOD','near-LOD','mid-LOD','far-LOD','streaming','runtime-profiling'],
  priorities: ['player','nearby-npc','nearby-environment','gameplay-critical','background']
}

export const VIDEO_PIPELINE = {
  name: 'NOVA High-Quality Video',
  goal: 'Maximum practical visual quality per shot, assembled into long-form video',
  separateAssetsFromGame: true,
  stages: ['script','shot-plan','licensed-reference-search','reference-analysis','original-character','original-environment','animation','lighting','render-shot','continuity-check','retry','edit','encode'],
  shotLengthSeconds: { min: 4, max: 15 }
}

export const VIDEO_REFERENCE_POLICY = {
  allowed: ['public-domain','CC0','Creative-Commons-with-adaptation-rights','user-owned','properly licensed commercial sources'],
  forbidden: ['unlicensed copyrighted footage','ripped movies/anime/game footage','material whose license does not permit the intended adaptation'],
  useFor: ['camera language','staging','timing','motion reference','environment inspiration'],
  notFor: ['copying protected characters','copying protected scenes shot-for-shot','redistributing source footage']
}

export function planShots(script, durationMinutes = 10) {
  const seconds = Math.max(60, durationMinutes * 60)
  const count = Math.ceil(seconds / 9)
  const types = ['establishing','character','dialogue','movement','mystery','action','reaction','transition']
  return Array.from({length: count}, (_, i) => ({
    id: `SHOT-${String(i + 1).padStart(3,'0')}`,
    start: i * 9,
    duration: Math.min(9, seconds - i * 9),
    type: types[i % types.length],
    status: 'queued',
    quality: 'maximum-practical',
    continuityKey: `continuity-${i}`
  }))
}

export function selectGameQuality(device, frameTimeMs) {
  const thermal = device?.thermal ?? 'normal'
  if (thermal === 'critical' || frameTimeMs > 33) return 'near-hero'
  if (frameTimeMs > 24) return 'hero-balanced'
  return 'hero-max'
}

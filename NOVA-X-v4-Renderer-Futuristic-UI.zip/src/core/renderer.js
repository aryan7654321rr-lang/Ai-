import * as THREE from 'three'

export class NovaRenderer {
  constructor(host) {
    this.host = host
    this.scene = new THREE.Scene()
    this.scene.background = new THREE.Color(0x050812)
    this.scene.fog = new THREE.FogExp2(0x07101b, 0.018)
    this.camera = new THREE.PerspectiveCamera(48, 1, 0.1, 500)
    this.camera.position.set(8, 5.5, 10)
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' })
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2))
    this.renderer.shadowMap.enabled = true
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap
    this.renderer.outputColorSpace = THREE.SRGBColorSpace
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping
    this.renderer.toneMappingExposure = 1.15
    this.host.appendChild(this.renderer.domElement)
    this.clock = new THREE.Clock()
    this.hero = null
    this.quality = 'hero-max'
    this._resize = () => this.resize()
    window.addEventListener('resize', this._resize)
    this.buildScene()
    this.resize()
    this.animate()
  }

  buildScene() {
    this.scene.clear()
    const hemi = new THREE.HemisphereLight(0xa9c9ff, 0x152033, 2.1)
    this.scene.add(hemi)
    const key = new THREE.DirectionalLight(0xd9e8ff, 3.2)
    key.position.set(8, 16, 6); key.castShadow = true
    key.shadow.mapSize.set(2048, 2048)
    key.shadow.camera.near = 1; key.shadow.camera.far = 70
    key.shadow.camera.left = -25; key.shadow.camera.right = 25; key.shadow.camera.top = 25; key.shadow.camera.bottom = -25
    this.scene.add(key)
    const rim = new THREE.PointLight(0x5d8cff, 24, 30, 2)
    rim.position.set(-7, 5, -5); this.scene.add(rim)

    const ground = new THREE.Mesh(new THREE.PlaneGeometry(180, 180), new THREE.MeshStandardMaterial({ color: 0x111a25, roughness: .92, metalness: .05 }))
    ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; this.scene.add(ground)

    for (let i = -5; i <= 5; i++) {
      const road = new THREE.Mesh(new THREE.BoxGeometry(4.2, .04, 180), new THREE.MeshStandardMaterial({ color: 0x1c2530, roughness: .82 }))
      road.position.x = i * 10; road.position.y = .02; this.scene.add(road)
    }
    for (let i = -7; i <= 7; i++) {
      const building = new THREE.Mesh(new THREE.BoxGeometry(5.4, 3 + Math.abs(i % 4) * 1.4, 5.4), new THREE.MeshStandardMaterial({ color: 0x273548, roughness: .55, metalness: .18 }))
      building.position.set((i % 3) * 10 - 10, building.geometry.parameters.height / 2, -9 - Math.floor(i / 3) * 8)
      building.castShadow = true; building.receiveShadow = true; this.scene.add(building)
    }
    for (let i = 0; i < 34; i++) this.addTree((i % 9) * 10 - 40, -5 - Math.floor(i / 9) * 13, 0.8 + (i % 4) * .12)
    this.hero = this.makeHero()
    this.scene.add(this.hero)
    const ring = new THREE.Mesh(new THREE.RingGeometry(1.25, 1.3, 64), new THREE.MeshBasicMaterial({ color: 0x75a8ff, transparent: true, opacity: .42, side: THREE.DoubleSide }))
    ring.rotation.x = -Math.PI / 2; ring.position.y = .05; this.hero.add(ring)
  }

  addTree(x, z, scale) {
    const g = new THREE.Group(); g.position.set(x, 0, z); g.scale.setScalar(scale)
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.18, .26, 2.1, 10), new THREE.MeshStandardMaterial({ color: 0x503a2a, roughness: 1 }))
    trunk.position.y = 1.05; trunk.castShadow = true; g.add(trunk)
    const crown = new THREE.Mesh(new THREE.IcosahedronGeometry(1.45, 1), new THREE.MeshStandardMaterial({ color: 0x214a3c, roughness: .86 }))
    crown.position.y = 2.5; crown.castShadow = true; g.add(crown)
    this.scene.add(g)
  }

  makeHero() {
    const g = new THREE.Group(); g.position.set(0, 0, 1.2)
    const skin = new THREE.MeshStandardMaterial({ color: 0xc88f73, roughness: .62, metalness: .02 })
    const cloth = new THREE.MeshStandardMaterial({ color: 0x18283e, roughness: .48, metalness: .12 })
    const hairMat = new THREE.MeshStandardMaterial({ color: 0x10141b, roughness: .36 })
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(.72, 1.25, 8, 18), cloth); torso.position.y = 1.65; torso.scale.z = .65; torso.castShadow = true; g.add(torso)
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(.22, .24, .28, 16), skin); neck.position.y = 2.65; g.add(neck)
    const head = new THREE.Mesh(new THREE.SphereGeometry(.48, 32, 24), skin); head.position.y = 3.15; head.scale.set(1, 1.08, .92); head.castShadow = true; g.add(head)
    const hair = new THREE.Mesh(new THREE.SphereGeometry(.5, 32, 20, 0, Math.PI * 2, 0, Math.PI * .58), hairMat); hair.position.set(0, 3.34, -.01); hair.castShadow = true; g.add(hair)
    for (const x of [-.82, .82]) { const arm = new THREE.Mesh(new THREE.CapsuleGeometry(.18, 1.15, 6, 12), cloth); arm.position.set(x, 1.68, 0); arm.rotation.z = x < 0 ? -.08 : .08; arm.castShadow = true; g.add(arm) }
    for (const x of [-.36, .36]) { const leg = new THREE.Mesh(new THREE.CapsuleGeometry(.22, 1.35, 6, 12), cloth); leg.position.set(x, .72, 0); leg.castShadow = true; g.add(leg) }
    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x9ed5ff, emissive: 0x1b5b91, emissiveIntensity: 1.4 })
    for (const x of [-.17, .17]) { const eye = new THREE.Mesh(new THREE.SphereGeometry(.045, 12, 8), eyeMat); eye.position.set(x, 3.18, .43); g.add(eye) }
    return g
  }

  setQuality(q) {
    this.quality = q
    const ratios = { low: .75, medium: 1, high: 1.35, max: 1.75, 'hero-max': 1.6, 'hero-balanced': 1.2, 'near-hero': .95 }
    this.renderer.setPixelRatio(Math.min((window.devicePixelRatio || 1) * (ratios[q] || 1), 2))
    this.resize()
  }

  resize() {
    const w = Math.max(1, this.host.clientWidth), h = Math.max(1, this.host.clientHeight)
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); this.renderer.setSize(w, h, false)
  }

  animate() {
    this.frame = requestAnimationFrame(() => this.animate())
    const t = this.clock.getElapsedTime()
    if (this.hero) { this.hero.rotation.y = Math.sin(t * .18) * .15; this.hero.position.y = Math.sin(t * 1.4) * .025 }
    this.camera.position.x = 8 + Math.sin(t * .12) * 1.2
    this.camera.lookAt(0, 2, 0)
    this.renderer.render(this.scene, this.camera)
  }

  dispose() {
    cancelAnimationFrame(this.frame); window.removeEventListener('resize', this._resize); this.renderer.dispose(); this.host.innerHTML = ''
  }
}

/**
 * Asset registry intentionally contains no copyrighted game/anime assets.
 * Production NOVA can populate this registry from sources whose licenses permit
 * the intended use. Video assets and game assets are deliberately separate.
 */
export const assetRegistry = {
  game: {
    hero: [],
    nearbyCharacters: [],
    environment: [],
    creatures: []
  },
  video: {
    characters: [],
    environments: [],
    motionReferences: []
  }
}

export function registerAsset(bucket, asset) {
  if (!assetRegistry[bucket]) throw new Error(`Unknown asset bucket: ${bucket}`)
  assetRegistry[bucket].push({
    id: asset.id,
    uri: asset.uri,
    license: asset.license,
    source: asset.source,
    role: asset.role,
    quality: asset.quality
  })
}

export function validateVideoReference(asset) {
  return ['public-domain','CC0','Creative-Commons-with-adaptation-rights','user-owned','properly licensed commercial sources'].includes(asset.license)
}

# NOVA-X: ZIP to APK with GitHub Actions

This setup is designed for a GitHub repository that contains the NOVA-X project ZIP rather than extracted project files.

## Repository layout

```text
Ai-/
├── .github/
│   └── workflows/
│       └── main.yml
└── NOVA-X-Final-GitHub.zip
```

The workflow automatically extracts the ZIP, finds `package.json`, builds the Vue app, creates the Capacitor Android project, and builds a debug APK.

## Run

1. Upload `NOVA-X-Final-GitHub.zip` to the repository root.
2. Upload `.github/workflows/main.yml`.
3. Open **Actions**.
4. Select **NOVA-X APK Build**.
5. Choose **Run workflow**.
6. After completion, download **NOVA-X-debug-apk** from Artifacts.

The APK is a debug APK for testing, not a Play Store release build.

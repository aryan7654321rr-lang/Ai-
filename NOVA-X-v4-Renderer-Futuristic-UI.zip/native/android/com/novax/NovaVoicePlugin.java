package com.novax;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import com.getcapacitor.Plugin;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.JSObject;

@CapacitorPlugin(name="NovaVoice")
public class NovaVoicePlugin extends Plugin {
  private static final int MIC_REQUEST = 7101;
  @com.getcapacitor.PluginMethod public void requestMicrophone(PluginCall call) {
    if (getActivity().checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { call.resolve(); return; }
    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
    call.resolve();
  }
  @com.getcapacitor.PluginMethod public void openAppSettings(PluginCall call) {
    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getActivity().getPackageName()));
    getActivity().startActivity(i); call.resolve();
  }
}

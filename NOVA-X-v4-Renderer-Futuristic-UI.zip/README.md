# NOVA — Realism-First Game + High-Quality Video Studio

This version removes the earlier prototype-first presentation and makes the product architecture explicit:

## Game pipeline
- Separate real-time mobile game asset pipeline.
- High-detail human-like source assets are the starting point.
- Player/hero and near-field assets receive the highest practical quality budget.
- Source assets are optimized into LODs; optimization is not a substitute for a detailed source model.
- Distant content uses streaming, culling and cheaper LODs.
- Device/thermal profiling decides how aggressively the world is simplified.

## Video pipeline
- Deliberately separate from the game's mobile assets.
- Long videos are planned as many short shots.
- Each shot can be processed at maximum practical quality, checked for continuity and retried independently.
- The video character/environment pipeline targets high-detail human-like 3D characters and story-matched environments rather than the game's low-end runtime assets.
- Internet reference discovery is a planned production step, but only material with rights suitable for adaptation is allowed into the pipeline.
- References are for motion/camera/staging inspiration; protected characters and footage are not copied.

## What this repository is
This is the control-plane/source architecture for the next NOVA build. It does **not** falsely claim that a lightweight web prototype can already generate photorealistic characters, AAA game worlds, or a finished 10-minute AI movie locally. Those capabilities require actual asset/model providers, rendering/encoding infrastructure and device testing.

## Removed from the product direction
- Generic low-poly “AAA” placeholder world presentation.
- Treating the game's mobile assets as the video assets.
- Treating a 10-second browser recording as a 10-minute video generator.
- Assuming arbitrary internet video is legally reusable.

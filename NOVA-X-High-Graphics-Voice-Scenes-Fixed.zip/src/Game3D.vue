<template>
  <div class="game3d-shell" :class="{playing: started}">
    <canvas ref="canvas" class="game3d-canvas"></canvas>
    <div v-if="!started" class="game-start-overlay">
      <div class="game-start-card">
        <div class="game-start-kicker">NOVA-X REAL-TIME 3D</div>
        <h2>{{ config.title }}</h2>
        <p>High-detail third-person scene · {{ quality }} graphics · {{ enemies.length }} enemies</p>
        <button class="game-start-button" @click="startGame">▶ START GAME</button>
        <small>Touch controls appear in the lower corner after starting.</small>
      </div>
    </div>
    <div v-if="started" class="game3d-hud">
      <div class="hud-title">{{ config.title }}</div>
      <div class="hud-sub">{{ config.genre }} · {{ quality }} · Wave {{ wave }}</div>
      <div class="hud-bar"><span :style="{width: playerHp + '%'}"></span></div>
      <div class="hud-stats">HP {{ playerHp }} · XP {{ xp }}</div>
      <div class="hud-help">Drag to orbit · pinch/wheel to zoom</div>
    </div>
    <div v-if="started" class="touch-controls-corner">
      <div class="move-pad">
        <button class="up" @pointerdown="touchKey('w',true)" @pointerup="touchKey('w',false)" @pointercancel="touchKey('w',false)" @pointerleave="touchKey('w',false)">▲</button>
        <button @pointerdown="touchKey('a',true)" @pointerup="touchKey('a',false)" @pointercancel="touchKey('a',false)" @pointerleave="touchKey('a',false)">◀</button>
        <button @pointerdown="touchKey('s',true)" @pointerup="touchKey('s',false)" @pointercancel="touchKey('s',false)" @pointerleave="touchKey('s',false)">▼</button>
        <button @pointerdown="touchKey('d',true)" @pointerup="touchKey('d',false)" @pointercancel="touchKey('d',false)" @pointerleave="touchKey('d',false)">▶</button>
      </div>
      <button class="attack-control" @pointerdown="attack">⚔</button>
    </div>
    <div class="game3d-badge">3D • HIGH DETAIL</div>
  </div>
</template>

<script setup>
import { onMounted, onBeforeUnmount, ref } from 'vue'
import * as THREE from 'three'

const props = defineProps({ prompt:{type:String,default:''},quality:{type:String,default:'High'},character:{type:String,default:'hero'},visualStyle:{type:String,default:'cinematic'} })
const canvas=ref(null), started=ref(false), playerHp=ref(100), xp=ref(0), wave=ref(1), enemies=ref([])
let renderer,scene,camera,clock,raf,resizeObserver,player,sword,targetRing,ground
let enemyObjects=[],key={},orbit={theta:.7,phi:1.0,radius:14,dragging:false,x:0,y:0},attackUntil=0,lastHit=0
const config={title:'NOVA-X: Cinematic 3D Realm',genre:props.visualStyle==='scifi'?'Sci-Fi':'Anime Fantasy'}
const touchKey=(k,v)=>{key[k]=v}
function mat(c,r=.48,m=.12){return new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m})}
function box(p,s,pos,c,r={}){const m=new THREE.Mesh(new THREE.BoxGeometry(...s),mat(c));m.position.set(...pos);m.rotation.set(r.x||0,r.y||0,r.z||0);m.castShadow=m.receiveShadow=true;p.add(m);return m}
function sphere(p,r,pos,c,scale=[1,1,1]){const m=new THREE.Mesh(new THREE.SphereGeometry(r,32,24),mat(c));m.position.set(...pos);m.scale.set(...scale);m.castShadow=m.receiveShadow=true;p.add(m);return m}
function addTree(x,z,s=1){const g=new THREE.Group();g.position.set(x,0,z);box(g,[.5*s,2.6*s,.5*s],[0,1.3*s,0],0x493426);sphere(g,1.35*s,[0,3*s,0],0x176447,[1,1.2,1]);sphere(g,.9*s,[.7*s,3.7*s,.1*s],0x238a5d);sphere(g,.85*s,[-.6*s,4*s,0],0x2a9b68);scene.add(g)}
function addRock(x,z,s=1){const g=new THREE.Group();g.position.set(x,0,z);const m=new THREE.Mesh(new THREE.DodecahedronGeometry(.7*s,1),mat(0x52657a,.7,.15));m.position.y=.5*s;m.scale.y=.65; m.castShadow=m.receiveShadow=true;g.add(m);scene.add(g)}
function makePlayer(){const g=new THREE.Group();g.position.set(0,.05,0);const c=props.character==='mage'?0x7d4cff:props.character==='ranger'?0x2ba977:props.character==='knight'?0xbfcde3:0x3f83ff;box(g,[.8,1.15,.48],[0,1.05,0],c);box(g,[.95,.22,.62],[0,1.5,0],props.character==='knight'?0x7f8da5:0x24385e);sphere(g,.44,[0,2.0,0],0xe9c4a8,[1,.98,1]);sphere(g,.47,[0,2.22,-.02],0x171629,[1,.5,1]);sphere(g,.06,[.16,2.0,.39],0x74e7ff);sphere(g,.06,[-.16,2.0,.39],0x74e7ff);box(g,[.22,.9,.28],[-.25,.28,0],0x26314f);box(g,[.22,.9,.28],[.25,.28,0],0x26314f);sword=box(g,[.11,1.9,.16],[.75,1.0,0],0xe8f4ff,{z:-.4});box(g,[.32,.12,.28],[.75,.22,0],0xb98a45,{z:-.4});scene.add(g);return g}
function makeEnemy(i){const g=new THREE.Group(),a=i/Math.max(1,enemyCount())*Math.PI*2,r=6+(i%4)*2;g.position.set(Math.cos(a)*r,.05,Math.sin(a)*r);const body=i%3===0?0x9a3fdb:i%3===1?0xc33e5f:0x2f8f8d;sphere(g,.8,[0,.85,0],body,[1,.9,1]);sphere(g,.52,[0,1.65,0],0x47244f);const h=sphere(g,.16,[.3,2.05,0],0xeecbff,[.7,2.2,.7]);const h2=h.clone();h2.position.x=-.3;g.add(h2);sphere(g,.07,[.19,1.7,.48],0xffdf69);sphere(g,.07,[-.19,1.7,.48],0xffdf69);box(g,[.25,.75,.25],[-.3,.15,0],0x3c244b);box(g,[.25,.75,.25],[.3,.15,0],0x3c244b);scene.add(g);const o={group:g,hp:100,alive:true,seed:i*31};enemyObjects.push(o);return g}
function enemyCount(){return props.quality==='Maximum'?10:props.quality==='High'?8:6}
function buildWorld(){
 scene=new THREE.Scene();scene.background=new THREE.Color(props.visualStyle==='dark'?0x090612:props.visualStyle==='scifi'?0x06101d:0x081524);scene.fog=new THREE.Fog(scene.background,22,58)
 camera=new THREE.PerspectiveCamera(52,1,.1,140);clock=new THREE.Clock();renderer=new THREE.WebGLRenderer({canvas:canvas.value,antialias:true,powerPreference:'high-performance'});renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.setPixelRatio(Math.min(devicePixelRatio,props.quality==='Maximum'?2:1.6));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap
 const hemi=new THREE.HemisphereLight(0xb8d9ff,0x13251b,2.2);scene.add(hemi);const sun=new THREE.DirectionalLight(0xffe6bf,4.2);sun.position.set(12,18,8);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.left=-30;sun.shadow.camera.right=30;sun.shadow.camera.top=30;sun.shadow.camera.bottom=-30;scene.add(sun)
 const fill=new THREE.PointLight(props.visualStyle==='scifi'?0x36cfff:0x8b5cff,18,20);fill.position.set(-5,5,-4);scene.add(fill)
 ground=new THREE.Mesh(new THREE.PlaneGeometry(70,70,40,40),new THREE.MeshStandardMaterial({color:props.visualStyle==='scifi'?0x102a3b:props.visualStyle==='dark'?0x21182b:0x163d2d,roughness:.9}));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground)
 for(let i=0;i<55;i++){const x=(Math.random()-.5)*60,z=(Math.random()-.5)*60;if(Math.hypot(x,z)>6)addTree(x,z,.65+Math.random()*.9)} for(let i=0;i<25;i++){const a=Math.random()*Math.PI*2,r=5+Math.random()*25;addRock(Math.cos(a)*r,Math.sin(a)*r,.5+Math.random())}
 player=makePlayer();targetRing=new THREE.Mesh(new THREE.RingGeometry(.85,1.05,48),new THREE.MeshBasicMaterial({color:0x5edfff,side:THREE.DoubleSide,transparent:true,opacity:.55}));targetRing.rotation.x=-Math.PI/2;targetRing.position.y=.035;scene.add(targetRing)
 enemyObjects=[];for(let i=0;i<enemyCount();i++)makeEnemy(i);enemies.value=enemyObjects;resize()
}
function startGame(){if(started.value)return;started.value=true;buildWorld();clock.start();animate()}
function resize(){if(!renderer)return;const el=canvas.value.parentElement,w=el.clientWidth,h=Math.max(420,el.clientHeight);renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
function attack(){if(!started.value||performance.now()<attackUntil)return;attackUntil=performance.now()+420;sword.rotation.z=-1.45;for(const e of enemyObjects){if(e.alive&&e.group.position.distanceTo(player.position)<3.2){e.hp-=50;e.group.scale.setScalar(1.18);setTimeout(()=>e.group.scale.setScalar(1),110);if(e.hp<=0){e.alive=false;e.group.visible=false;xp.value+=30}}}}
function update(dt){if(!player)return;const d=new THREE.Vector3((key.d||key.arrowright?1:0)-(key.a||key.arrowleft?1:0),0,(key.s||key.arrowdown?1:0)-(key.w||key.arrowup?1:0));if(d.lengthSq())d.normalize();player.position.addScaledVector(d,dt*5.4);player.position.x=THREE.MathUtils.clamp(player.position.x,-25,25);player.position.z=THREE.MathUtils.clamp(player.position.z,-25,25);if(d.lengthSq())player.rotation.y=Math.atan2(d.x,d.z);targetRing.position.set(player.position.x,.04,player.position.z);if(performance.now()>attackUntil)sword.rotation.z=THREE.MathUtils.lerp(sword.rotation.z,-.4,.18)
 for(const e of enemyObjects){if(!e.alive)continue;const to=player.position.clone().sub(e.group.position);to.y=0;const dist=to.length();if(dist>2.15){to.normalize();e.group.position.addScaledVector(to,dt*(1.2+(e.seed%4)*.15));e.group.rotation.y=Math.atan2(to.x,to.z)}else if(performance.now()-lastHit>900){lastHit=performance.now();playerHp.value=Math.max(0,playerHp.value-5)}e.group.position.y=.05+Math.sin(performance.now()*.002+e.seed)*.06}
 if(enemyObjects.every(e=>!e.alive)){wave.value++;enemyObjects.forEach((e,i)=>{e.hp=100;e.alive=true;e.group.visible=true;const a=i/enemyObjects.length*Math.PI*2;e.group.position.set(Math.cos(a)*(7+wave.value),.05,Math.sin(a)*(7+wave.value))})}
 const r=orbit.radius;camera.position.set(player.position.x+Math.sin(orbit.theta)*Math.sin(orbit.phi)*r,player.position.y+Math.cos(orbit.phi)*r,player.position.z+Math.cos(orbit.theta)*Math.sin(orbit.phi)*r);camera.lookAt(player.position.x,player.position.y+1.15,player.position.z)
}
function animate(){raf=requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.05);update(dt);renderer.render(scene,camera)}
function keydown(e){if(!started.value)return;key[e.key.toLowerCase()]=true;if(e.code==='Space'){e.preventDefault();attack()}}function keyup(e){key[e.key.toLowerCase()]=false}
function pointerdown(e){if(!started.value)return;orbit.dragging=true;orbit.x=e.clientX;orbit.y=e.clientY}function pointermove(e){if(!orbit.dragging)return;orbit.theta-=(e.clientX-orbit.x)*.008;orbit.phi=THREE.MathUtils.clamp(orbit.phi+(e.clientY-orbit.y)*.006,.35,1.4);orbit.x=e.clientX;orbit.y=e.clientY}function pointerup(){orbit.dragging=false}function wheel(e){orbit.radius=THREE.MathUtils.clamp(orbit.radius+e.deltaY*.012,7,24)}
onMounted(()=>{window.addEventListener('keydown',keydown);window.addEventListener('keyup',keyup);window.addEventListener('resize',resize);window.addEventListener('pointerup',pointerup);canvas.value.addEventListener('pointerdown',pointerdown);canvas.value.addEventListener('pointermove',pointermove);canvas.value.addEventListener('wheel',wheel,{passive:true});resizeObserver=new ResizeObserver(resize);resizeObserver.observe(canvas.value.parentElement)})
onBeforeUnmount(()=>{cancelAnimationFrame(raf);window.removeEventListener('keydown',keydown);window.removeEventListener('keyup',keyup);window.removeEventListener('resize',resize);window.removeEventListener('pointerup',pointerup);resizeObserver?.disconnect();renderer?.dispose()})
</script>

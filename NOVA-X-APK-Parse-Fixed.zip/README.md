# NOVA-X — Voice-first local creative assistant

NOVA-X is a local-first Vue + Capacitor Android foundation focused on voice interaction and creative generation.

## Current capabilities

- Futuristic voice-first interface.
- Android native `Hey Nova` wake-word loop using the device speech recognizer.
- After `Hey Nova`, NOVA captures the next command and answers using Android Text-to-Speech.
- Browser SpeechRecognition/TTS fallback when the WebView exposes those APIs.
- Local browser memory.
- Playable generated HTML game prototypes with movement and combat.
- Local animation rendering to real WebM clips using Canvas + MediaRecorder where the WebView supports it.
- Device-aware generation metadata and local project export.
- GitHub Actions workflow that builds the Vue app, creates a fresh Capacitor Android project, injects the native voice bridge, and uploads the debug APK.

## Important scope

The game builder currently creates a playable procedural prototype rather than a full AAA 3D game. The anime builder currently renders procedural animated WebM clips rather than running a heavyweight text-to-video foundation model. Those heavier engines can be added as optional local/device-specific adapters later.

## Build

The repository workflow is designed for a repository containing this project ZIP at the repository root. Run **NOVA-X APK Build** from GitHub Actions and download `NOVA-X-debug-apk` from the completed run.


## Installing the APK from GitHub Actions

GitHub Actions artifacts are downloaded by GitHub as a ZIP container. Do **not** rename that ZIP to `.apk`. Extract it first, then install `NOVA-X-debug.apk`.

The workflow now validates the APK with Android `aapt` and `apksigner` before uploading it, including checking the application id `com.novax`.
